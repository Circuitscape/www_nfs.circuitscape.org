function [G, NODEMAP] = cs_builder(GMAP)
% CS_BUILDER - Build a graph G and its NODEMAP from a given GMAP.
%
% Brad McRae, Viral B. Shah (C) 2006-08. All rights reserved.
%
% $Id: cs_builder.m 31 2007-05-01 19:36:23Z viral $

global options;

cs_time ('Building graph');

[nrow, ncol] = size (GMAP);
numnodes = nnz(GMAP);
if options.usingStarP
    numnodes = nnz(GMAP)*p;
    nrow = nrow*p;
    ncol = ncol*p;

    % find() in StarP and matlab return in different orders when
    % turning Strict Matlab Compatibility off.
    ppsetoption ('StrictMatlabCompat','off')
    [I J] = find (GMAP);
    NODEMAP = sparse (I, J, 1:numnodes, nrow, ncol);
else
    [I J] = find (GMAP');
    NODEMAP = sparse (J, I, 1:numnodes, nrow, ncol);
end

% 4-point stencil
[node1, node2, g1, g2] = get_conductances (NODEMAP, GMAP, nrow, ncol);

if (options.avgResistanceFlag) 
    conductances = 1 ./((1./g1 + 1./g2) / 2);
else
    conductances = ((g1 + g2) / 2);
end
G = sparse (node1, node2, conductances, numnodes, numnodes);
G=G+G';

if (~options.fourNeighborFlag) %Need to add diagonals 
    % 8-point stencil
    GMAP_UL = GMAP(1:end-1,1:end-1); %upper left
    GMAP_DR = GMAP(2:end,2:end); %lower right
    GMAP_UDR = GMAP_UL & GMAP_DR;
    S_DR = find ([GMAP_UDR sparse(nrow-1,1); sparse(1,ncol)]); %source nodes- diagonal lower left
    T_DR = find ([sparse(1,ncol); sparse(nrow-1,1) GMAP_UDR]); %target nodes- diagonal lower left

    GMAP_UR = GMAP(1:end-1,2:end); %upper right
    GMAP_DL = GMAP(2:end,1:end-1); %lower left
    GMAP_UDL = GMAP_UR & GMAP_DL;
    S_DL = find ([sparse(nrow-1,1) GMAP_UDL; sparse(1,ncol)]);
    T_DL = find ([sparse(1,ncol); GMAP_UDL sparse(nrow-1, 1)]);

    SD = [S_DR; S_DL];
    TD = [T_DR; T_DL];

    node1 = NODEMAP(SD);
    node2 = NODEMAP(TD);
    g1 = GMAP(SD);
    g2 = GMAP(TD);

    if(options.avgResistanceFlag)
        GD = sparse (node1, node2, 1 ./(sqrt(2)*(1./g1 + 1./g2) / 2), numnodes, numnodes);
    else
        GD = sparse (node1, node2, ((g1 + g2) / (2*sqrt(2))), numnodes, numnodes);
    end
    G=G+GD+GD';

end


fprintf ('              : Graph has %d nodes.\n', length(G));

end % End of cs_builder

function [S_HORIZ, T_HORIZ] = get_horiz_neighbors(GMAP, nrow)
GMAP_L = GMAP(:,1:end-1);
GMAP_R = GMAP(:,2:end);
GMAP_LR = GMAP_L & GMAP_R;
S_HORIZ = find ([GMAP_LR sparse(nrow,1)]);
T_HORIZ = find ([sparse(nrow,1) GMAP_LR]);
end

function [S_VERT, T_VERT] = get_vert_neighbors(GMAP, ncol)
GMAP_U = GMAP(1:end-1,:);
GMAP_D = GMAP(2:end,:);
GMAP_UD = GMAP_U & GMAP_D;
S_VERT = find ([GMAP_UD; sparse(1,ncol)]);
T_VERT = find ([sparse(1,ncol); GMAP_UD]);
end

function [node1, node2, g1, g2] = get_conductances (NODEMAP, GMAP, nrow, ncol)

[S_HORIZ, T_HORIZ] = get_horiz_neighbors (GMAP, nrow);
[S_VERT, T_VERT] = get_vert_neighbors (GMAP, ncol);

S = [S_HORIZ; S_VERT];
node1 = NODEMAP(S);
g1 = GMAP(S);

T = [T_HORIZ; T_VERT];
node2 = NODEMAP(T);
g2 = GMAP(T);
end
