function cs_time (banner)
% CS_TIME - Print current time.
%
% Brad McRae, Viral B. Shah (C) 2006-08. All rights reserved.
%
% $Id: cs_time.m 24 2007-04-27 23:10:25Z viral $

c=clock;
hour=round(c(4));
min=round(c(5));
minstr=num2str(min);
SIZEMIN=size(minstr);
sizemin=SIZEMIN(2);

if sizemin==1
  fprintf('\nTime is %2d:0%d: %s.\n', hour, min, banner)
else
  fprintf('\nTime is %2d:%d : %s.\n', hour, min, banner)
end
