function cs_allsrc_onegnd(G, NODEMAP, POINTS_RC, GROUNDS_RC)
% CS - MULTIPLE_ENGINE - handles multiple source/multiple ground problems
%
%
% Brad McRae, Viral B. Shah (C) 2006-08. All rights reserved.
%
% $Id: cs.m 29 2007-04-30 01:58:13Z viral $

global options

% Set up SOURCES and GROUNDS
[SOURCES GROUNDS]=cs_multiple_setup(G, NODEMAP, GROUNDS_RC, POINTS_RC);

% Make G Laplacian for solving linear systems.
G = cs_laplacian(G);

if options.curMapFlag
    CUMCURRMAP=zeros(options.nrow,options.ncol);
    writeCumFlag=0;
end


numnodes=size(G,1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[i,j,val]=find(GROUNDS);
GROUNDLIST(:,1)=i;
GROUNDLIST(:,2)=val;
clear i j val;
if(size(GROUNDLIST,1))<1
    error('No valid ground points')
end
    
for groundPoint=1:size(GROUNDLIST,1)
    groundNode=GROUNDLIST(groundPoint,1);
    SOURCESTEMP=SOURCES;
    if(SOURCESTEMP(groundNode))%Potential conflict
        if strcmp(options.rmvSrcGnd,'rmvSrc'); %'keepAll';  'rmvGnd';
            SOURCESTEMP(groundNode)=0;  %Source will also be removed if ground connection is direct in next step.
        end
    end
    GTEMP=G;
    if GROUNDLIST(groundPoint,2)==Inf
        GTEMP(groundNode,:)=[];
        GTEMP(:,groundNode)=[];
        SOURCESTEMP(groundNode)=[];
        INFGROUNDLIST=groundNode;
        FINITEGROUNDS=zeros(size(GROUNDS));
    else
        GTEMP(groundNode,groundNode)=GTEMP(groundNode,groundNode)+GROUNDLIST(groundPoint,2);
        INFGROUNDLIST=[];
        FINITEGROUNDS=zeros(size(GROUNDS));
        FINITEGROUNDS(groundNode)=GROUNDLIST(groundPoint,2);
    end

    numsources=nnz(SOURCESTEMP);
    if numsources<1
        fprintf('\nNo valid source or source conflicts with a ground.  Skipping iteration.\n')
    else
        VOLTAGES=cs_multiple_solver(SOURCESTEMP,GTEMP,INFGROUNDLIST);

        if groundPoint==size(GROUNDLIST,1)
            writeCumFlag=1;
        end

        if options.curMapFlag
            pt1='allsrc';
            pt2=groundPoint;
            pt2=num2str(pt2);
            pt2=strcat('gnd',pt2);
            G_GRAPH = (G - diag(sparse(diag(G))));
            CUMCURRMAP=cs_current_map(pt1,pt2,VOLTAGES,FINITEGROUNDS,G_GRAPH,NODEMAP,CUMCURRMAP,writeCumFlag);
            clear G_GRAPH
        end
        if options.voltMapFlag
            cs_voltage_map(pt1,pt2,VOLTAGES,NODEMAP,numnodes)
        end
    end


    clear GTEMP SOURCESTEMP INFGROUNDLIST
end

