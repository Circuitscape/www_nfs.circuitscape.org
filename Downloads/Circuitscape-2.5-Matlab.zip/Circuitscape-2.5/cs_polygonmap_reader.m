function [POLYGONMAP]=cs_polygonmap_reader

global options;

if exist(options.polygonFile)
    [POLYGONMAP  poly_ncol poly_nrow poly_xllcorner poly_yllcorner poly_cellsize options.poly_NODATA_value] = cs_ascii_reader(options.polygonFile);

    if poly_ncol ~= options.ncol
        error('Habitat and short-circuit region map coordinates do not match')
    elseif poly_nrow ~= options.nrow
        error('Habitat and short-circuit region map coordinates do not match')
    elseif poly_xllcorner ~= options.xllcorner
        error('Habitat and short-circuit region map coordinates do not match')
    elseif poly_yllcorner ~= options.yllcorner
        error('Habitat and short-circuit region map coordinates do not match')
    elseif poly_cellsize ~= options.cellsize
        error('Habitat and short-circuit region map coordinates do not match')
    end

    SIZEPOLYGONS=size(POLYGONMAP); %Sometimes get extra column
    polygons_ncols=SIZEPOLYGONS(2);
    if options.ncol < polygons_ncols
        POLYGONMAP(:,polygons_ncols)=[];
    end
else
    error('Polygon file does not exist')
end

% CHANGE poly_NODATA_value to 0 in POLYGONMAP
POLYGONMAP(POLYGONMAP == options.poly_NODATA_value) = 0;
POLYGONMAP = sparse(POLYGONMAP);

if options.usingStarP
    POLYGONMAP = ppback(POLYGONMAP, 1);
end
