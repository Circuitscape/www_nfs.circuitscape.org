function [SOURCES GROUNDS]=cs_multiple_setup(G, NODEMAP, GROUNDS_RC, POINTS_RC) 
% CS - MULTIPLE_SETUP - creates SOURCES and GROUNDS for multiple ground
% scenarios
%
%
% Brad McRae, Viral B. Shah (C) 2006-08. All rights reserved.
%
% $Id: cs.m 29 2007-04-30 01:58:13Z viral $

global options


%FORMATS
%POINTS_RC 
%ID row col value nodenumber (ID is 0 if GIS format used).
%GROUNDS_RC
%ID row col value nodenumber (ID is 0 if GIS format used).

%Place node number in 5th column of point and ground files
numGrounds = size (GROUNDS_RC, 1);

numnodes=size(G,1);
for groundPoint=1:numGrounds
    row=GROUNDS_RC(groundPoint,2);
    col=GROUNDS_RC(groundPoint,3);
    groundNode=NODEMAP(row,col);
    GROUNDS_RC(groundPoint,5)=groundNode;
end

numPoints= size (POINTS_RC, 1);
for sourcePoint=1:numPoints
    row=POINTS_RC(sourcePoint,2);
    col=POINTS_RC(sourcePoint,3);
    sourceNode=NODEMAP(row,col);
    POINTS_RC(sourcePoint,5)=sourceNode;
end

%Convert GROUNDS_RC to conductance format
if options.groundRorC==1
    warning off;
    GROUNDS_RC(:,4)=1./GROUNDS_RC(:,4);
    warning on;
end



%Create vectors of grounds and sources for all nodes in system
%remove dropped nodes from POINTS_RC and GROUNDS_RC
POINTS_RC=POINTS_RC(POINTS_RC(:,5)>0,:);
GROUNDS_RC=GROUNDS_RC(GROUNDS_RC(:,5)>0,:);

SOURCES=sparse(zeros(numnodes,1));
GROUNDS=sparse(zeros(numnodes,1));
SOURCES(POINTS_RC(:,5))=POINTS_RC(:,4);%If a node appears more than once, the first instance(s) in POINTS_RC will be lost.
GROUNDS(GROUNDS_RC(:,5))=GROUNDS_RC(:,4);%If a node appears more than once, the first instance(s) in GROUNDS_RC will be lost.

%Remake source and ground vectors depending on input options
if options.unitCurrents==1;
    SOURCES = sparse(SOURCES&SOURCES);
end

if options.directGrounds==1;
    GROUNDS(GROUNDS>0)=Inf;
end

if length(SOURCES)<1
    error('\nNo valid sources\n')
end
if length(GROUNDS)<1
    error('\nNo valid grounds\n')
end