function [POINTS_RC] = cs_pointfile_reader

global options

pointFile=options.pointFile;
if exist(options.pointFile)
    %    if(options.gridFlag) %GRID POINT FILE FORMAT- Needs neatening up
    if strcmp(cs_extension(pointFile),'.asc')
        [POINTS_GIS pts_ncol pts_nrow pts_xllcorner pts_yllcorner pts_cellsize pts_NODATA_value] = cs_ascii_reader(options.pointFile);

        if pts_ncol ~= options.ncol
            fprintf('\nWARNING: Habitat and source map coordinates do not match.  Some sources may be removed.\n')
        elseif pts_nrow ~= options.nrow
            fprintf('\nWARNING: Habitat and source map coordinates do not match.  Some sources may be removed.\n')
        elseif pts_xllcorner ~= options.xllcorner
            fprintf('\nWARNING: Habitat and source map coordinates do not match.  Some sources may be removed.\n')
        elseif pts_yllcorner ~= options.yllcorner
            fprintf('\nWARNING: Habitat and source map coordinates do not match.  Some sources may be removed.\n')
        elseif pts_cellsize ~= options.cellsize
            fprintf('\nWARNING: Habitat and source map coordinates do not match.  Some sources may be removed.\n')
        end

        %Convert POINTS_GIS to POINTS_TEMP
        numpoints=0;
        for row=1:pts_nrow %changed from nrow to pts_nrow
            for col=1:pts_ncol %changed from nrow to pts_nrow
                if POINTS_GIS(row,col)>0
                    numpoints=numpoints+1;
                    x_coord=pts_xllcorner+pts_cellsize*(col-1)+pts_cellsize/2; %changed pts_cellsize pts_xllcorner
                    y_coord=pts_yllcorner+pts_cellsize*(pts_nrow-row)+pts_cellsize/2;%changed from nrow to pts_nrow pts_cellsize pts_yllcorner too
                    POINTS_TEMP(numpoints,1)=POINTS_GIS(row,col);
                    POINTS_TEMP(numpoints,2)=x_coord;
                    POINTS_TEMP(numpoints,3)=y_coord;
                end
            end
        end

            
        %Sort POINTS_TEMP to create POINTS
        [x, i] = sort(POINTS_TEMP(:,1)); %BHM 040908
         POINTS = POINTS_TEMP(i,:);
         clear x i
         if strcmp(options.scenario,'pairwise')
             POINTS(:,4)=1;
         else
            POINTS(:,4)=POINTS(:,1); %We are reading current values in advanced scenarios, which go in col 4
            POINTS(:,1)=0;
         end
             
        
    elseif strcmp(cs_extension(pointFile),'.txt')%TEXT LIST OF POINT COORDINATES
        POINTS = textread(options.pointFile, '', 'headerlines', 1);
    else
        error('Current source file must have .asc or .txt extension')
    end

    %Convert POINTS file into row, column format POINTS_RC
    POINTS_RC(:,1)=POINTS(:,1);
    POINTS_RC(:,2)=ceil(options.nrow-(POINTS(:,3)-options.yllcorner)/options.cellsize);
    POINTS_RC(:,3)=ceil((POINTS(:,2)-options.xllcorner)/options.cellsize);

    if size(POINTS,2)>3%if there is a value column in POINTS
        POINTS_RC(:,4)=POINTS(:,4);
    else
        POINTS_RC(:,4)=1;
    end
    if strcmp(options.scenario,'pairwise')
    POINTS_RC(:,4) = 1;  %Denotes that point is used.  Will change to 0 if point is dropped.
        if size(POINTS_RC, 1) < 2
            error('Less than two source/ground points! \n')
        end
    end

    % DROP POINTS THAT LIE OUTSIDE OF CELLMAP
    [row,col]=find(POINTS_RC(:,2)<1);
    POINTS_RC(row,:)=[];
    [row,col]=find(POINTS_RC(:,2)>options.nrow);
    POINTS_RC(row,:)=[];

    [row,col]=find(POINTS_RC(:,3)<1);
    POINTS_RC(row,:)=[];
    [row,col]=find(POINTS_RC(:,3)>options.ncol);
    POINTS_RC(row,:)=[];

    
    numPoints=size(POINTS_RC, 1);
    if numPoints < 1
        error('No valid current source points in current source file')
    end


else
    if strcmp(options.scenario,'pairwise')
        error('Source/ground point file does not exist! \n')
    else
        error('Source point file does not exist! \n')
    end
end

%POINTS_RC format passed out of this module: ID row col val (val=1 for
%pairwise)
%In solver, format for pairwise scenario is:
%ID row col nodenumber
%In solver, format for multiple scenarios is:
%ID row col value nodenumber (ID is 0 if GIS format used).
%0 is not an allowable ID for input files- will be ignored.