curdir = pwd;
hypre_package = strcat (pwd, '/Hypre/hypre_interface.so');
pploadpackage (hypre_package);



