#include <mpi.h>
#include "Starp.h"
#include "_hypre_utilities.h"
#include "HYPRE_krylov.h"
#include "HYPRE.h"
#include "HYPRE_parcsr_ls.h"

using namespace std;

static void hypre_pcg_amg (starp_sdk_t &sdk, starp_value_vector_t const & inArgs, 
			   starp_value_vector_t & outArgs)
{
  try {
    int rank, nproc;
    MPI_Comm_rank (MPI_COMM_WORLD, &rank);
    MPI_Comm_size (MPI_COMM_WORLD, &nproc);

    matrix_ptr_t mA = inArgs.at(0).distributed_value();
    const PPcsr *Store = (PPcsr *) mA->local_sparse_data();
    idx_t nnz_loc = Store->nnz_loc;
    idx_t m_loc = Store->m_loc;
    idx_t *rowptr = (idx_t*) Store->rowptr; 
    idx_t *colind = (idx_t *) Store->colind; 
    starp_double_t *nzval = (starp_double_t *) Store->nzval;

    matrix_ptr_t mX = inArgs.at(1).distributed_value();
    starp_double_t *mX_data = mX->local_dense_data<starp_double_t>();

    matrix_ptr_t mB = inArgs.at(2).distributed_value();
    starp_double_t *mB_data = mB->local_dense_data<starp_double_t>();

    starp_size_vector_t gsizeA = mA->layout_desc().global_size_array();
    int gColsA = static_cast<int> (gsizeA[1]);

    const starp_double_t *layoutA_dbl = inArgs.at(3).array_value<starp_double_t>();
    int layoutA[nproc+1];
    for (int i=0;i<=nproc; ++i) layoutA[i] = static_cast<int> (layoutA_dbl[i]);

    HYPRE_IJMatrix A;
    HYPRE_ParCSRMatrix parcsr_A;
    HYPRE_IJVector b;
    HYPRE_ParVector par_b;
    HYPRE_IJVector x;
    HYPRE_ParVector par_x;

    /* Create the matrix.
       Note that this is a square matrix, so we indicate the row partition
       size twice (since number of rows = number of cols) */
    HYPRE_IJMatrixCreate (MPI_COMM_WORLD, 
			  layoutA[rank], layoutA[rank+1] - 1,
			  layoutA[rank], layoutA[rank+1] - 1,
			  &A);

    /* Choose a parallel csr format storage */
    HYPRE_IJMatrixSetObjectType(A, HYPRE_PARCSR);

    /* Initialize before setting coefficients */
    HYPRE_IJMatrixInitialize(A);

    int *hypre_col = new int[gColsA];
    double *hypre_val = new double[gColsA];
    for (int i=0; i<m_loc; ++i) {
      int row = i + layoutA[rank];
      int k = 1;
      for (int j=rowptr[i]; j<rowptr[i+1]; ++j) {
	if (row == colind[j]) { // diagonal element
	  hypre_col[0] = static_cast<int> (row);
	  hypre_val[0] = static_cast<double> (nzval[j]);
	} else {
	  hypre_col[k] = static_cast<int> (colind[j]);
	  hypre_val[k] = static_cast<double> (nzval[j]);
	  ++k;
	}
      }

      HYPRE_IJMatrixSetValues (A, 1, &k, &row, hypre_col, hypre_val);
    }
    delete [] hypre_col;
    delete [] hypre_val;

    /* Assemble after setting the coefficients */
    HYPRE_IJMatrixAssemble(A);

    /* Get the parcsr matrix object to use */
    HYPRE_IJMatrixGetObject(A, (void**) &parcsr_A);

    /* Create the rhs and solution */
    HYPRE_IJVectorCreate(MPI_COMM_WORLD, layoutA[rank], layoutA[rank+1] - 1, &b);
    HYPRE_IJVectorSetObjectType(b, HYPRE_PARCSR);
    HYPRE_IJVectorInitialize(b);

    HYPRE_IJVectorCreate(MPI_COMM_WORLD, layoutA[rank], layoutA[rank+1] - 1, &x);
    HYPRE_IJVectorSetObjectType(x, HYPRE_PARCSR);
    HYPRE_IJVectorInitialize(x);

    /* Setup solution and RHS */
    int *rows = new int[m_loc];
    for (int i=0; i<m_loc; ++i) {
      rows[i] = i + layoutA[rank];
    }

    HYPRE_IJVectorSetValues(b, m_loc, rows, mB_data);
    HYPRE_IJVectorSetValues(x, m_loc, rows, mX_data);

    /* Assemble RHS */
    HYPRE_IJVectorAssemble(b);
    HYPRE_IJVectorGetObject(b, (void **) &par_b);

    /* Assemble solution vector */
    HYPRE_IJVectorAssemble(x);
    HYPRE_IJVectorGetObject(x, (void **) &par_x);

    //HYPRE_IJMatrixPrint(A, "IJ.out.A");
    //HYPRE_IJVectorPrint(b, "IJ.out.b");

    /* Choose a solver and solve the system */
    /* AMG */
    int num_iterations;
    double final_res_norm;

    /* Create solver */
    HYPRE_Solver solver, precond;
    HYPRE_ParCSRPCGCreate(MPI_COMM_WORLD, &solver);

    /* Set some parameters (See Reference Manual for more parameters) */
    HYPRE_PCGSetMaxIter(solver, 1000); /* max iterations */
    HYPRE_PCGSetTol(solver, 1e-7); /* conv. tolerance */
    HYPRE_PCGSetTwoNorm(solver, 1); /* use the two norm as the stopping criter
				       ia */
    HYPRE_PCGSetPrintLevel(solver, 2); /* print solve info */
    HYPRE_PCGSetLogging(solver, 1); /* needed to get run info later */

    /* Now set up the AMG preconditioner and specify any parameters */
    HYPRE_BoomerAMGCreate(&precond);
    HYPRE_BoomerAMGSetPrintLevel(precond, 1); /* print amg solution info */
    HYPRE_BoomerAMGSetCoarsenType(precond, 6);
    HYPRE_BoomerAMGSetRelaxType(precond, 6); /* Sym G.S./Jacobi hybrid */ 
    HYPRE_BoomerAMGSetNumSweeps(precond, 1);
    HYPRE_BoomerAMGSetTol(precond, 0.0); /* conv. tolerance zero */
    HYPRE_BoomerAMGSetMaxIter(precond, 1); /* do only one iteration! */

    /* Set the PCG preconditioner */
    HYPRE_PCGSetPrecond(solver, (HYPRE_PtrToSolverFcn) HYPRE_BoomerAMGSolve,
			(HYPRE_PtrToSolverFcn) HYPRE_BoomerAMGSetup, precond);

    /* Now setup and solve! */
    HYPRE_ParCSRPCGSetup(solver, parcsr_A, par_b, par_x);
    HYPRE_ParCSRPCGSolve(solver, parcsr_A, par_b, par_x);

    HYPRE_PCGGetNumIterations(solver, &num_iterations);
    HYPRE_PCGGetFinalRelativeResidualNorm(solver, &final_res_norm);
    if (rank == 0)
      {
	printf("\n");
	printf("Iterations = %d\n", num_iterations);
	printf("Final Relative Residual Norm = %e\n", final_res_norm);
	printf("\n");
      }

    /* Destroy solver and preconditioner */
    HYPRE_ParCSRPCGDestroy(solver);
    HYPRE_BoomerAMGDestroy(precond);

    //HYPRE_IJVectorPrint(x, "IJ.out.x");

    starp_double_t *x_vals = new starp_double_t[m_loc];
    HYPRE_IJVectorGetValues (x, m_loc, rows, x_vals);
    for (int i=0; i<m_loc; ++i) {
      mX_data[i] = x_vals[i];
    }
    delete [] rows;
    delete [] x_vals;
  
    /* Clean up */
    HYPRE_IJMatrixDestroy(A);
    HYPRE_IJVectorDestroy(b);
    HYPRE_IJVectorDestroy(x);
  }
  catch (exception& e) {
    cerr <<  "********* caught exception [" << e.what() << "] ********" << endl 
	 << flush;
    sdk.set_error(e.what());
  }

  return;
}

extern "C" bool starpInit (starp_sdk_t &sdk) 
{
  sdk.register_func ("hypre_pcg_amg", &hypre_pcg_amg);
        
  return true;  // Return 0 to indicate no error
}
