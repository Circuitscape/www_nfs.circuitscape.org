function [x, iter, relres] = Hypre_PCG_BAMG (G, rhs)

     [x, iter, relres] = ppclient('hypre_pcg_amg', G, rhs, pplayout(length(G)));

return;
