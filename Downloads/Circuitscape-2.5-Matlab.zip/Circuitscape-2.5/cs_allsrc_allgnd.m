function cs_allsrc_allgnd(G, NODEMAP, POINTS_RC, GROUNDS_RC)
% CS - MULTIPLE_ENGINE - handles multiple source/multiple ground problems
%
%
% Brad McRae, Viral B. Shah (C) 2006-08. All rights reserved.
%
% $Id: cs.m 29 2007-04-30 01:58:13Z viral $

global options

% Set up SOURCES and GROUNDS
[SOURCES GROUNDS]=cs_multiple_setup(G, NODEMAP, GROUNDS_RC, POINTS_RC) ;

% Make G Laplacian for solving linear systems.
G = cs_laplacian(G);

if options.curMapFlag
    CUMCURRMAP=zeros(options.nrow,options.ncol);
    writeCumFlag=0;
end

numnodes=size(G,1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
SOURCESTEMP=SOURCES;
GROUNDSTEMP=GROUNDS;
CONFLICTS=SOURCESTEMP&GROUNDSTEMP;
if strcmp(options.rmvSrcGnd,'rmvSrc')
    SOURCESTEMP(CONFLICTS==1)=0;
elseif strcmp(options.rmvSrcGnd,'rmvGnd')
    GROUNDSTEMP(CONFLICTS==1)=0;
end
GROUNDSTEMP(SOURCESTEMP&(GROUNDSTEMP==Inf))=0;%Remove grounds directly connected to sources
GTEMP=G;

%add in finite grounds to GTEMP
FINITEGROUNDS=GROUNDSTEMP;
FINITEGROUNDS(FINITEGROUNDS==Inf)=0;
GTEMP=sparse(GTEMP+sparse(diag(FINITEGROUNDS)));

[i,j,val]=find(GROUNDSTEMP==Inf);
if i%if there are nonempty entries
    INFGROUNDLIST(:,1)=i; %this will be used to both remove entries from GTEMP and reconstitute VOLTAGES
    clear i j val;
else
    INFGROUNDLIST=[];
end
numInfGrounds=size(INFGROUNDLIST,1);

for infGround=numInfGrounds:-1:1 %count backwards, remove entries
    GTEMP(INFGROUNDLIST(infGround),:)=[];
    GTEMP(:,INFGROUNDLIST(infGround))=[];
    SOURCESTEMP(INFGROUNDLIST(infGround))=[];
end

if sum(SOURCESTEMP)==0
    error('No current source points entered or all source points conflict with grounds')
end
if size(GTEMP)==0
    error('G-matrix is empty after processing')
end
if numInfGrounds+nnz(FINITEGROUNDS)<1
    error('No ground points entered or all ground points conflict with sources')
end

VOLTAGES=cs_multiple_solver(SOURCESTEMP,GTEMP,INFGROUNDLIST);

if options.curMapFlag
    pt1='allsrc';
    pt2='allgnd';
    G_GRAPH = (G - diag(sparse(diag(G))));
    CUMCURRMAP=cs_current_map(pt1,pt2,VOLTAGES,FINITEGROUNDS,G_GRAPH,NODEMAP,CUMCURRMAP,writeCumFlag);
    clear G_GRAPH
end
if options.voltMapFlag
    cs_voltage_map(pt1,pt2,VOLTAGES,NODEMAP,numnodes)
end

clear GTEMP SOURCESTEMP INFGROUNDLIST FINITEGROUNDS GROUNDSTEMP

