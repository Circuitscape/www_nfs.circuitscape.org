function RESISTANCES = cs_main
% CS - Main routine for circuitscape.
%
%
% Brad McRae, Viral B. Shah (C) 2006-08. All rights reserved.
%
% $Id: cs.m 29 2007-04-30 01:58:13Z viral $

global options


[GMAP, POLYGONMAP, POINTS_RC, GROUNDS_RC] = cs_read_files; %BHM 040108

image(0);
axis image;
box on;
%axis equal;
%axis tight;
%axis off;

cs_spy (GMAP, 'y');

% Build Graph and Nodemap
[G, NODEMAP] = cs_builder (GMAP);

% Consolidate polygons
if(options.polygonFlag)
    [G, NODEMAP] = cs_polygons (G, NODEMAP, POLYGONMAP);
    cs_spy (POLYGONMAP, 'g');
end

% Prune disconnected parts of the graph.
[G, NODEMAP] = cs_node_pruner (G, NODEMAP, POINTS_RC);
cs_spy (spones(NODEMAP)-spones(GMAP), 'r')


%Write log file
cs_logwriter(G);


% Compute resistances, current, and/or voltage
if strcmp(options.scenario,'pairwise');
    RESISTANCES = cs_pairwise_solver (G, NODEMAP, POINTS_RC);
elseif strcmp(options.scenario,'oneSrcAllGnd')
    cs_onesrc_allgnd(G, NODEMAP, POINTS_RC, GROUNDS_RC);
    RESISTANCES=0;
elseif strcmp(options.scenario,'allSrcOneGnd')
    cs_allsrc_onegnd(G, NODEMAP, POINTS_RC, GROUNDS_RC);
    RESISTANCES=0;
else
    cs_allsrc_allgnd(G, NODEMAP, POINTS_RC, GROUNDS_RC);
    RESISTANCES=0;
end


