function [GMAP, POLYGONMAP, POINTS_RC, GROUNDS_RC] =  cs_read_files %(options)
% CS_READER - Read data from files.
%
% Brad McRae, Viral B. Shah (C) 2006-08. All rights reserved.
%
% $Id: cs_reader.m 22 2007-04-27 23:06:42Z viral $

global options;

POLYGONMAP=0; %This will be returned if options.polygonFlag is not set.
GROUNDS_RC=0;  %This will be returned if options.scenario is pairwise.

%CELLS
cs_time ('Reading cell file');
GMAP=cs_cellmap_reader;

%POLYGONS
if(options.polygonFlag)
    cs_time ('Reading short-circuit region file');
    POLYGONMAP = cs_polygonmap_reader;
end

%SOURCES
if strcmp(options.scenario,'pairwise');
    cs_time ('Reading source/ground location file');
else
    cs_time ('Reading current source location file');
end
POINTS_RC = cs_pointfile_reader;

%GROUNDS
if ~strcmp(options.scenario,'pairwise')
    cs_time ('Reading ground point location file');
    GROUNDS_RC=cs_groundfile_reader;
end