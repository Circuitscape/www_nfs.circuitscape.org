function ext=cs_extension(fileName)

%returns last four characters in a filename
% Brad McRae, Viral B. Shah (C) 2006-08. All rights reserved.
sizeFileName=length(fileName);
if sizeFileName > 4
    ext = fileName(sizeFileName-3:sizeFileName);
else
    ext=0;
end