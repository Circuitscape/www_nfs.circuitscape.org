function [GROUNDS_RC] = cs_groundfile_reader

global options

groundFile=options.groundFile;
if exist(options.groundFile)
    %    if(options.gridFlag) %GRID GROUND FILE FORMAT- Needs neatening up
    if strcmp(cs_extension(groundFile),'.asc')
        [GROUNDS_GIS grounds_ncol grounds_nrow grounds_xllcorner grounds_yllcorner grounds_cellsize grounds_NODATA_value] = cs_ascii_reader(options.groundFile);

        if grounds_ncol ~= options.ncol
            fprintf('\nWARNING: Habitat and ground map coordinates do not match. Some grounds may be removed.\n')
        elseif grounds_nrow ~= options.nrow
            fprintf('\nWARNING: Habitat and ground map coordinates do not match. Some grounds may be removed.\n')
        elseif grounds_xllcorner ~= options.xllcorner
            fprintf('\nWARNING: Habitat and ground map coordinates do not match. Some grounds may be removed.\n')
        elseif grounds_yllcorner ~= options.yllcorner
            fprintf('\nWARNING: Habitat and ground map coordinates do not match. Some grounds may be removed.\n')
        elseif grounds_cellsize ~= options.cellsize
            fprintf('\nWARNING: Habitat and ground map coordinates do not match. Some grounds may be removed.\n')
        end

        %Convert GROUNDS_GIS to GROUNDS_TEMP
        numgrounds=0;
        for row=1:grounds_nrow
            for col=1:grounds_ncol
                if GROUNDS_GIS(row,col)>=0
                    numgrounds=numgrounds+1;
                    x_coord=grounds_xllcorner+grounds_cellsize*(col-1)+grounds_cellsize/2;
                    y_coord=grounds_yllcorner+grounds_cellsize*(grounds_nrow-row)+grounds_cellsize/2;
                    GROUNDS_TEMP(numgrounds,1)=0; %No identifier for GIS format, just ground value.

                    if options.directGrounds==0;
                        GROUNDS_TEMP(numgrounds,4)=GROUNDS_GIS(row,col); %This will be ground value unless direct ground connections selected.
                    else %direct grounds- set ground values to zero resistances
                        options.groundRorC=1;
                        GROUNDS_TEMP(numgrounds,4)=0;
                    end

                    GROUNDS_TEMP(numgrounds,2)=x_coord;
                    GROUNDS_TEMP(numgrounds,3)=y_coord;
                end
            end
        end

        if numgrounds>0
            GROUNDS=GROUNDS_TEMP;
        else
            error('No valid ground points in grounds file')
        end

    elseif strcmp(cs_extension(groundFile),'.txt')%TEXT LIST OF GROUND COORDINATES- ID X Y GNDVAL
        GROUNDS = textread(options.groundFile, '', 'headerlines', 1);
        if options.directGrounds==1;
            options.groundRorC=1;
            GROUNDS(:,4)=0;
        end

    else
        error('Current source file must have .asc or .txt extension')
    end

    %Convert GROUNDS file into row, column format GROUNDS_RC
    GROUNDS_RC(:,1)=GROUNDS(:,1);
    GROUNDS_RC(:,2)=ceil(options.nrow-(GROUNDS(:,3)-options.yllcorner)/options.cellsize);
    GROUNDS_RC(:,3)=ceil((GROUNDS(:,2)-options.xllcorner)/options.cellsize);
    GROUNDS_RC(:,4)=GROUNDS(:,4);

    % DROP GROUNDS THAT LIE OUTSIDE OF CELLMAP
    [row,col]=find(GROUNDS_RC(:,2)<1);
    GROUNDS_RC(row,:)=[];
    [row,col]=find(GROUNDS_RC(:,2)>options.nrow);
    GROUNDS_RC(row,:)=[];

    [row,col]=find(GROUNDS_RC(:,3)<1);
    GROUNDS_RC(row,:)=[];
    [row,col]=find(GROUNDS_RC(:,3)>options.ncol);
    GROUNDS_RC(row,:)=[];

    numGrounds=size(GROUNDS_RC, 1);
    if numGrounds < 1
        error('No valid ground points in ground point file')
    end

else
    error('Ground file does not exist! \n')
end

