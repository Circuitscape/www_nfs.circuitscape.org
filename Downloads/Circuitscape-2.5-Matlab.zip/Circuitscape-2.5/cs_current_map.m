function   CUMCURRMAP=cs_current_map(pt1,pt2,VOLTAGES,FINITEGROUNDS,G_GRAPH,NODEMAP,CUMCURRMAP,writeCumFlag);
% Brad McRae, Viral B. Shah (C) 2006-08. All rights reserved.
%   Creates maps of current flow between source and ground points using
%   VOLTAGES calculated by solver modules
%

global options
numnodes = length (G_GRAPH);
[NODE1,NODE2,CONDUCTANCE]=find(G_GRAPH);
VDIFF=VOLTAGES(NODE1)-VOLTAGES(NODE2);
SIZEVDIFF=size(VDIFF);
if SIZEVDIFF(1,1)==1
    VDIFF=transpose(VDIFF);%TEMPORARY- if GTEMP is dimension 1x1, get row vector instead of col vector
end

BRANCHCURRENTS_SQUARE = sparse(NODE1,NODE2,CONDUCTANCE.*VDIFF);
BRANCHCURRENTS_SQUARE_POS=BRANCHCURRENTS_SQUARE.*(BRANCHCURRENTS_SQUARE>0);
BRANCHCURRENTS_SQUARE_NEG=abs(BRANCHCURRENTS_SQUARE.*(BRANCHCURRENTS_SQUARE<0));

if isempty(BRANCHCURRENTS_SQUARE_POS)
    BRANCHCURRENTS_SQUARE_POS(1,1)=0;
end
if isempty(BRANCHCURRENTS_SQUARE_NEG)
    BRANCHCURRENTS_SQUARE_NEG(1,1)=0;
end
if sum(FINITEGROUNDS)>0
    INDIRECT_GROUND_CURRENTS=(FINITEGROUNDS.*VOLTAGES);
    BRANCHCURRENTS_SQUARE_POS=BRANCHCURRENTS_SQUARE_POS+sparse(diag(INDIRECT_GROUND_CURRENTS));
end
NODECURRENTS_POS=sum(BRANCHCURRENTS_SQUARE_POS);
NODECURRENTS_NEG=sum(BRANCHCURRENTS_SQUARE_NEG);
NODECURRENTS=max(NODECURRENTS_POS,NODECURRENTS_NEG);
[row col node] = find(NODEMAP);
CURRMAP = sparse (row, col, NODECURRENTS(node), options.nrow, options.ncol);
CURRMAP=full(CURRMAP);
CUMCURRMAP=CUMCURRMAP+CURRMAP;


output_filename=options.outFile;
SIZE=size(output_filename);
size_output_filename=SIZE(2);
outfile_root=output_filename(1:size_output_filename-4);
outfile=strcat(outfile_root,'_current_',pt1,'_',pt2,'.asc');
cs_mapwriter(CURRMAP,outfile)

if writeCumFlag==1
    outfile=strcat(outfile_root,'_cumulative_current_','.asc');
    cs_mapwriter(CUMCURRMAP,outfile)
end

plot_flag=1;
    if plot_flag==1    
        X=zeros(options.nrow,options.ncol);
        Y=X;
        for r=1:options.nrow
            Y(r,:)=r;
        end
        for c=1:options.ncol
            X(:,c)=c;
        end
                    
        figure(1)
%        LOGCURRMAP=log(CURRMAP+.0000000001);
 %       surf(Y,X,LOGCURRMAP)
        surf(Y,X,CURRMAP)
    end
