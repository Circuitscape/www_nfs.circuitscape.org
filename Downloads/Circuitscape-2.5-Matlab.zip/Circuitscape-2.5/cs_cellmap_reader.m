function [GMAP] =  cs_cellmap_reader %(options)

global options;

if exist(options.cellFile)
    [CELLMAP options.ncol options.nrow options.xllcorner options.yllcorner options.cellsize options.NODATA_value] = cs_ascii_reader(options.cellFile);
else
    error('Cell map file does not exist! \n')
end

% CHANGE NODATA_value to 0 in CELLMAP, and return GMAP
NODATA_value = options.NODATA_value;
if(options.resistanceFlag)
    GMAP=1./CELLMAP;
    if max(max(GMAP))==Inf
        error('Error- cell map has zero resistance.  This is not yet implemented.')
    end
    GMAP(CELLMAP==-1)=0;           %INFINITE RESISTANCE, ZERO CONDUCTANCE.
    GMAP(CELLMAP==NODATA_value)=0; %OUT OF MAPPED AREA, ASSUMED ZERO CONDUCTANCE
else
    GMAP=CELLMAP;
    GMAP(CELLMAP==NODATA_value)=0;%OUT OF MAPPED AREA, ASSUMED ZERO CONDUCTANCE
    GMAP(CELLMAP==-1)=Inf;
    if max(max(GMAP))==Inf
        error('Error- cell map has infinite conductance.  This is not yet implemented.')
    end
end

% Make GMAP sparse.
GMAP = sparse(GMAP);

% If Star-P present, send to backend.
if options.usingStarP
    GMAP = ppback(GMAP, 1);
end

