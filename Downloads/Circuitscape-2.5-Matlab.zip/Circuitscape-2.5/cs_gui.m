function varargout = cs_gui(varargin)
%CS_GUI M-file for cs_gui.fig
% Brad McRae, Viral B. Shah (C) 2006-08. All rights reserved.
%      CS_GUI, by itself, creates a new CS_GUI or raises the existing
%      singleton*.
%
%      H = CS_GUI returns the handle to a new CS_GUI or the handle to
%      the existing singleton*.
%
%      CS_GUI('Property','Value',...) creates a new CS_GUI using the
%      given property value pairs. Unrecognized properties are passed via
%      varargin to cs_gui_openingfcn.  This calling syntax produces a
%      warning when there is an existing singleton*.
%
%      CS_GUI('CALLBACK') and CS_GUI('CALLBACK',hObject,...) call the
%      local function named CALLBACK in CS_GUI.M with the given input
%      arguments.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help cs_gui

% Last Modified by GUIDE v2.5 25-Apr-2008 14:57:40


%SCENARIOS
%handles.scenario allSrcOneGnd, pairwise, oneSrcAllGnd, allSrcAllGnd



% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @cs_gui_OpeningFcn, ...
    'gui_OutputFcn',  @cs_gui_OutputFcn, ...
    'gui_LayoutFcn',  [], ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT
global options

% --- Executes just before cs_gui is made visible.
function cs_gui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   unrecognized PropertyName/PropertyValue pairs from the
%            command line (see VARARGIN)

% Choose default command line output for cs_gui
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes cs_gui wait for user response (see UIRESUME)
% uiwait(handles.figure1);
fprintf('Launching CIRCUITSCAPE\n')

a=imread('circuitscape.jpg');
image(a)
axis equal;
axis tight;
axis off;


%%%%%%%%%%%%%%%%%%%%%%CALL cs_options to set up options, including those modified from previous run
global options
cs_options

options.figure=handles.figure1;

%Copy options data to handles structure
handles.inDir=options.inDir;
handles.outDir=options.outDir;
handles.cellFile=options.cellFile;
handles.pointFile=options.pointFile;
handles.polygonFile=options.polygonFile;
handles.outFile=options.outFile;
handles.polygonFlag=options.polygonFlag;
handles.resistanceFlag=options.resistanceFlag;
%handles.gridFlag=options.gridFlag; %Get rid of grid flag entirely!
handles.fourNeighborFlag=options.fourNeighborFlag;
handles.curMapFlag=options.curMapFlag;
handles.voltMapFlag=options.voltMapFlag;
handles.PC=options.PC;

%New options 0408
handles.avgResistanceFlag=options.avgResistanceFlag;
handles.groundRorC=options.groundRorC;
handles.scenario=options.scenario;
handles.groundFile=options.groundFile;
handles.unitCurrents=options.unitCurrents;
handles.directGrounds=options.directGrounds;
handles.rmvSrcGnd=options.rmvSrcGnd;

guidata(hObject,handles) %SAVES THE HANDLE STRUCTURE

%Set GUI objects to reflect options


if strcmp(options.scenario,'pairwise')
    set(handles.advancedPanel,'Visible','off'); %Display polygon file browse dialog
    set(handles.SourcePanel,'Title','Source/Ground File')
else
    set(handles.advancedPanel,'Visible','on');
    set(handles.SourcePanel,'Title','Current Source File');
end

if strcmp(options.scenario,'pairwise')
    set(handles.pairwiseBtn,'Value',1);
else set(handles.pairwiseBtn,'Value',0);
end
if strcmp(options.scenario,'oneSrcAllGnd');
    set(handles.oneSrcAllGndBtn,'Value',1);
else set(handles.oneSrcAllGndBtn,'Value',0);
end
if strcmp(options.scenario,'allSrcOneGnd');
    set(handles.allSrcOneGndBtn,'Value',1);
else set(handles.allSrcOneGndBtn,'Value',0);
end
if strcmp(options.scenario,'allSrcAllGnd');
    set(handles.allSrcAllGndBtn,'Value',1);
else set(handles.allSrcAllGndBtn,'Value',0);
end

set(handles.avgResistanceBtn,'Value',options.avgResistanceFlag);
set(handles.avgConductanceBtn,'Value',abs(options.avgResistanceFlag-1));
set(handles.gndConductanceBtn,'Value',abs(options.groundRorC-1));
set(handles.gndResistanceBtn,'Value',options.groundRorC);

set(handles.GroundFile,'String',options.groundFile);
set(handles.unitCurrentBox,'Value',options.unitCurrents);
set(handles.directGndBox,'Value',options.directGrounds);

if strcmp(options.rmvSrcGnd,'keepAll')
    set(handles.keepAllBtn,'Value',1);
elseif strcmp(options.rmvSrcGnd,'rmvGnd')
    set(handles.rmvGndBtn,'Value',1);
else
    set(handles.rmvSrcBtn,'Value',1);
end

set(handles.CellFile,'String',options.cellFile)
set(handles.PointFile,'String',options.pointFile)
set(handles.PolygonFile,'String',options.polygonFile)
set(handles.OutFile,'String',options.outFile)
set(handles.ResistanceButton,'Value',options.resistanceFlag)
set(handles.ConductanceButton,'Value',abs(options.resistanceFlag-1))
%set(handles.GridButton,'Value',options.gridFlag)
%set(handles.CoordinatesButton,'Value',abs(options.gridFlag-1))
set(handles.FourNButton,'Value',options.fourNeighborFlag)
set(handles.EightNButton,'Value',abs(options.fourNeighborFlag-1))
set(handles.CurMapBox,'Value',options.curMapFlag)
set(handles.VoltMapBox,'Value',options.voltMapFlag)


%NEXT
%SET ALL OTHER CHECK BOXES AND BUTTONS
%SET EDIT BOXES

% --- Outputs from this function are returned to the command line.
function varargout = cs_gui_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function CellFile_Callback(hObject, eventdata, handles)
% hObject    handle to CellFile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of CellFile as text
%        str2double(get(hObject,'String')) returns contents of CellFile as a double
handles.cellFile=get(hObject,'String') ;
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function CellFile_CreateFcn(hObject, eventdata, handles)
% hObject    handle to CellFile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in CellFileBrowse.
function CellFileBrowse_Callback(hObject, eventdata, handles)
% hObject    handle to CellFileBrowse (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if(handles.PC)
    indir=strcat(handles.inDir,'\');
else
    indir=strcat(handles.inDir,'/');
end
[file, dir]=uigetfile({'*.asc'},'Select the Cell Map File',indir);
if dir~0
    handles.inDir=dir;
end
if file~0;
    handles.cellFile=strcat(dir,file);
    set(handles.CellFile,'String',handles.cellFile);
    guidata(hObject, handles);
end

% --- Executes during object deletion, before destroying properties.
function ResistanceButton_DeleteFcn(hObject, eventdata, handles)
% hObject    handle to ResistanceButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% --- Executes on button press in ResistanceButton.
function ResistanceButton_Callback(hObject, eventdata, handles)
% hObject    handle to ResistanceButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of ResistanceButton
set(hObject,'Value',1) %Turn on the radio Button
handles.resistanceFlag = get(hObject,'Value');
guidata(hObject, handles);

% --- Executes on button press in ConductanceButton.
function ConductanceButton_Callback(hObject, eventdata, handles)
% hObject    handle to ConductanceButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of ConductanceButton
set(hObject,'Value',1) %Turn on the radio Button
handles.resistanceFlag=abs(get(hObject,'Value')-1);
guidata(hObject, handles);


function PointFile_Callback(hObject, eventdata, handles)
% hObject    handle to PointFile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of PointFile as text
%        str2double(get(hObject,'String')) returns contents of PointFile as a double
handles.pointFile=get(hObject,'String') ;
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function PointFile_CreateFcn(hObject, eventdata, handles)
% hObject    handle to PointFile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in PointFileBrowse.
function PointFileBrowse_Callback(hObject, eventdata, handles)
% hObject    handle to PointFileBrowse (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if(handles.PC)
    indir=strcat(handles.inDir,'\');
else
    indir=strcat(handles.inDir,'/');
end
%if handles.gridFlag
%[file, dir]=uigetfile({'*.asc'},'Select an ACII Grid Source/Ground File',indir);
%else
if strcmp(handles.scenario,'pairwise')
    [file, dir]=uigetfile({'*.txt; *.asc'},'Select a Text or ACII Grid Source/Ground File',indir);
else
    [file, dir]=uigetfile({'*.txt; *.asc'},'Select a Text or ACII Grid Current Source File',indir);
end
    
%end
if dir~0
    handles.inDir=dir;
end
if file~0;
    handles.pointFile=strcat(dir,file);
    set(handles.PointFile,'String',handles.pointFile);
    guidata(hObject, handles);
end

% --- Executes on button press in GridButton.
function GridButton_Callback(hObject, eventdata, handles)
% hObject    handle to GridButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of GridButton
set(hObject,'Value',1) %Turn on the radio Button
%handles.gridFlag=get(hObject,'Value');
guidata(hObject, handles);


% --- Executes on button press in CoordinatesButton.
function CoordinatesButton_Callback(hObject, eventdata, handles)
% hObject    handle to CoordinatesButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of CoordinatesButton
set(hObject,'Value',1) %Turn on the radio Button
%handles.gridFlag=abs(get(hObject,'Value')-1);
guidata(hObject, handles);



% --- Executes during object creation, after setting all properties.
function PolygonFile_CreateFcn(hObject, eventdata, handles)
% hObject    handle to PolygonFile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function PolygonFile_Callback(hObject, eventdata, handles)
% hObject    handle to PolygonFile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of PolygonFile as text
%        str2double(get(hObject,'String')) returns contents of PolygonFile as a double
handles.polygonFile=get(hObject,'String') ;
if(handles.polygonFile)
    handles.polygonFlag=1;
else
    handles.polygonFlag=0;
end
guidata(hObject, handles);

function OutFile_Callback(hObject, eventdata, handles)
% hObject    handle to OutFile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of OutFile as text
%        str2double(get(hObject,'String')) returns contents of OutFile as a double
file=get(hObject,'String') ;
if file~=0
    ext=cs_extension(file);
    if ext(1)=='.';
        handles.outFile=file;
    else
        handles.outFile=strcat(file,'.out');
    end
else
    handles.outFile=strcat(handles.inDir,'.out');
end
set(handles.OutFile,'String',handles.outFile);

guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function OutFile_CreateFcn(hObject, eventdata, handles)
% hObject    handle to OutFile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes during object creation, after setting all properties.
function PolygonFileBrowse_CreateFcn(hObject, eventdata, handles)
% hObject    handle to PolygonFileBrowse (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% --- Executes on button press in PolygonFileBrowse.
function PolygonFileBrowse_Callback(hObject, eventdata, handles)
% hObject    handle to PolygonFileBrowse (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if(handles.PC)
    indir=strcat(handles.inDir,'\');
else
    indir=strcat(handles.inDir,'/');
end
[file, dir]=uigetfile({'*.asc'},'Select the Polygon File',indir);
if dir~0
    handles.inDir=dir;
end
if file~0;
    handles.polygonFile=strcat(dir,file);
    set(handles.PolygonFile,'String',handles.polygonFile);
    handles.polygonFlag=1; %If they browse, then load polygon
else
    if ~handles.polygonFile %if there's nothing in the box
    handles.polygonFlag=0
    end
end

guidata(hObject, handles);






% --- Executes on button press in OutFileBrowse.
function OutFileBrowse_Callback(hObject, eventdata, handles)
% hObject    handle to OutFileBrowse (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if(handles.PC)
    outdir=strcat(handles.outDir,'\');
else
    outdir=strcat(handles.outDir,'/');
end
[file, dir]=uiputfile({'*.asc; *.out; *.txt'},'Select the Output File',outdir);
if(file)
    handles.outDir=dir; 
    ext=cs_extension(file);
    %    SIZE=size(file);
    %    size_output_filename=SIZE(2);
    %    if size_output_filename > 4
    if ext(1) == '.' %Check for 3-character file extension.
        handles.outFile=strcat(dir,file);
    else
        handles.outFile=strcat(dir,file,'.out');
    end
    set(handles.OutFile,'String',handles.outFile);
    guidata(hObject, handles);
end


% --- Executes on button press in FourNButton.
function FourNButton_Callback(hObject, eventdata, handles)
% hObject    handle to FourNButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of FourNButton
set(hObject,'Value',1) %Turn on the radio Button
handles.fourNeighborFlag=1;
guidata(hObject, handles);


% --- Executes on button press in EightNButton.
function EightNButton_Callback(hObject, eventdata, handles)
% hObject    handle to EightNButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of EightNButton
set(hObject,'Value',1) %Turn on the radio Button
handles.fourNeighborFlag=0;
guidata(hObject, handles);

% --- Executes on button press in CurMapBox.
function CurMapBox_Callback(hObject, eventdata, handles)
% hObject    handle to CurMapBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of CurMapBox
handles.curMapFlag=get(hObject,'Value');
guidata(hObject, handles);

% --- Executes on button press in VoltMapBox.
function VoltMapBox_Callback(hObject, eventdata, handles)
% hObject    handle to VoltMapBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of VoltMapBox
handles.voltMapFlag=get(hObject,'Value');
guidata(hObject, handles);

% --- Executes on button press in CalcButton.
function CalcButton_Callback(hObject, eventdata, handles)
% hObject    handle to CalcButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global options

cs_options(handles) %Extract options from handle structure and add other options like usingStarP
guidata(hObject, handles);
save cs_options.mat options
R=cs_main;
if length(R)>1
    if length(R)<100
        R
    end
end
fprintf('\nCalculations complete.\n')
return


% --- Executes during object creation, after setting all properties.
function axes4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to axes4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate axes4


% --- Executes on button press in verifyBtn.
function verifyBtn_Callback(hObject, eventdata, handles)
% hObject    handle to verifyBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
cs_verify;



% --- Executes on selection change in unitCurrentBox.
function unitCurrentBox_Callback(hObject, eventdata, handles)
% hObject    handle to unitCurrentBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns unitCurrentBox contents as cell array
%        contents{get(hObject,'Value')} returns selected item from unitCurrentBox
handles.unitCurrents=get(hObject,'Value');
guidata(hObject, handles);
    
    

% --- Executes during object creation, after setting all properties.
function unitCurrentBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to unitCurrentBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function groundFile_Callback(hObject, eventdata, handles)
% hObject    handle to groundFile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of groundFile as text
%        str2double(get(hObject,'String')) returns contents of groundFile as a double
handles.groundFile=get(hObject,'String') ;
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function groundFile_CreateFcn(hObject, eventdata, handles)
% hObject    handle to groundFile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in gndFileBrowse.
function gndFileBrowse_Callback(hObject, eventdata, handles)
% hObject    handle to gndFileBrowse (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if(handles.PC)
    indir=strcat(handles.inDir,'\');
else
    indir=strcat(handles.inDir,'/');
end
[file, dir]=uigetfile({'*.txt; *.asc'},'Select a Text or ACII Grid Ground File',indir);

if dir~0
    handles.inDir=dir;
end
if file~0;
    handles.groundFile=strcat(dir,file);
    set(handles.GroundFile,'String',handles.groundFile);
    guidata(hObject, handles);
end



% --- Executes on selection change in directGndBox.
function directGndBox_Callback(hObject, eventdata, handles)
% hObject    handle to directGndBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns directGndBox contents as cell array
%        contents{get(hObject,'Value')} returns selected item from directGndBox
handles.directGrounds=get(hObject,'Value');
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function directGndBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to directGndBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end




% --- Executes during object deletion, before destroying properties.
function PolygonFile_DeleteFcn(hObject, eventdata, handles)
% hObject    handle to PolygonFile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes during object deletion, before destroying properties.
function PolygonFileBrowse_DeleteFcn(hObject, eventdata, handles)
% hObject    handle to PolygonFileBrowse (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pairwiseBtn.
function pairwiseBtn_Callback(hObject, eventdata, handles)
% hObject    handle to pairwiseBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of pairwiseBtn

set(hObject,'Value',1) %Turn on the radio Button
set(handles.advancedPanel,'Visible','off')
set(handles.SourcePanel,'Title','Source/Ground File')
handles.scenario='pairwise';
guidata(hObject, handles);




% --- Executes on button press in avgResistanceBtn.
function avgResistanceBtn_Callback(hObject, eventdata, handles)
% hObject    handle to avgResistanceBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of avgResistanceBtn
set(hObject,'Value',1) %Turn on the radio Button
handles.avgResistanceFlag=abs(get(hObject,'Value'));  
guidata(hObject, handles);


% --- Executes on button press in avgConductanceBtn.
function avgConductanceBtn_Callback(hObject, eventdata, handles)
% hObject    handle to avgConductanceBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of avgConductanceBtn
set(hObject,'Value',1) %Turn on the radio Button
handles.avgResistanceFlag=abs(get(hObject,'Value')-1);
guidata(hObject, handles);


% --- Executes on button press in oneSrcAllGndBtn.
function oneSrcAllGndBtn_Callback(hObject, eventdata, handles)
% hObject    handle to oneSrcAllGndBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of oneSrcAllGndBtn
set(hObject,'Value',1) %Turn on the radio Button
handles.scenario='oneSrcAllGnd';
set(handles.advancedPanel,'Visible','on')
set(handles.SourcePanel,'Title','Current Source File')
guidata(hObject, handles);


% --- Executes on button press in allSrcOneGndBtn.
function allSrcOneGndBtn_Callback(hObject, eventdata, handles)
% hObject    handle to allSrcOneGndBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of allSrcOneGndBtn
set(hObject,'Value',1) %Turn on the radio Button
handles.scenario='allSrcOneGnd';
set(handles.advancedPanel,'Visible','on')
    set(handles.SourcePanel,'Title','Current Source File')
guidata(hObject, handles);


% --- Executes on button press in allSrcAllGndBtn.
function allSrcAllGndBtn_Callback(hObject, eventdata, handles)
% hObject    handle to allSrcAllGndBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of allSrcAllGndBtn
set(hObject,'Value',1) %Turn on the radio Button
handles.scenario='allSrcAllGnd';
set(handles.advancedPanel,'Visible','on')
    set(handles.SourcePanel,'Title','Current Source File')
guidata(hObject, handles);


% --- Executes on button press in gndResistanceBtn.
function gndResistanceBtn_Callback(hObject, eventdata, handles)
% hObject    handle to gndResistanceBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of gndResistanceBtn
set(hObject,'Value',1) %Turn on the radio Button
handles.groundRorC=1;
guidata(hObject, handles);


% --- Executes on button press in gndConductanceBtn.
function gndConductanceBtn_Callback(hObject, eventdata, handles)
% hObject    handle to gndConductanceBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of gndConductanceBtn
set(hObject,'Value',1) %Turn on the radio Button
handles.groundRorC=0;
guidata(hObject, handles)


% --- Executes during object creation, after setting all properties.
function advancedPanel_CreateFcn(hObject, eventdata, handles)
% hObject    handle to advancedPanel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called



function GroundFile_Callback(hObject, eventdata, handles)
% hObject    handle to GroundFile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of GroundFile as text
%        str2double(get(hObject,'String')) returns contents of GroundFile as a double
handles.groundFile=get(hObject,'String') ;
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function GroundFile_CreateFcn(hObject, eventdata, handles)
% hObject    handle to GroundFile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in keepAllBtn.
function keepAllBtn_Callback(hObject, eventdata, handles)
% hObject    handle to keepAllBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of keepAllBtn

   handles.rmvSrcGnd='keepAll';
guidata(hObject, handles);


% --- Executes on button press in rmvGndBtn.
function rmvGndBtn_Callback(hObject, eventdata, handles)
% hObject    handle to rmvGndBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of rmvGndBtn
handles.rmvSrcGnd='rmvGnd';
guidata(hObject, handles);


% --- Executes on button press in rmvSrcBtn.
function rmvSrcBtn_Callback(hObject, eventdata, handles)
% hObject    handle to rmvSrcBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of rmvSrcBtn
handles.rmvSrcGnd='rmvSrc';
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function SourcePanel_CreateFcn(hObject, eventdata, handles)
% hObject    handle to SourcePanel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function figure1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to figure1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function pairwiseBtn_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pairwiseBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object deletion, before destroying properties.
function PointFile_DeleteFcn(hObject, eventdata, handles)
% hObject    handle to PointFile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes during object creation, after setting all properties.
function CellFileBrowse_CreateFcn(hObject, eventdata, handles)
% hObject    handle to CellFileBrowse (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function verifyBtn_CreateFcn(hObject, eventdata, handles)
% hObject    handle to verifyBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function CalcButton_CreateFcn(hObject, eventdata, handles)
% hObject    handle to CalcButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function keepAllBtn_CreateFcn(hObject, eventdata, handles)
% hObject    handle to keepAllBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function rmvGndBtn_CreateFcn(hObject, eventdata, handles)
% hObject    handle to rmvGndBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function rmvSrcBtn_CreateFcn(hObject, eventdata, handles)
% hObject    handle to rmvSrcBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function gndResistanceBtn_CreateFcn(hObject, eventdata, handles)
% hObject    handle to gndResistanceBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function gndConductanceBtn_CreateFcn(hObject, eventdata, handles)
% hObject    handle to gndConductanceBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function gndFileBrowse_CreateFcn(hObject, eventdata, handles)
% hObject    handle to gndFileBrowse (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function OutFileBrowse_CreateFcn(hObject, eventdata, handles)
% hObject    handle to OutFileBrowse (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function CurMapBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to CurMapBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function VoltMapBox_CreateFcn(hObject, eventdata, handles)
% hObject    handle to VoltMapBox (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function PointFileBrowse_CreateFcn(hObject, eventdata, handles)
% hObject    handle to PointFileBrowse (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function EightNButton_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EightNButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function FourNButton_CreateFcn(hObject, eventdata, handles)
% hObject    handle to FourNButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function avgResistanceBtn_CreateFcn(hObject, eventdata, handles)
% hObject    handle to avgResistanceBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function avgConductanceBtn_CreateFcn(hObject, eventdata, handles)
% hObject    handle to avgConductanceBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function ConductanceButton_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ConductanceButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function ResistanceButton_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ResistanceButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function allSrcAllGndBtn_CreateFcn(hObject, eventdata, handles)
% hObject    handle to allSrcAllGndBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function allSrcOneGndBtn_CreateFcn(hObject, eventdata, handles)
% hObject    handle to allSrcOneGndBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function oneSrcAllGndBtn_CreateFcn(hObject, eventdata, handles)
% hObject    handle to oneSrcAllGndBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object deletion, before destroying properties.
function ConductanceButton_DeleteFcn(hObject, eventdata, handles)
% hObject    handle to ConductanceButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over ConductanceButton.
function ConductanceButton_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to ConductanceButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes during object creation, after setting all properties.
function uipanel15_CreateFcn(hObject, eventdata, handles)
% hObject    handle to uipanel15 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function uipanel12_CreateFcn(hObject, eventdata, handles)
% hObject    handle to uipanel12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function uipanel25_CreateFcn(hObject, eventdata, handles)
% hObject    handle to uipanel25 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function uipanel22_CreateFcn(hObject, eventdata, handles)
% hObject    handle to uipanel22 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object creation, after setting all properties.
function uipanel24_CreateFcn(hObject, eventdata, handles)
% hObject    handle to uipanel24 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object deletion, before destroying properties.
function uipanel24_DeleteFcn(hObject, eventdata, handles)
% hObject    handle to uipanel24 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes during object creation, after setting all properties.
function uipanel10_CreateFcn(hObject, eventdata, handles)
% hObject    handle to uipanel10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object deletion, before destroying properties.
function uipanel10_DeleteFcn(hObject, eventdata, handles)
% hObject    handle to uipanel10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes during object creation, after setting all properties.
function uipanel19_CreateFcn(hObject, eventdata, handles)
% hObject    handle to uipanel19 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes during object deletion, before destroying properties.
function uipanel19_DeleteFcn(hObject, eventdata, handles)
% hObject    handle to uipanel19 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function uipanel19_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to uipanel19 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function uipanel10_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to uipanel10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function uipanel24_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to uipanel24 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over PointFile.
function PointFile_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to PointFile (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes during object deletion, before destroying properties.
function keepAllBtn_DeleteFcn(hObject, eventdata, handles)
% hObject    handle to keepAllBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes during object deletion, before destroying properties.
function gndResistanceBtn_DeleteFcn(hObject, eventdata, handles)
% hObject    handle to gndResistanceBtn (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over PolygonFileBrowse.
function PolygonFileBrowse_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to PolygonFileBrowse (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes during object deletion, before destroying properties.
function axes4_DeleteFcn(hObject, eventdata, handles)
% hObject    handle to axes4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


