function VOLTAGES=cs_multiple_solver(SOURCESTEMP,GTEMP,INFGROUNDLIST);
%cs_multiple_solver - solves non-pairwise scenarios
%
% Brad McRae, Viral B. Shah (C) 2006-08. All rights reserved.
%
% $Id: cs.m 29 2007-04-30 01:58:13Z viral $

global options;

if options.usingStarP
    [P iter relres] = Hypre_PCG_BAMG (GTEMP, SOURCESTEMP);
    if abs(relres) > 1e-3; error('Bad linear solve'); end
else
    P=GTEMP\SOURCESTEMP;
end

VOLTAGES=P(:);

if(INFGROUNDLIST)%If we have deleted nodes to replace
    numInfGrounds=size(INFGROUNDLIST,1);
    for ground=1:numInfGrounds
        node=INFGROUNDLIST(ground);
        sizeVolt=size(VOLTAGES);
        VOLTAGES(node+1:sizeVolt+1)=VOLTAGES(node:sizeVolt);
        VOLTAGES(node)=0;
    end
end
