function cs_onesrc_allgnd(G, NODEMAP, POINTS_RC, GROUNDS_RC)
% CS - ONESRC_ALLGND - handles multiple source/multiple ground problems
%
%
% Brad McRae, Viral B. Shah (C) 2006-08. All rights reserved.
%
% $Id: cs.m 29 2007-04-30 01:58:13Z viral $

global options

% Set up SOURCES and GROUNDS
[SOURCES GROUNDS]=cs_multiple_setup(G, NODEMAP, GROUNDS_RC, POINTS_RC) ;

% Make G Laplacian for solving linear systems.
G = cs_laplacian(G);

if options.curMapFlag
    CUMCURRMAP=zeros(options.nrow,options.ncol);
    writeCumFlag=0;
end

numnodes=size(G,1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


[i,j,val]=find(SOURCES);
SOURCELIST(:,1)=i;
SOURCELIST(:,2)=val;
clear i j val;

if size(SOURCELIST,1)<1
    error('No valid source points')
end

for sourcePoint=1:size(SOURCELIST,1)
    sourceNode=SOURCELIST(sourcePoint,1);
    GROUNDSTEMP=GROUNDS;
    SOURCESTEMP=zeros(size(SOURCES,1),1);
    SOURCESTEMP(sourceNode)=SOURCES(sourceNode);
    if GROUNDSTEMP(sourceNode)==Inf
        GROUNDSTEMP(sourceNode)=0;%Can't connect source to ground.  Here sourcetakes precedence.
    elseif GROUNDSTEMP(sourceNode)%(conflict)
        if strcmp(options.rmvSrcGnd,'rmvGnd'); %'keepAll';  'rmvSrc';
            GROUNDSTEMP(sourceNode)=0;
        end
    end

    GTEMP=G;

    %add in finite grounds to GTEMP
    FINITEGROUNDS=GROUNDSTEMP;
    FINITEGROUNDS(FINITEGROUNDS==Inf)=0;
    GTEMP=sparse(GTEMP+sparse(diag(FINITEGROUNDS)));

    [i,j,val]=find(GROUNDSTEMP==Inf);
    if i%if there are nonempty entries
        INFGROUNDLIST(:,1)=i; %this will be used to both remove entries from GTEMP and reconstitute VOLTAGES
        clear i j val;
    else
        INFGROUNDLIST=[];
    end
    numInfGrounds=size(INFGROUNDLIST,1);
    for infGround=numInfGrounds:-1:1 %count backwards, remove entries
        GTEMP(INFGROUNDLIST(infGround),:)=[];
        GTEMP(:,INFGROUNDLIST(infGround))=[];
        SOURCESTEMP(INFGROUNDLIST(infGround))=[];
    end
    numsources=nnz(SOURCESTEMP);
    numgrounds=nnz(GROUNDSTEMP);
    if numsources>0
        if numgrounds>0
            VOLTAGES=cs_multiple_solver(SOURCESTEMP,GTEMP,INFGROUNDLIST);

            if sourcePoint==size(SOURCELIST,1)
                writeCumFlag=1;
            end

            if options.curMapFlag
                pt1='allgnd'  ;
                pt2=sourcePoint;
                pt2=num2str(pt2);
                pt2=strcat('src',pt2);
                G_GRAPH = (G - diag(sparse(diag(G))));
                CUMCURRMAP=cs_current_map(pt1,pt2,VOLTAGES,FINITEGROUNDS,G_GRAPH,NODEMAP,CUMCURRMAP,writeCumFlag);
                clear G_GRAPH
            end
            if options.voltMapFlag
                cs_voltage_map(pt1,pt2,VOLTAGES,NODEMAP,numnodes)
            end
        else
            fprintf('\nNo valid grounds or ground conflicts with source.  Skipping iteration.\n')
        end
    else
        fprintf('\nNo valid source or source conflicts with a ground.  Skipping iteration.\n')
    end
    clear FINITEGROUNDS GROUNDSTEMP INFGROUNDLIST numInfGrounds GTEMP SOURCESTEMP
end


