function cs_mapwriter(MAP,fileName)

% Brad McRae, Viral B. Shah (C) 2006-08. All rights reserved.

global options

fid = fopen(fileName,'w');
fprintf(fid, 'ncols         %d',options.ncol);
fprintf(fid, '\nnrows         %d',options.nrow);
fprintf(fid, '\nxllcorner     %d',options.xllcorner);
fprintf(fid, '\nyllcorner     %d',options.yllcorner);
fprintf(fid, '\ncellsize      %d',options.cellsize);
fprintf(fid, '\nNODATA_value  %d',options.NODATA_value);
fprintf(fid, '\n');
for row=1:options.nrow
    fprintf(fid,'%e\t',MAP(row,:)) ;
    fprintf(fid,'\n');
end
st=fclose(fid);
