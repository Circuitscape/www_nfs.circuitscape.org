function G = undirect(G)
% UNDIRECT : Unweighted, undirected version of a graph.
%
% F = undirect(G)  : G is a graph ("help formats" for details).
%                    F is a 1-layer undirected equivalent of G,
%                      with no self-loops.
%
% Prototype version of 17 Oct 2006.  VShah, JRG, SPR

% doesn't make sense for bipartite
if isbipartite(G)
  error('Not valid for bipartite graphs');
end

% Make the diagonal zero unless it already is
if any(diag(G.g{1}))
    G.g{1} = G.g{1}-diag(diag(G.g{1}));
end;
% Make it logical and symmetric unless it already is
if ~islogical(G.g{1}) || ~issym(G)
    G.g{1} = (G.g{1} + G.g{1}') / 2;
end;
