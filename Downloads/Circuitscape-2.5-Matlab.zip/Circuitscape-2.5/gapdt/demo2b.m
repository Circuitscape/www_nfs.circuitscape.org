%	DEMO2B:  simple demo of the Graph toolbox, intended to be usable
%	on graphs that consume ~20% of the memory of a system.  If the
%	graph 'Gflowers' does not exist, demo2b will create it;  otherwise
%	it just uses it, allowing repeated calls without creating multiple
%	times, which can be time-consuming.

echo on
%	if don't exist, create random graphs
if ~exist('Gflowers')
  Gflowers = powergraph(n*p);
  n = nverts(Gflowers,1);		%handle rounding
else
  n = nverts(Gflowers,1);
end
fprintf('n=%i, np=%i\n',n,np);

%	find the people who sent/received flowers more than twice
senders = find(outdegree(Gflowers)>2);
receivers = find(indegree(Gflowers)>2)';

%	find the people who the thrice-senders recipients sent to (repeated)
sender_reach = reach(Gflowers,senders);
receiver_reach = reach(Gflowers,receivers);

%	find the people who were reachable from both the thrice-senders
%	and thrice-receivers
sendrecv = intersect(sender_reach,receiver_reach);
%	find the thrice-senders who were reachable from thrice-receivers
%	but were not themselves receivers
send_reach_norecv = setdiff(intersect(senders,receiver_reach),receivers);

%	find the people who sent/received flowers the most
degrees = degree(Gflowers,1:n);
maxdeg = max(degrees);
highdegree = find(degrees>(maxdeg-3));

%	how much did those frequent senders/receivers send each other?
flowerdegs = nedges(subgraph(Gflowers,highdegree));
