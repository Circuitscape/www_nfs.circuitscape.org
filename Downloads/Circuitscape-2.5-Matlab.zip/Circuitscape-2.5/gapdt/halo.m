function v1 = halo(G, V, k, varargin)
% HALO:  Returns indices that are within k of the elements in the input
%        vector, ensuring that no out-of-bound indices are created.
%
% V1 = halo(G, V, K): G is a graph and V is a set of vertex indices
%		in that graph.  V2 is the set of vertices that is +/- K
%		from the input indices.
% V1 = halo(G, V, K, DIM): As above, but DIM indicates whether the indices
%               are in the 1st or 2nd dimension of the graph.
%
% Prototype version of 7 Dec 2006.  SPR


dim = 1;
if nargin>=3 & prod(size(varargin{1}))>0
  dim = varargin{1};
  if dim~=1 && dim~=2
    error('Unsupported dimension');
  end
end

delta = 0;

ndxmax = nverts(G,dim);
v1 = V;
for i=1:k
  v1 = [v1 V+i V-i];
end
v1 = unique(v1(and(v1>0,v1<ndxmax)));
