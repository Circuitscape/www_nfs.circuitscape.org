function B = srasmm (A,I,J)
% Use matrix multiplication to implement sparse subsref.
%
% B = srasmm (A, I, J)
% performs B = A(I,J)
%
% (C) 2006 Viral Shah. All rights reserved.

[nr, nc] = size(A);
nI = length(I);
nJ = length(J);
if isa(I,'char') & isa(J,'char')
  B = A;
elseif isa(J,'char') & ~isa (I, 'char')
  IM = sparse (1:nI,I,1,nI,nr);
  B = IM * A;
elseif isa(I, 'char') & ~isa(J, 'char')
  JM = sparse (J,1:nJ,1,nc,nJ);
  B = A *JM;
else
  IM = sparse (1:nI,I,1,nI,nr);
  JM = sparse (J,1:nJ,1,nc,nJ);
  B = IM * A * JM;
  end
end
