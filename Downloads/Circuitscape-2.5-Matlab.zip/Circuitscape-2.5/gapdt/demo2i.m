
echo on
n, np
%	create random graphs
tic, Gflowers = powergraph(n^2*p); toc
tic, Gchocs =   powergraph(n^2*p); toc

%	find the people who sent flowers/chocs more than twice
tic, flower_senders = find(outdegree(Gflowers)>2)'; toc
tic, choc_senders = find(outdegree(Gchocs)>2)'; toc

%	find the people who the thrice-senders recipients sent to (repeated)
tic, flower_reach = reach(Gflowers,flower_senders); toc
tic, choc_reach = reach(Gchocs,choc_senders); toc

%	find the people who were reachable from both the thrice-flower-
%	senders	and thrice-chocolate-senders
tic, flowerchoc = intersect(flower_reach,choc_reach); toc
%	find the people who sent flowers and received chocolates but did
%	not send chocolates
tic, flowernochoc = setdiff(intersect(flower_senders,choc_reach),choc_senders); toc

%	find the people who sent/received flower/chocolates the most
tic, degrees = degree(grintersect(Gflowers,Gchocs),1:n^2*p); toc
tic, maxdeg = max(degrees); toc
tic, highdegree = find(degrees>(maxdeg-3)); toc

%	how much did those people send each other flowers/chocolates?
tic, totdegs = nedges(subgraph(grunion(Gchocs,Gflowers),highdegree));  toc
tic, flowerdegs = nedges(subgraph(Gflowers,highdegree)); toc
tic, chocdegs = nedges(subgraph(Gchocs,highdegree)); toc
