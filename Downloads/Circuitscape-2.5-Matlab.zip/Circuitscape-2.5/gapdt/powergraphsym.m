function G = powergraphsym(nv, beta)
% POWERGRAPHSYM : Generate undirected graph with approx power law degrees.
%
% G = powergraphsym(nv)  : returns an undirected graph with n
%                           vertices in which the number of degree-k
%                           vertices is roughly proportional to k^(-beta).
%
% G is distributed if nv is a dlayout, e.g. G = powergraphsym(n*p)
%
% Prototype version of 17 Oct 2006.  VShah, JRG, SPR

dmax = sqrt(nv);
h = (1:dmax).^-beta;
h = nv*h/sum(h);
h = round(h);
twone = sum(h.*(1:dmax));
ne = fix(twone/2);
I = zeros(1,twone);
start = 1;
for d = 1:dmax
    stop = start+d*h(d);
    I(start:d:stop-1) = 1;
    start = stop;
end;
I = cumsum(I);
p = randperm(twone);
J = I(p(1:ne));
I = I(p(ne+1 : 2*ne));
V = ones(1,ne);
Gtmp = sparse(I,J,V,nv,nv);
G.g{1} = Gtmp - diag(diag(Gtmp));
G = undirect(G);
for i=1:nv
  G.labels(i,:) = sprintf('powsym%10.10i',i);
end
