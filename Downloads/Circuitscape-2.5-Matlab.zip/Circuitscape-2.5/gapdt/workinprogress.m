disp (' ');
disp ('**********************************************************');
disp ('* WARNING: ROUTINE UNDER CONSTRUCTION. MAY BE INCORRECT. *');
disp ('**********************************************************');
disp (' ');
