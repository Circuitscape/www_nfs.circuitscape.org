function [I, J, Aij, vperm, tperm] = kronmat(scale)
% RMAT : generate power-law directed graph with R-MAT algorithm
%
% A = kronmat(scale)   returns a graph (adj matrix) with 2^scale
% vertices,
%                   with vertex numbers not randomized.
% [I J Aij] = rmat(scale)  returns triplets, with vertex numbers
%                          and triplet order randomized.
% [I J Aij vperm tperm] = rmat(scale) also returns the randomizing
% perms.
%
% Implementation of the Kronecker power-law graph
% generation algorithm (Chakrabati &  Faloutsos).
% This is a "nice" implementation in that
% it is completely embarrassingly parallel
% and does not require ever forming the
% adjacency matrix.
%
% THE INTERFACE ADVERTISED DOES NOT WORK FOR THIS ONE YET.

% Set Kronecker weights.
%G1 = [7 1; 1 1]; lgNv = 10;  % 2 x 2 matrix => R-MAT
%G1 = [1 1 0; 1 1 1; 0 1 1];  lgNv = 7; % 3x3 matrix.

% For figure 2 I [Jure] was using a 4x4 G0 matrix with
% G0 is a 4-star (a center and 3 nodes), like this:
%a=0.41; b=0.11; lgNv = 5;
%G1 = [a a a a; a a a b; a b a b; a b b a];

% For patents I [Jure] used a star with 7 nodes:
%a=0.32; b=0.05;  lgNv = 4;
%G1 = diag(zeros(1,7)+a); G1(1,:) = a; G1(:,1) = a;  G1(G1 == 0) = b;

% Figure 4: I [Jure] used a star with 5 nodes (1 center, and 4 satellites):
a=0.48; b=0.08;   lgNv = scale;
G1 = diag(zeros(1,5)+a); G1(1,:) = a; G1(:,1) = a;  G1(G1 == 0) = b;

% Set base size of kernel matrx.
baseN = length(G1);

% Set number of vertices.
Nv = baseN^lgNv;

% Set number of edges.
Ne = 8.*Nv;

% Normalize.
G1 = G1 ./ sum(sum(G1))

% Compute sums.
G1colSums = sum(G1,1);
G1rowSums = sum(G1,2);
G1rowCumSums = [0; cumsum(G1rowSums,1)];

% Create index arrays.
ii = ones(Ne,1);  jj = ii;
ii_bit = ii;  jj_bit = jj;

% Create normalized column probabilities.
G1colNorm = G1;
for i_base=1:baseN
  G1colNorm(:,i_base) = G1(:,i_base)./G1rowSums;
end
G1colCumSums = [zeros(baseN,1) cumsum(G1colNorm,2)];

% Loop over each order of bit.
for ib = 1:lgNv
  % Compare with probabilities and set bits of indices.
%  ii_bit = rand(Ne,1) > G1rowSums(1);

  % Create random numbers.
  ii_rand = rand(Ne,1);
  jj_rand = rand(Ne,1);

  % Loop over each "bit" and compare with cumulative probability.
  for i_base=1:baseN
    ii_bit(find( ...
      (G1rowCumSums(i_base,1) < ii_rand) & ...
      (ii_rand < G1rowCumSums(i_base+1,1)) ...
    )) = i_base-1;
  end

  % Loop over each "bit" and compare with cumulative probability.
  for j_base=1:baseN
    jj_bit(find( ...
      (G1colCumSums(ii_bit+1,j_base) < jj_rand) & ...
      (jj_rand < G1colCumSums(ii_bit+1,j_base+1)) ...
    )) = j_base-1;
  end

  % multilply base and set value of this "bit".
  ii = ii + (baseN.^(ib-1)).*ii_bit;
  jj = jj + (baseN.^(ib-1)).*jj_bit;
end

% Free up some memory.
clear ii_rand ii_bit jj_rand jj_bit

% Create adjancey matrix for viewing purposes.
AA = sparse(ii,jj,ones(Ne,1));

% Create a randomized adjaceny matrix.
%[temp ir] = sort(rand(Nv,1));
%AAr = sparse(ir(ii),ir(jj),ones(Ne,1));

% Compute the histogram of the vertex degrees.
xmax = full(max(sum(AA,2)))
x = hist(sum(AA,2),xmax);

% Find non-zero entries.
k_nonzero = find(x >= 1);
k_ind = 1:xmax;


% Plot results.
%spy(AA);
%loglog(x,'o')
%plot(log10(k_ind(k_nonzero)),log10(x(k_nonzero)),'o')
