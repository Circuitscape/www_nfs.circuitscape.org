function H = addverts(G,nnew,varargin)
% ADDVERTS : Subgraph created by adding new vertices.
%
% H = addverts(G,NNEW)
% H = addverts(G,NNEW,LABELS,DIM)
%
% Input:   G is a graph (see "help formats").  NNEW is the number of new
%          vertices. DIM is the dimension in which to add the labels.  
%          LABELS are the (optional) labels for the new vertices.
%
% Output:  H is the new graph created by adding the new vertices (and
%	   optional labels) to G
% 
% Prototype version of 18 Oct 2006.  VShah, JRG, SPR

dim = 1;
if nargin==4
  if varargin{2}~=1 && varargin{2}~=2
    error('Unsupported dimension');
  end
  dim = varargin{2};
end

oldsz = size(G.g{1});
if dim==1
  newsz = size(G.g{1})+[nnew 0];
elseif dim==2
  newsz = size(G.g{1})+[0 nnew];
end
H.g{1} = sparse(newsz(1), newsz(2));
H.g{1}(1:oldsz(1),1:oldsz(2)) = G.g{1}(1:oldsz(1),1:oldsz(2));

if dim==1 & isfield(G,'label')
  H.label{1}(1:oldsz(1),:) = G.label{1}(1:oldsz(1),:);
  H.label{1}(oldsz(1)+1:newsz(1),:) = ' ';
  if nargin==3 | (nargin==4 & prod(size(varargin{1}))==0)
    for i=1:newsz-oldsz
      tmp = sprintf('adv%3.3i',i);
      H.label{1}(oldsz(1)+i,1:size(tmp,2)) = tmp;
    end
  else
    H.label{1}(oldsz(1)+1:newsz(1),1:size(varargin{1},2)) = varargin{1};
  end
  if size(G.label,2)==2
    H.label{2} = G.label{2};
  end
elseif dim==2 & isfield(G,'label') & size(G.label,2)==2
  H.label{1} = G.label{1};
  H.label{2}(1:oldsz(2),:) = G.label{2}(1:oldsz(2),:);
  H.label{2}(oldsz(2)+1:newsz(2),:) = ' ';
  if nargin==3 | (nargin==4 & prod(size(varargin{1}))==0)
    for i=1:newsz(2)-oldsz(2)
      tmp = sprintf('adv%3.3i',i);
      H.label{2}(oldsz(2)+i,1:size(tmp,2)) = tmp;
    end
  else
    H.label{2}(oldsz(2)+1:newsz(2),1:size(varargin{1},2)) = varargin{1};
  end
end
