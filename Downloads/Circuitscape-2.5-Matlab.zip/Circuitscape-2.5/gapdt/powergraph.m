function G = powergraph(nv)
% POWERGRAPH : Generate directed graph with approximate power law degrees.
%
% G = powergraph(nv)  : returns a directed graph with n vertices
%                     in which the number of indegree-k vertices 
%                     and the number of outdegree-k vertices are
%                     both roughly proportional to k^(-beta).
%
% G is distributed if nv is a dlayout, e.g. G = powergraph(n*p)
%
% Prototype version of 17 Oct 2006.  VShah, JRG, SPR

if mod(log2(nv),1)~=0
  nv = 2^floor(log2(nv));
  fprintf('powergraph:  rounding #vertices down to %i\n',nv);
end
G = rmat(log2(nv));
for i=1:nv
  G.labels(i,:) = sprintf('pow%10.10i',i);
end
