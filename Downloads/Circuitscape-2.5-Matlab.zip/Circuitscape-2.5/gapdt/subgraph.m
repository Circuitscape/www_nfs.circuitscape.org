function R = subgraph(G,V1,varargin)
% SUBGRAPH : Subgraph induced by a set of vertices.
%
% R = subgraph(G,V): 
% 	Input:  G is a graph (see "help formats").
%      	        V is an array of vertices.
%
% R = subgraph(G,V1,V2):
% R = subgraph(G,[],V2):
% 	Input:  G is a graph (see "help formats").
%      	        V1,V2 area arrays of vertices. [] signifies keeping all
%		the vertices in that dimension.
%
% Output:  R is the subgraph of G induced by the vertex set V (V1/V2),
%          that is, the graph obtained by deleting all vertices 
%          not in V (V1/V2) and the edges incident on them.
% 
% Prototype version of 17 Oct 2006.  VShah, JRG, SPR

  
if ~prod(size(V1))
  V1 = 1:size(G.g{1},1);
end
if nargin==2
  V2 = V1;
else
  if nargin==3 & ~prod(size(varargin{1}))
    V2 = 1:size(G.g{1},2);
  else
    V2 = varargin{1};
  end
end
  

R.g{1} = G.g{1}(V1,V2);
if isfield(G,'label')
  R.label{1} = G.label{1}(V1,:);
  if size(G.label,2)==2
    R.label{2} = G.label{2}(V2,:);
  end
end
