function h = degreehist(G, varargin)
% DEGREEHIST : Histogram of vertex degrees in an undirected graph.
%
% h = degreehist(G, dim)  : G is a graph ("help formats" for details)
%                           h(k) is the number of vertices in dimension DIM 
%	       	                with k-1 neighbors.
% h = degreehist(G, dim)  : G is a bipartite graph, dim is the dimension
%			in which to examine the vertices
%
% With no output, plot the degree histogram.
%
% Prototype version of 17 Oct 2006.  VShah, JRG, SPR

dim = 1;
if nargin==2
  if varargin{1}~=1 && varargin{1}~=2
    error('Unsupported dimension');
  end
  dim = varargin{1};
end

deg = degree(G, 1:nverts(G), dim);
D = 0:max(deg);
h = histc(deg, D);
if nargout < 1
    subplot (2, 1, 1);
    bar (D, h);
    axis tight;
    xlabel('vertex degree'); 
    ylabel('frequency');
  
    subplot (2, 1, 2);
    loglog (D, h, '.');
    p = polyfit (D, h', 1)
    axis tight;
    xlabel('frequency');
    ylabel('vertex degree');
end;
