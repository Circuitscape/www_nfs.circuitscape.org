function parent = getparent(T)
% GETPARENT
%
% parent = getparent(T)
%
% Compute the parent information for nodes in the tree T.
% Root nodes have label 0. There are as many root nodes as there
% are connected components in the tree T.
%
% Copyright (C) 2007, Vikram Aggarwal, Viral Shah.  All rights reserved.

T = spones(zerodiag (grsparse (T)));
n = length(T);

parent = zeros(n,1);
leaves = true;
iter = 0;

while (true)
    % Calculate the leaf nodes at this level
    outDegree = sum(T,2);
    leaves = find(outDegree == 1);
    leafSize = length(leaves);
    %fprintf ('#LEAVES = %d, #LEFT = %d\n', leafSize, nnz(outDegree));

    % Calculate the parents of these leaves
    leafMatrix = sparse(leaves, 1:leafSize, 1, n, leafSize);
    parentMatrix = T * leafMatrix;
    [connections, ign] = find(parentMatrix);
    parent (leaves) = connections;

    % Drop the edges from the original tree
    s = sparse([connections leaves], [leaves connections], 1, n, n);
    T = T - s;

    if (isempty(leaves))
        % Single root remaining.  parent is already set to zero
        break;
    elseif (length(leaves) == 2 & min(leaves) == min(connections))
        % Two nodes remaining.  Make the first the root.
        parent(leaves(1)) = 0;
        parent(leaves(2)) = leaves(1);
        break;
    end

    % To avoid semi-infinite loops
    iter = iter + 1;
    if (iter > n)
        error ('Input is not a Tree.  Cycle detected.');
    end

end

% This check should be n-max(components(G)), but we may not want to
% do connected components solely for error checking.
%
% if (nnz(parent) ~= n-1)
%    error ('Input is not a Tree.  Cycle detected.');
% end
