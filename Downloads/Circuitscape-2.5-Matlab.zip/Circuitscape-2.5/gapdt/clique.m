function G = clique (n);
% Return the graph of a clique of size n.
%
% C = clique (N)
%
% (C) 2006 Viral Shah. All rights reserved.

X = zerodiag (ones (n));
G = graph (sparse (X));


