function [is, rounds] = mis (Gin)
% MIS - Find a maximal independent vertex set in a graph G
%       using Luby's algorithm.
%
% [IS, rounds] = MIS (G)
%
% Input:  G     - undirected graph (symmetric matrix)
%
% Output: IS     - Set of maximally independent vertices
%         rounds - Number of rounds used
%
% Viral Shah (C) 2005. All rights reserved.
%
% $Id: mis.m 105 2007-03-19 21:15:53Z viral $

warning off MATLAB:divideByZero

G = grsparse (Gin);

is = [];
n = length (G);
map = 1:length(G);
G = zerodiag (spones(G));

rounds = 0;
while n > 0
    rounds = rounds + 1;
    n = length (G);

    % Select vertices where rand < 1 / (2d)
    % Degree 0 nodes always get chosen.
    deg = full(sum (G,2));
    prob = 1 ./ (2 * deg);
    select = rand(n,1) <= prob;
    
    % If neighbours selected, keep vertex with higher degree
    neigh = select & G * select;
    if ~isempty(neigh)
        f = find(neigh);
        degf = deg(f);
        Gneigh = G (f, f);
        [I J] = find(Gneigh);
        keep = degf(I) < degf(J);
        fk = [I(keep); J(keep == 0)];
        select(f(fk)) = 0;
    end
    
    % Add selected vertices and degree 0 to independent set
    sel = map(select);
    if prod(size(sel)) == 0
      sel = zeros(0,0);
    end
    is = [is sel];
    
    % Exclude neighbours of selected vertices from further consideration
    select = select | G * select;
    remain = select == 0;
    
    % Iterate on remaining subgraph
    G = G (remain, remain);
    map = map (remain);   
end

warning on MATLAB:divideByZero

