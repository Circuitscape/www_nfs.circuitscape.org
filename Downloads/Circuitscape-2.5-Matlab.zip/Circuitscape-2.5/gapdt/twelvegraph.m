function G = twelvegraph(n, d)
% TWELVEGRAPH : Generate sparse random graph.
%
% G = twelvegraph(n)  : returns an n-vertex directed graph
%                       with about 10*n random weighted edges.
% G = twelvegraph(n,d): same, with about d*n edges.
%
% G is distributed if n is a dlayout, e.g. G = twelvegraph(n*p)
%
% Prototype version of 17 Oct 2006.  VShah, JRG, SPR

if nargin < 2
    d = 10;
end;
I = 1 + fix(n*rand(1,d*n));
J = 1 + fix(n*rand(1,d*n));
V = randn(1,d*n);
G.g{1} = sparse(I,J,V,n,n);
for i=1:n
  G.labels(i,:) = sprintf('twelve%10.10i',i);
end
