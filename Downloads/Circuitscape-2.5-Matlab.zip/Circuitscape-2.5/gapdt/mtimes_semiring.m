function [X, ARG] = mtimes_semiring (A, B, in_plus_op, in_mult_op)
% SPARSE MATRIX MULTIPLICATION OVER SEMIRINGS
%
% Sparse matrix multiplication over semirings.
%
% X = mtimes_semiring (A, B, plus_op, mult_op)
% [X, ARG] = mtimes_semiring (A, B, plus_op, mult_op)
%
% Supported values for plus_op and mult_op are:
% 'plus', 'mult', 'min', 'max', 'and', 'or'
%
% In addition, when plus_op is 'argmin', 'argmax', an extra output
% argument ARG gives the location which contributed the min/max.
%
% Viral Shah (C) 2007. All rights reserved.
%
% $Id: mtimes_semiring.m 114 2007-03-22 09:50:06Z viral $

if ~isreal(A) | ~isreal(B)
  error ('Only real inputs supported for semiring operations');
end

[m1 n1] = size(A);
[m2 n2] = size(B);
if (n1 ~= m2);  error ('Incorrect dimensions'); end

if ~issparse(A);  A = sparse(A); end
if ~issparse(B);  B = sparse(B); end

if nargin == 2
  in_plus_op = 'plus';
  in_mult_op = 'mult';
elseif nargin ~= 4
  error ('Usage: mtimes_semiring (A, B, PLUS_OP, MULT_OP)');
end

if isa(A, 'dsparse') || isa(B, 'dsparse')

  if ~isa(A, 'dsparse'); A = ppback(A); end
  if ~isa(B, 'dsparse'); B = ppback(B); end

  PLUS_OP = 1;
  MULT_OP = 2;
  
  if strcmp(in_plus_op, 'plus');       PLUS_OP = 1;
  elseif strcmp(in_plus_op, 'mult');   PLUS_OP = 2;
  elseif strcmp(in_plus_op, 'min');    PLUS_OP = 3;
  elseif strcmp(in_plus_op, 'max');    PLUS_OP = 4;
  elseif strcmp(in_plus_op, 'and');    PLUS_OP = 5;
  elseif strcmp(in_plus_op, 'or');     PLUS_OP = 6;
  elseif strcmp(in_plus_op, 'argmin'); PLUS_OP = 7;
  elseif strcmp(in_plus_op, 'argmax'); PLUS_OP = 8;
  end
  
  if strcmp(in_mult_op, 'plus');       MULT_OP = 1;
  elseif strcmp(in_mult_op, 'mult');   MULT_OP = 2;
  elseif strcmp(in_mult_op, 'min');    MULT_OP = 3;
  elseif strcmp(in_mult_op, 'max');    MULT_OP = 4;
  elseif strcmp(in_mult_op, 'and');    MULT_OP = 5;
  elseif strcmp(in_mult_op, 'or');     MULT_OP = 6;
  end
  
  [X, ARG] = ppclient ('matmat_driver', A, B, PLUS_OP, MULT_OP);

else % Not using Star-P  
  C = A * B;

  if strcmp (in_plus_op, 'plus') && strcmp (in_mult_op, 'mult')
    X = C;
    return;
  end

  [I J] = find(C);
  At = A';
  U = At(:, I);
  V = B(:, J);

  W1 = [];
  if     strcmp(in_mult_op, 'plus');   W1 = U + V;
  elseif strcmp(in_mult_op, 'mult');   W1 = U .* V;
  elseif strcmp(in_mult_op, 'min');    W1 = min (U, V);
  elseif strcmp(in_mult_op, 'max');    W1 = max (U, V);
  elseif strcmp(in_mult_op, 'and');    W1 = U & V;
  elseif strcmp(in_mult_op, 'or');     W1 = U | V;
  end

  % Clear U and V now.
  U = [];
  V = [];

  W2 = [];
  if     strcmp(in_plus_op, 'plus');   W2 = sum (W1);
  elseif strcmp(in_plus_op, 'mult');   W2 = prod (W1);
  elseif strcmp(in_plus_op, 'min');    W2 = min (W1);
  elseif strcmp(in_plus_op, 'max');    W2 = max (W1);
  elseif strcmp(in_plus_op, 'and');    W2 = prod (spones(W1)) ~= 0;
  elseif strcmp(in_plus_op, 'or');     W2 = sum (spones(W1)) ~= 0;
  elseif strcmp(in_plus_op, 'argmin'); [W2, W2arg] = min (W1);
  elseif strcmp(in_plus_op, 'argmax'); [W2, W2arg] = max (W1);
  end
  
  X = sparse (I, J, W2, size(C,1), size(C,2));
  if strcmp(in_plus_op, 'argmin') || strcmp(in_plus_op, 'argmax')
    ARG = sparse (I, J, W2arg, size(C,1), size(C,2));
  end

end
