function c = core(A,k);
% CORE : k-core of undirected graph
%
% If A is the 0/1 adjacency matrix of an n-vertex undirected graph
% (with zero diagonal), then c = core2(A);
% returns a 0/1 n-vector c with c(v)=1 for vertices v in the 2-core
% of A.
% JRG, 3 Feb 2007
% Test to make sure A is symmetric 0/1 with zero diagonal omitted.

A = spones(A);
n = max(size(A));
c = ones(n,1);
lastn = Inf;
thisn = n;
while thisn < lastn
  c = c & (A*c >= k);
  lastn = thisn;
  thisn = nnz(c);
end;
