function [len entity feature] = read_entfeat(fname)
%
%

%FIX:  make sure uneven lines handled properly

fid = fopen(fname,'r');
if fid <0
  fprintf('error opening file %s',fname);
  return
end

status = fseek(fid,0,1)
if status~=0
  fprintf('error seeking in file %s',fname);
  return
end

fsz = ftell(fid);
startb = 1;
endb = fsz-1;

fseek(fid,startb,-1);

byte = startb;
entity = char([]);
feature = char([]);
i = 0;
while byte<=endb
  line = fgetl(fid);
  if line<0 
    if byte~=endb
      fprintf(2,'Unexpected EOF in reading file, byte offset %i\n',byte);
    else
        break;
    end
  end
  i = i+1;
  byte = ftell(fid);
  [ent nline] = strtok(line);
  entity = strvcat(entity, ent);
  feat = strtok(nline);
  feature = strvcat(feature, feat);
end
len = i;
whos entity feature
