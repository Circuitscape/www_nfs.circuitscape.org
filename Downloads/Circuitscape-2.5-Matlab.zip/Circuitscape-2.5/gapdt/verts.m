function v = verts(G,varargin)
% VERTS : Vertices in a graph.
%
% v = verts(G)     : input G is a graph ("help formats" for details).
% v = verts(G,dim) : dim is a dimension (1 or 2), for bipartite graphs
%
% Prototype version of 17 Oct 2006.  VShah, JRG, SPR


% Vertices are nonzero rows (columns)
if nargin==1
  v = find(sum(abs(G.g{1}),2));
elseif nargin==2 && (varargin{1}==1 || varargin{1}==2)
  v = find(sum(abs(G.g{1}),varargin{1}));
end
