function S = grsparse (G)
% Return the underlying sparse matrix for a graph
% S = grsparse (G)
%
% The motivation behind this call is to provide a consistent interface
% in case the underlying data structure changes.
%
% Viral Shah (C) 2006. All rights reserved.
%
% $Id: grsparse.m 105 2007-03-19 21:15:53Z viral $

if isa(G, 'logical')
  G = double(G);
end

if isa(G, 'double') || isa (G, 'dsparse') || isa (G, 'ddense')
  S = G;
else 
  S = G.g{1};
end

return;
