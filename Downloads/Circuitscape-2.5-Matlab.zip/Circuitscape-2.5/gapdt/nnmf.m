function [W H] = nnmf (V, ndim, update_rule, check_convergence, varargin)
% NON NEGATIVE MATRIX FACTORIZATION
%
% [W H] = nnmf (V, ndim, update_rule, maxiter)
% [W H] = nnmf (V, ndim, update_rule, @check_convergence)
%
% Two multiplicative update rules are available in this routine
% as described in Lee and Seung (2000). The divergence method gives
% Kullback-Leibler divergence if the matrices are probability
% matrices - if all matrix entries in V and WH sum to 1. 
%
% Input: 
%  V          : Rectangular matrix or bipartite graph
%  ndim       : Number of dimensions in factorization
%  update_rule : 'euclidean', 'divergence'
%  check_convergence : Can be a function handle that returns true
%                      if W and H have converged.
%                      Can also just be the maximum number of iterations.
%  opt        : Options
%               (Currently these can only be modified in the code)
%
% Output:
%  W : m-by-k  dense matrix
%  H : k-by-n  dense matrix
%
% NOTE: W and H are not scaled during divergence iterations. Should
% they be scaled ?
%
% Dec-21-06  Viral Shah
% Parts adapted from Patrick Hoyer's nmfpack.
%
% $Id: nnmf.m 47 2007-01-05 07:55:38Z viral $

opt.checkconv = 20; % Check for convergence after these many iterations.
opt.computeobj = false; % Do not compute objective function by default.

%if isStarP
%  ppsetoption ('StrictMatlabCompat', 'off');
%end

update = @false;
objective = @false;
if strcmp (update_rule, 'euclidean')  %% Lee and Seung
    update = @euclidean_update;
    objective = @euclidean_obj;
elseif strcmp (update_rule, 'divergence')  %% Lee and Seung
    update = @divergence_update;
    objective = @divergence_obj;
else
    error ('Invalid update rule specified');
end

V = grsparse(V);
G = graph (V);

% Rescale to avoid potential overflows/underflows
V = V ./ max(max(V));

num_ent = nverts (G, 1);
num_feat = nverts (G, 2);
[V_ent V_feat V_val] = find (V);

W = abs (randn (num_ent, ndim));
H = abs (randn (ndim, num_feat));

iter = 0;
while true
    fprintf ('.');
    if mod (iter, opt.checkconv) == 0
      fprintf ('\n');

      if opt.computeobj
	obj = objective (V, W, H, V_ent, V_feat, V_val, iter); 
      end

      if isa (check_convergence, 'function_handle')
	if check_convergence (W, H, iter, varargin{:}) == true
	  break;
	end
      end	
    end

    [W H] = update (V, W, H, V_ent, V_feat, V_val);

    iter = iter + 1;
    if isa (check_convergence, 'double')
      if iter == check_convergence 
	break;
	end
    end

end

if isgraph (V)
  W = graph(W);
  H = graph(H);
end

return;

end %%% nnmf()



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% Euclidean Update Rule %%%%
%%%% Lee and Seung (2000)  %%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [W, H] = euclidean_update (V, W, H, V_ent, V_feat, V_val);

myeps = 1e-9;

Wt = W';
H = H .* (Wt*V) ./ ((Wt*W)*H + myeps);

Ht = H';
W = W .* (V*Ht) ./ (W*(H*Ht) + myeps);

return;

end %%% euclidean_update()


function obj = euclidean_obj (V, W, H, V_ent, V_feat, V_val, iter)

obj = 0.5 * sum(sum((V-W*H).^2));
fprintf ('%4d: Objective function: %f\n', iter, obj);

return;

end %%% euclidean_obj()



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% Divergence Update Rule                           %%%%
%%%% Lee and Seung (2000)                             %%%%
%%%% Gives Kullback-Leibler if all matrix entries in  %%%%
%%%% V and WH sum to 1 (probability matrices).        %%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [W, H] = divergence_update (V, W, H, V_ent, V_feat, V_val)

G = graph (V);
num_ent = nverts(G, 1);
num_feat = nverts(G, 2);

WH_val = prodWH (W, H, V_ent, V_feat);
V_over_WH = sparse (V_ent, V_feat, V_val./WH_val, num_ent, num_feat);

Ht = H';
W = W .* ((V_over_WH) * Ht) ./ (ones(num_ent, 1) * sum(Ht));

WH_val = prodWH (W, H, V_ent, V_feat);
V_over_WH = sparse (V_ent, V_feat, V_val./WH_val, num_ent, num_feat);

Wt = W';
H = H .* (Wt * (V_over_WH)) ./ (sum(W)' * ones(1, num_feat));

return;

end %%% divergence_update()


function obj = divergence_obj (V, W, H, V_ent, V_feat, V_val, iter)

WH_val = prodWH (W, H, V_ent, V_feat);
log_V_over_WH = log(V_val ./ WH_val);

ndim = size(W,2);
WH_allsum = 0;
for i=1:ndim
    WH_allsum = WH_allsum + sum(W(:,i)).*sum(H(i,:));
end
obj = sum ((V_val .* log_V_over_WH) - V_val) + WH_allsum;

fprintf ('%4d: Objective function: %f\n', iter, obj);

return;

end %%% divergence_obj()



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% Do W*H for only nonzeros in spones(V) %%%%%
%%%% Returns a list of nonzeros            %%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function WH_val = prodWH (W, H, V_ent, V_feat)

myeps = 1e-9;

if isStarP
  % Use ND indexing to work around 2d indexing slowness
  sz_WH_val = length(V_ent);

  [nrW ncW] = size(W);
  Wr = reshape (W, 1, nrW, ncW);
  W_V_ent = reshape (Wr(1, V_ent, :), sz_WH_val, ncW);
  
  [nrH ncH] = size(H);
  Hr = reshape (H, 1, nrH, ncH);
  H_V_feat = reshape (Hr(1, :, V_feat), nrH, sz_WH_val)' ;
else
  W_V_ent = W(V_ent, :);
  H_V_feat = H(:,V_feat)';
end
  
WH_val = sum (W_V_ent .* H_V_feat, 2);
WH_val(find(WH_val == 0)) = myeps;

return;

end %%% prodWH()


