function [C, ARG] = contract (G, labels, op)
% CONTRACT
%
% Contract G into blocks specified by labels.
% Nodes with the same label are contracted into one node.
%
% C = contract (G, labels);
% [C, ARG] = contract (G, labels, op);
%
% op defines how elements contributing to the same node in the
% contraction are treated. The Default is 'plus'. All
% mtimes_semiring operations are supported, including 
% 'argmin' and 'argmax'.
%
% NOTE - op works efficiently only in Star-P. 
%        Sequential Matlab implementation is very wasteful of memory.
%
% Viral Shah (C) 2007. All rights reserved.
%
% $Id: contract.m 146 2007-04-25 02:38:07Z viral $

if nargin == 2 
  op = 'plus';
end

G = grsparse (G);
n = length (G);
m = max(labels);
S = sparse (labels, 1:n, 1, m, n);
St = sparse (1:n, labels, 1, n, m);

if strcmp (op, 'plus')
  % C = S * G * St;
  [I J V] = find (G);
  C = sparse (labels(I), labels(J), V, m, m);
else
  C1 = mtimes_semiring (S, G, deblank(op), 'mult');
  [C, ARG] = mtimes_semiring (C1, St, deblank(op), 'mult');
end

if isgraph(G)
  C = graph(C);
  if ~isempty(ARG)
    ARG = graph(ARG);
  end
end
