function [edges freq] = freqsubgraph(G,szthresh,cntthresh)
%	
%	[edges freq] = freqsubgraph(G,szthresh,cntthresh) 
%	finds frequent subgraphs in the input graph G of at least
%	SZTHRESH size (number of edges) and CNTTHRESH number of ocurrences.
%	The output matrix EDGES
%	contains in each column the indices of the edges in 
%	G that comprise a specific frequent subgraph (zero filled, as
%	frequent subgraphs may be of different sizes) and the output vector
%	FREQ contains the count of how many times each frequent subgraph
%	occurred.

%	NOTE:  option to return just the subgraphs that occur with the
%	highest frequency?
%	NOTE:  or option to specify how many frequent subgraphs to return?

sprintf('\n***Note:  freqsubgraph not returning real data\n')

alledges = find(G);
nedges = size(alledges,1);

% pick a random #freq subgraphs
nfreq = fix(max(4,rand(1)*nedges/50));

nfreqedges = sort(max(szthresh,fix(rand(nfreq,1) * nedges/10)),'descend');

edges = zeros(max(nfreqedges),nfreq);
for i=1:double(nfreq)
  edges(1:nfreqedges(i),i) = sort(alledges(fix(rand(1,nfreqedges(i))*nedges)+1));
end

freq = max(cntthresh,fix(rand(nfreq,1) * sqrt(nedges)));
