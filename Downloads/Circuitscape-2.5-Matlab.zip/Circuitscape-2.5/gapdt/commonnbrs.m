function w = commonnbrs(G, v1, v2, varargin)
% COMMONNBRS : Common neighbors of a vertex or set in an undirected graph.
%
% w = commonnbrs(G, V1, V2): G is a graph ("help formats" for details)
%                  V1, V2 are vertex numbers (in the first and second
%		   dimensions, respectively, for bipartite graphs)
%                  w is the set of vertices adjacent to both v1 and v2 in G
%
% W = commonnbrs(G, V1, V2, DIM): As above, except V1 and V2 are in dimension
%                  DIM, as needed for bipartite graphs
%
% Prototype version of 17 Oct 2006.  VShah, JRG, SPR

if nargin==3
  dim = 1
elseif nargin==4
  dim = varargin{1};
  if dim~=1 && dim~=2
    error('Unsupported dimension');
  end
end
  
w = intersect(neighbors(G,v1,dim),neighbors(G,v2,dim));
