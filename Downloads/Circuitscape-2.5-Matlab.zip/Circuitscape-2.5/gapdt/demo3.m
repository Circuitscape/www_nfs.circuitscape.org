%	demonstration script for the Graph Analysis and Pattern Discovery
%	Toolbox.  Aug2006, SPR / JRG.
%	Intended to model its use for finding frequently occurring metabolic
%	pathways in a large graph of metabolic pathways.
%

echo on
%	create random graphs
Gpath = powergraph(n^2*p);

[freqedges freqcnt] = freqsubgraph(G,4);





