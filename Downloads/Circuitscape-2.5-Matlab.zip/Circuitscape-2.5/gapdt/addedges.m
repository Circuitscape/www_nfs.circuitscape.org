function H = addedges(G, i, j, varargin);
%
%  H = addedges(G, i, j);
%  H = addedges(G, i, j, weight);
%	Addedges adds the edges connecting the nodes i and j to the graph
%	G, using optional edge weights in weight.

%FIX:  needs to detect creation of multi-graphs

H = G;
H.g{:} = [];
if nargin == 3
  H.g{1} = sparse(i,j,1,size(G.g{1},1),size(G.g{1},2));
elseif nargin == 4
  H.g{1} = sparse(i,j,varargin{1},size(G.g{1},1),size(G.g{1},2));
end
H.g{1} = H.g{1} + G.g{1};
