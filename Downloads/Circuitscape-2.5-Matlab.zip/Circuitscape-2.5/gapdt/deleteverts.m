function R = deleteverts(G,V,varargin)
% DELETEVERTS : Subgraph formed by deleting specified vertices.
%
% R = deleteverts(G,V,DIM):
%
% Input:   G is a graph (see "help formats").  DIM is the dimension in 
%	   which to add the vertices.  V is an array of vertices.
%
% Output:  R is the subgraph of G induced by the complement
%          of the vertex set V, that is, the graph obtained
%          by deleting all vertices in V and incident edges.
% 
% Prototype version of 17 Oct 2006.  VShah, JRG, SPR

dim = 1;
if nargin==3
  if varargin{1}~=1 && varargin{1}~=2
    error('Unsupported dimension value');
  end
  dim = varargin{1};
end


W = otherside(find(any(G.g{1},dim)),V);
if nargin<3
  R.g{1} = G.g{1}(W,W);
elseif dim==1
  R.g{1} = G.g{1}(W,:);
else
  R.g{1} = G.g{1}(:,W);
end
if dim==0
  if isfield(G,'label')
    if size(G.label,2)==2
      error('DIM must be specified for bipartite graphs');
    end
    R.label{1} = G.label{1}(W,:);
  end
elseif dim==1
  if isfield(G,'label')
    R.label{1} = G.label{1}(W,:);
    if size(G.label,2)==2
      R.label{2} = G.label{2};
    end
  end
else
  if isfield(G,'label')
    R.label{1} = G.label{1};
    if size(G.label,2)==2
      R.label{2} = G.label{2}(W,:);
    end
  end
end
