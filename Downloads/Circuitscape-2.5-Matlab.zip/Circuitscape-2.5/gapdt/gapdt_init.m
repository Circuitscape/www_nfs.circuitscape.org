addpath meshpart
addpath cssca2/v2.0
addpath nmfpack
addpath matlab_bgl
addpath demo_netflix
addpath benchmarks

if isStarP
  ppsetoption ('StrictMatlabCompat', 'off');
end
