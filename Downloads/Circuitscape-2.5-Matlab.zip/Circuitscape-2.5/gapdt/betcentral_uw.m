function C = betcentral_uw (G, start)
% BetCentral_uw - Betweenness Centrality for unweighted graphs
%
% C = betcentral_uw (G)
% C = betcentral_uw (G, start)
%
% (C) 2006 Viral Shah. All rights reserved.

n = nverts(G);
C = zeros (n, 1);

if nargin == 1
  start = 1:n;
end

for s=start
    Q = s;
    S = [];
    Pi = [];
    Pj = [];

    numsp = zeros (n, 1);
    numsp(s) = 1;
    
    d = -ones (n, 1);
    d(s) = 0;
    
    while any(Q)
        v = Q(1);
        Q(1) = [];
        
        S = [v S];
        
        % foreach neigbor w of v
        w = neighbors (G, v);
        
        % w found for first time ?
        wnew = w(d(w) < 0);
        if any(wnew)
	  if any(Q)
            Q = [Q; wnew];
	  else
	    Q = wnew;
	  end
            d(wnew) = d(v) + 1;
        end
        
        % shortest path to w via v
        wupdate = w(d(w) == d(v) + 1);
        if any(wupdate)
            numsp(wupdate) = numsp(wupdate) + numsp(v);
            Pi = [Pi; wupdate];
            Pj = [Pj; v.*ones(length(wupdate),1)];
        end
    end
    
    P = sparse (Pi, Pj, 1, n, n);
    pairdep = zeros(n, 1);
    
    for w=S
        v = find(P(w,:));
        if any(v)
	    pairdep(v) = pairdep(v) + (numsp(v)./numsp(w)) .* (1 + pairdep(w));

	    if w ~= s
	        C(w) = C(w) + pairdep(w);
	    end
	end
    end


end
