function w = neighbors(G, v, varargin)
% NEIGHBORS : Neighbors of a vertex or set in an undirected graph.
%
% w = neighbors(G, v, dim): G is a graph ("help formats" for details)
%		       dim is the dimension of the vertex
%                      v is a vertex number
%                      w is the set of vertices adjacent to v in G
%
% W = neighbors(G, V, dim): If V is a set of vertices, then W is the set
%                      of vertices not in V adjacent to vertices in V.
%
%	Note that, for a bipartite graph, neighbors of vertices in dimension 1
%	(alternatively, 2) will be in dimension 2 (1).  Thus the calls
%		neigh = neighbors(G,1,[1:2:5]);
%		lab = labels(G,2,neigh);
%	will give the names of the neighbors of vertices 1,3,5 in the first
%	dimension.  I.e., the dimension on the neighbors() and labels()
%	are opposite.
%
% Prototype version of 3 Nov 2006.  VShah, JRG, SPR

dim = 1;
if nargin==3
  dim = varargin{1};
  if dim~=1 && dim~=2
    error('Unsupported dimension');
  end
end
bipart = nverts(G,1)~=nverts(G,2) || isfield(G,'label') && ...
	prod(size(G.label{2}))>0;

if dim==1
  if length(v) == 1
      w = G.g{1}(v,:);
      if ~bipart
        w(v) = 0;
      end
      w = find(w)';
  else
      x = zeros(nverts(G,1),1);
      x(v) = 1;
      w = G.g{1}'*x;
      if ~bipart
        w(v) = 0;
      end
      w = find(w)';
  end;
else	%dim==2
  if length(v) == 1
      w = G.g{1}(:,v);
      if ~bipart
        w(v) = 0;
      end
      w = find(w)';
  else
      x = zeros(nverts(G,2),1);
      x(v) = 1;
      w = G.g{1}*x;
      if ~bipart
        w(v) = 0;
      end
      w = find(w)';
  end;
end
  

  
