function G = graph(i, j, varargin);
%
%  G = graph(S);
%  G = graph(i, j);
%  G = graph(i, j, weight, nv1, nv2);
%  G = graph(i, j, weight, nv1, nv2, label1, label2); is the primary graph
%       constructor in the Graph toolbox.  i and j are the vertex indices
%       of the ends of each edge, with the edge weight optionally specified
%       by the corresponding element of weight.  label1 and label2 optionally
%       contain the node labels, with label1 corresponding to the elements
%       of i and label2 corresponding to the elements of j.

%FIX: could support graph(i,j,weight,nv1,label1) for non-bipartite
%FIX: how to handle multi-graphs?  denoted in the interface, or just
%	figured out from multiple i/j pairs?
%FIX: get labels onto back-end


if nargin == 1
  if isfield(i, 'g')
    G = i;
    return;
  end
  G.g{1} = i;
  return;
elseif nargin == 2
  weight = 1;
elseif nargin == 3
  weight = varargin{1};
elseif nargin==4 | nargin==5 | nargin==6 | nargin==7
  weight = varargin{1};
else
  error('Unexpected number of input arguments');
end

if nargout ~= 1
  error('Unexpected number of output arguments');
end

sz = [max(i) max(j)];
if nargin >= 4 & prod(size(varargin{2}))
  if  prod(size(varargin{3}))
    sz = [varargin{2} varargin{3}];
  else		% graph(i,j,w,nv1,[],...)
    sz = [varargin{2} varargin{2}];
  end
end

G.g{1} = sparse(i,j,weight,sz(1),sz(2));
if nargin == 6
  G.label{1} = varargin{4};
elseif nargin == 7
  G.label{1} = varargin{4};
  G.label{2} = varargin{5};
end
