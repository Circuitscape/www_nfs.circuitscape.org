function d = degree(G, varargin)
% DEGREE : Number of neighbors of a vertex in an undirected graph.
%
% d = degree(G, v, dim)  : G is a graph ("help formats" for details)
%                     v is a vertex number
%                     d is the number of vertices adjacent to v
%
% d = degree(G, V, dim)  : G is a graph ("help formats" for details)
%                     V is a vector of vertex numbers
%                     d is a vector of the numbers of adjacent vertices
%			for each element of V
%
% d = degree(G)         d is a vector of degrees of all vertices of G
% d = degree(G,[],dim)  in dimension dim (default 1).
%
% With one input and no output, draw a histogram of the degrees.
%
% Prototype version of 17 Oct 2006.  VShah, JRG, SPR

%FIX:  should degree return indegree+outdegree?

if nargin>3
  error('Unsupported number of input arguments');
end

if nargin==1 || nargin==2
  dim = 1;
else
  dim = varargin{2};
end
if dim==1
  sumdim = 2;
elseif dim==2
  sumdim = 1;
else
  error('Unsupported dimension, %i\n',dim);
end

if nargin < 2 | (nargin>1 & ~prod(size(varargin{1})))
    if islogical(G.g{1})
        d = full(sum(G.g{1},sumdim));
    else
        d = full(sum(spones(G.g{1}),sumdim));
    end;
    if nargout < 1
        figure; 
        hist(d,0:max(d)); 
        xlabel('vertex degree'); 
        ylabel('frequency');
    end;
else	% V argument
    v = varargin{1};
    if prod(size(v)) > 1
        if dim==1
          d = full(sum(spones(G.g{1}(v,:)),sumdim));
        else
          d = full(sum(spones(G.g{1}(:,v)),sumdim));
        end
    else
        if dim==1
          d = nnz(G.g{1}(v,:));
        else
          d = nnz(G.g{1}(:,v));
        end
    end
end;
