echo on
scale = 20*p;

% Construct a graph of size 2^scale-by-2^scale. 
G = rmat (scale)

% View graph as a 2d density plot. Currently, the order is not randomized.
spyy (G);

% Now reconstruct the graph with randomized vertex order.
G = rmat (scale, true)

% View again. The graph is now randomized.
spyy (G);

% Make the graph symmetric
G = undirect (G)

% Find connected components in the graph
c = components (G)

% Re-order the graph using the component labels
[ign, reorder] = sort (c); 
G = grperm (G, reorder, reorder);

% G will now have a block-diagonal structure 
% There is one very big block along the diagonal
spyy (G);
