% TWELVE   "The other twelve things" one would do with sparse matrices
%	Obsolete;  left here for illustration purposes.  Does not implement
%	the graph data structures fully.

format compact;  echo on

n = 5*10^8;   % for a demo n should be as large as possible, too big for one proc
I = 1 + fix(n*rand(10*n*p,1));
J = 1 + fix(n*rand(10*n*p,1));
V = randn(10*n*p,1);
A = sparse(I,J,V,n,n);
whose
% take A to be a symmetric nonzero pattern
A = spones(A + A' + speye(n*p,n));
A - A'
% row (or column) nonzero counts of A
rownz = sum(A');
max(rownz)
min(rownz)
mean(rownz)

% do a histogram of nonzero counts, with a front-end dense vector
%r = full(rownz(:));  %SPR:  rownz is dense in Star-P (not sparse as in ML)
r = rownz(:);
hist(r)

v = 123 % pick a vertex of the graph of A
find(A(v,:)) % which vertices are adjacent to v?
w = 345 % pick another vertex

find (A(v,:) .* A(w,:)) % What common neighbors do v and w have?

% another way to get neighbors of v
x = zeros(n,1); x(v) = 1;
y = A*x;
find(y)
% now, vertices at distance at most 2 from v
yy = A*y;
f = find(yy);
f'
% In this random graph, probably everything is at distance at most 
% 3 from v. Let's see:
yyy = A*yy;
nnz(yyy)
% yup.

% for a much larger graph with the same ratio of edges to vertices, 
% it would take a longer distance to hit every vertex.

% which vertices have the fewest neighbors?
degree = sum(A,2) -1;  % -1 for the nonzero on the diagonal
%[d, v] = min(degree)
d = min(degree)
find(degree == d)
% Only one vertex of degree 7
% what are its neighbors?
find(A(7,:))
% oops, should have been vertex number 610, not vertex number 7
find(A(610,:))
% how about degree 8?
find(degree == 8)
find(A(54,:))
find(A(344,:))
% Do the two degree-8 vertices have a common neighbor?
find( A(54,:) .* A(344,:))
% no.  how far apart are they?
x = zeros(n,1);
x(54) = 1;
dist = 0;
while x(344)==0; dist=dist+1, x = A*x; end
% Distance four!

diary off

