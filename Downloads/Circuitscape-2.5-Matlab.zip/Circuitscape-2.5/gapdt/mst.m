function G_mst = mst (Gin, type)
% MAXIMUM/MINIMUM WEIGHT SPANNING TREE
%
% Max/Min weight spanning tree based on Sollin's algorithm.
%
% T = mst (G, 'max') - Default if type not specified
% T = mst (G, 'min')
%
% G    - Input graph. 
%        This routine treats all off-diagonal elements as +ve.
% type - 'max' for maximum weight spanning tree.
%        'min' for minimum weight spanning tree.
% T    - Output graph corresponding to the spanning tree.
%        T is a subset of G.
%
% Viral Shah (C) 2007. All rights reserved.
%
% $Id: mst.m 146 2007-04-25 02:38:07Z viral $

%if ~issym(G)
%  error ('Input graph not symmetric');
%end

G = zerodiag (grsparse (Gin));

if nargin == 1
  type = 'max';
end

arg_op = [];
if strcmp(type, 'max');
  arg_op = 'argmax';
  G = abs(G);
elseif strcmp (type, 'min');
  arg_op = 'argmin';
  G = -abs(G);
else
  error ('Invalid 2nd argument: type');
end

% If edge weights are not unique, contract() may get confused.
G = unique_edges (G);

n = length(G);
SN = 1:n;      % Start with each node as a supernode.
n_SN = n;
n_SN_old = n;
G_mst = sparse(n, n);

while true
  %fprintf ('#SUPERNODES = %d\n', n_SN);

  % Contract graph into supernodes
  [G_SN E_SN] = contract (G, SN, arg_op);
  G_SN = zerodiag (G_SN);
  
  % Pick max weight edges for each node from G_SN
  if strcmp(type, 'max');
    [ign, U] = max (G_SN, [], 2);
  else
    [ign, U] = min (G_SN, [], 2);
  end

  % T_locs has locations of max weight edges from G_SN which
  % contribute to the MST.
  V = (1:n_SN)';    
  T_locs = sparse ([U; V], [V; U], 1, n_SN, n_SN);

  % Now, pick the edges specified by T_locs from G to get MST edges
  % from the original graph.
  T_edges = E_SN .* spones(T_locs);
  
  % Pick MST edges from E_SN based on T_edges
  U_mst = nonzeros (triu (T_edges));
  V_mst = nonzeros (triu (T_edges'));
  T = sparse ([U_mst; V_mst], [V_mst; U_mst], 1, n, n);
  
  % Add these edges to the existing MST
  G_mst = G_mst | T;
  
  %fprintf ('Edges outside graph = %d\n', ...
  %         nnz(spones(T).*spones(G)-spones(T)));

  % Find connected components (supernodes) for the next iteration
  % Setup D to be passed to components as a starting dependency
  % vector. This greatly speeds up components.
  S = sparse(1:n, SN, 1, n, n_SN);  
  [ign ind] = max(S);
  D = sum(S * diag(sparse(ind)), 2);
  SN = components(G_mst, D);

  n_SN = max(SN);
  if n_SN == n_SN_old || n_SN == 1; 
    break; 
  end    
  n_SN_old = n_SN;
  
end

G_mst = zerodiag(G_mst) .* grsparse(Gin);

if isgraph(G)
  G_mst = graph (G_mst);
end

end % function mst()


