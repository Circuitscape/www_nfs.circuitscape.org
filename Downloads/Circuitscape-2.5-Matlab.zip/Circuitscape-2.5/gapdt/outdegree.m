function d = outdegree(G, varargin)
% OUTDEGREE : Number of neighbors of a vertex in a directed graph.
%
% d = outdegree(G, v)  : G is a graph ("help formats" for details)
%                        v is a vertex number
%                        d is the number of vertices w with (v,w) in G
%
% d = outdegree(G)     : d is a vector of outdegrees of all vertices of G
%
% With one input and no output, draw a histogram of the outdegrees.
%
% Prototype version of 17 Oct 2006.  VShah, JRG, SPR

if nargin<3
  dim = 2;
  d = degree(G,[],dim);
else
  if varargin{2}==1
    dim = 2;
  else
    dim = 1;
  end
  d = degree(G,varargin{1},dim);
end

