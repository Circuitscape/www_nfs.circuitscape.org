function nv = nverts(G,varargin)
% NVERTS : Number of vertices in a graph.
%
% nv = nverts(G)      : input G is a graph ("help formats" for details).
% nv = nverts(G, dim) : input G is a graph and dim is the dimension in 
%		which to count the number of vertices (default 1).
%
% Prototype version of 3 Nov 2006.  VShah, JRG, SPR


if nargin>2
  error('Unsupported number of input arguments');
end

% Number of vertices is matrix dimension
dim = 1;
if nargin==2
  if varargin{1}~=1 && varargin{1}~=2
    error('Unsupported dimension');
  else
    dim = varargin{1};
  end
end

G = grsparse(G);
nv = size(G,dim);
if isa(prod(size(G)),'dlayout')
  nv = nv*p;
end
