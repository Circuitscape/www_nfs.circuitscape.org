function Gmst = maxspantree(Ginput)
% MAXIMUM WEIGHT SPANNING TREE
% Sollin's algorithm from Jaja, Page 224.
%
% Gmst = maxspantree (G)
%
% (C) 2006 Viral Shah, Vikram Aggarwal. All rights reserved.

workinprogress;

if verts(G,1)~=verts(G,2)
  error('maxspantree only implemented for square graphs');
end

G = Ginput.g{1};
n = length(G);
nSN = n;

U = [];
V = [];

iter = 0;

while 1
    iter = iter + 1;
        
    % Pick max weight edges for each node
    [m, pos] = max (G);
    F = sparse (1:nSN, pos, m, nSN, nSN);
    
    % Add these edges to the MST
    F = F + F';
    [I J] = find(F);
    if iter > 1
        [ign ign UU] = find(full(spones(tril(F)) .* Einfo));
        U = [U; UU];
        [ign ign VV] = find(full(spones(triu(F)) .* Einfo));
        V = [V; VV];
    else
        U = I;
        V = J;
    end
    
    % Find supernodes
    SN = seqcomponents(F);
    if (max(SN)) == 1
        break;
    end
    
    % Delete intra-supernode edges
    [I J W] = find (G);
    intraEdge = find (SN(I) ~= SN(J));
    I = I(intraEdge);
    J = J(intraEdge);
    W = W(intraEdge);
    
    % Pick max weight edges among supernodes
    Jlin = sub2ind ([nSN nSN], I, J);
    Gtemp = sparse (Jlin, SN(I), W);
    [m, pos] = max (Gtemp);
    fm = find(m);
    [Inext Jnext] = ind2sub ([nSN nSN], pos(fm));
    
    % Prepare graph of supernodes for next iteration
    Isn = SN(Inext);
    Jsn = SN(Jnext);
    nSN = max(SN);

    % Bookkeeping and graph preparation
    x_Einfo = [Isn Jsn];
    y_Einfo = [Jsn Isn];
    v_Einfo = [Inext Jnext];
    m_G = [m(fm) m(fm)];
    xyv = unique(sortrows([x_Einfo; y_Einfo; v_Einfo; m_G]'), 'rows');

    x = xyv(:,1);
    y = xyv(:,2);
    G = sparse (x, y, xyv(:,4), nSN, nSN);
    Einfo = sparse (x, y, xyv(:,3), nSN, nSN);

end

Gmst.g{1} = sparse (U, V, 1, n, n);
Gmst.g{1} = spones(Gmst.g{1} + Gmst.g{1}.') .* Ginput.g{1};

