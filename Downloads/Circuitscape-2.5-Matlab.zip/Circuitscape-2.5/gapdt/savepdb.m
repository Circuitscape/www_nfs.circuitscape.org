function savepdb (G, xyz, filename)
% SAVEPDB
%
% savepdb (G, xyz)
%
% Save an adjacency graph and its 3d co-ordinates as a PDB file
% which can be directly loaded into pymol for visualization.
%
% Viral Shah (C) 2005. All rights reserved.
%
% $Id$

atoms = {'N', 'CA', 'C', 'O', 'CE', 'CG', 'NE', 'S'};
fid = fopen (filename, 'w');

fprintf (fid, 'HEADER    XXXXXXXXXXXXXX                          31-DEC-79   GRAPH\n');

nVertices = size(G, 1);
color = ones (nVertices,1);
label = ones (nVertices,1);
for i=1:nVertices
    fprintf(fid, 'ATOM  %5i %3s %4i A %4i   ', ...
	    i, atoms{color(i)}, label(i), label(i) );
    fprintf(fid, '%8.3f', 100*xyz(i,:));
    fprintf(fid, '  1.00 30.00           N\n');  
end

for i=1:nVertices
    f = find (G(i,:));
    pairs = [i*ones(nnz(f),1)'; f];
    fprintf(fid, 'CONECT%5i%5i\n', pairs);
end

fclose (fid);
