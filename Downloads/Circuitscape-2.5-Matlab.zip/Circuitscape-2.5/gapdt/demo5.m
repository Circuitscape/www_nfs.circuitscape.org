echo on

% Fv{F,T,P} == faces v {faces,times,places}

if ~prod(size(strfind(pphostname,'americas.sgi.com')))
  FvF = powergraph(1000*p);	% non-bipartite
  nF = nverts(FvP,1);
  FvT = powergraph(1000*p);	% bipartite
  FvP = powergraph(1000*p);	% bipartite
else
  data = pph5read('/data/efs/a67/spr/starp/codes/gapdt/ratings_ts.h5','ratings');
  FvP = graph(data(1,:), data(2,:), data(3,:));
  nF = nverts(FvP,1);
  FvT = fliplr(FvP);
  FvF = powergraph(nF);
end
  

% {c,}{f,t,p} oi == {calculated,}{faces,times,places}  of interest
% ffoi = friends of faces of interest

% start with a set of {faces,times,places} of interest
foi = ppback((1:100).*2);
toi = (1:(nverts(FvT,2)^.25))*10+nverts(FvT,2)/2;
poi = 1:100;

% First, only look further at times that are of interest and for which
% faces of interest have been seen
[ign ctoi] = reach(FvT,foi,1);
toi = intersect(ctoi,toi);

% Next, get all the times +/- width time units from the times of interest
width = 2;
htoi = halo(FvT,toi,width,2);	
% find all the people who were seen in those halo time periods
[ftoi ign] = reach(FvT,htoi,1,2);

% Next, get the faces that were seen in both times and places of interest
[fpoi ign] = reach(FvP,poi,1,2);
fptoi = intersect(fpoi,ftoi);


