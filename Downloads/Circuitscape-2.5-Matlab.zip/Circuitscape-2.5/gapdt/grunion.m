function Gn = grunion(G1, G2)
% GRUNION:  Returns edges that exist in either input undirected graph.
%
% Gn = grunion(G1, G2): G1 and G2 are graphs ("help formats" for details)
%               Gn is the graph consisting of edges that exist in either 
%		G1 and G2
%
% Prototype version of 17 Oct 2006.  VShah, JRG, SPR

Gn.g{1} = G1.g{1} + G2.g{1};
if isfield(G1,'label')
  Gn.label{1} = G1.label{1};
  if size(G1.label,2) == 2
    Gn.label{2} = G1.label{2};
  end
end
