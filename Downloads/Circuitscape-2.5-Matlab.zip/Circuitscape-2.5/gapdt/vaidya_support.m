function T = vaidya_support (G, npart)
% VAIDYA_SUPPORT
%
% Generate a support graph for G using the Vaidya algorithm with
% augmented edges.
%
% T = supporttree (G)
% T = supporttree (G, npart)
%
% Input: G is the input graph.
%        npart is the number of partitions. Default is 10.
% Output: T is the Vaidya preconditioner with augmented edges.
%
% Viral Shah, Vikram Aggarwal (C) 2007. All rights reserved.

G = grsparse (G);
n = length (G);

% Get the simple Vaidya preconditioner based on the MST.
T = mst (G, 'max');

% Get the tree partition.
if nargin == 1;  npart = 10; end
part_label = treepart (T, npart);

% If edge weights are not unique, contract() may get confused.
Gu = unique_edges (G);
[ign E_SN] = contract (Gu, part_label, 'argmax');

% Augment MST with the heavy edges between the tree partitions.
U = nonzeros (triu (E_SN));
V = nonzeros (triu (E_SN'));
T_aug = sparse ([U; V], [V; U], 1, n, n);

T = G .* (T | T_aug);

% Preserve row sums in the preconditioner.
rowsumsG = sum (G, 2);
rowsumsT = sum (T, 2);
T = T + diag (sparse(rowsumsG - rowsumsT));
