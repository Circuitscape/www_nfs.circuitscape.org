% Pattern Discovery Toolbox:  Data Formats.
% 
% A graph is represented as a struct of
%
% (1a)  A sparse double matrix giving adjacencies in an edge-weighted 
%	graph, directed or undirected, the matrix symmetric if undirected,
%	with nonzero diagonal elements for self-loops.  The graph can be
%	non-bipartite, in which case the vertices in both dimensions are
%	the same, or bipartite, in which case the vertices are different
%	for each dimension.
% (1b)  A cell array of "layers" representing a multigraph,
%        each layer being (1) or (2).  The nonzeros in
%        the layers are nested.  [Deferred implementation]
% (2)   For non-bipartite graphs, a single character array of labels.  For
%	bipartite graphs, a pair of character arrays of labels.
%
% The vertices of non-bipartite graph G are the integers 1 through nverts(G).
%
% This prototype mostly assumes one layer and no weights.

% Prototype version of 17 Oct 2006.  VShah, JRG, SPR


help formats
