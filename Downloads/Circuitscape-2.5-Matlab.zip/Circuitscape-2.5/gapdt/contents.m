% Pattern Discovery Toolbox (v0.5).  Layer 1:  Graph Theoretic Tools
%
% "help formats" describes the graph data structure.
% 
% Graph operations.
%   graph          - Create a graph from vertex pairs, weights, and labels
%   nverts         - Number of vertices.
%   verts          - Vertices with at least one edge
%   nedges         - Number of edges.
%   edges          - Edges (of a set of vertices) of a graph
%   weights        - Weights of edges (of a set of vertices) of a graph
%   grsize         - Sizes of the graph (nverts, nedges, nbytes, ...)
%   nlayers        - Number of layers of multiple edges.
%   addedges       - Add edges to a graph
%   deleteedges    - Delete edges from a graph
%   addverts       - Add vertices to a graph
%   deleteverts    - Delete nodes from a graph
%   mergeverts     - Merge vertices together
%   subgraph       - Extract a subgraph determined by a set(s) of vertices
%   degree         - Number of neighbors of a vertex(es).
%   indegree       - Number of neighbors of a vertex.
%   outdegree      - Number of neighbors of a vertex.
%   degreehist     - Histogram of vertex degrees.
%   neighbors      - Adjacencies of a vertex or vertex set.
%   commonnbrs     - Common adjacencies of two vertices.
%   minnbrs        - Lowest-degree vertices.
%   maxnbrs        - Highest-degree vertices.
%   grdistance     - Distance in edges from one vertex to another.
%   grperm         - Permute a graph
%   eccentricity   - Eccentricity of a vertex (max distance to another).
%   grintersect    - Intersection of edges of two graphs.
%   grunion        - Union of edges of two graphs.
%   grdiff         - Difference between two graphs.
%   reach          - Reachable vertices from initial vertex(es).
%   halo           - Create a halo around each of a set of indices
%   labels         - Labels of a set of vertices
%
% Global structure of graphs.
%   components     - Connected components of a graph.
%   scomponents    - Strongly connected components of a graph.
%   toposort       - Topological ordering of directed graph.
%   bfstree        - Breadth-first spanning tree.
%   mis            - Maximal independent set.
%   mst            - Min/Max weight spanning tree.
%   contract       - Graph contraction
%
% Graph partitioning and clustering.
%   specpart       - Spectral partitioning.
%   geopart        - Geometric partitioning
%   dice           - Use any 2-way partitioner to get a multiway partition.
%   specdice       - Recursive spectral partitioning.
%   bicluster      - Iterative biclustering.
%   vcolor         - Find a vertex coloring
%   contract       - Condense a graph or matrix by given blocks.
%   cutsize        - Find or count edges cut by a partition.
%   otherside      - Other side of a partition, or change representations.
%   grcoords       - Reduce a graph to a set of N-dimensional coordinates
%   grcluster      - Reduce a graph to a set of clusters (DEFERRED IMPLEMENTATION)
%   grsequence     - Reduce a graph to a sequence of vertex IDs (DEFERRED IMPLEMENTATION)
%
%
% Demos
%   demo2          - Does simple social network analysis
%   demo5          - Does analysis of faces, places, and times
%   demo6          - Uses grcoords/NMF to explore clustering with
%                    simple visualization
%   demo7          - Creates, randomizes, and finds connected components
%
% Graph generators.
%   twelvegraph    - Input graph for Twelve Things script.
%   powergraph     - Directed graph with power-law degree distribution.
%   powergraphsym  - Undirected graph with power-law degree distribution.
%   ssca2graph     - Input graph for SSCA#2 benchmark.
%   grid5          - 2D square 5-point mesh.
%   grid9          - 2D square 9-point mesh.
%   grid3d         - 3D cubical mesh.
%   grid3dt        - 3D tetrahedral mesh.
%   clique         - A clique.
%   rmat           - R-MAT recursive power law graph generator.
%   kronmat        - Power law graph generator based on kronecker products.
%
% Visualization and graphics.
%   (Some of the graph operations can also draw pictures of what they do.)
%   gplotpart      - Draw a 2-way partition.
%   gplotmap       - Draw a multiway partition.
%   highlight      - Draw a mesh with some vertices highlighted.
%   gplotg         - Draw a 2D or 3D mesh (replaces Matlab's gplot).
%   spypart        - Matrix spy plot with partition boundaries.
%   spyy           - Plot the sparsity pattern into buckets
%
% Scan and combining operations.
%   scan           - Cumulative-op scan with specified operator.
%   segscan        - Segmented cum-op scan with specified operator.
%   accumulate     - Gather-op with specified operator.
%   
% Utilities.
%   issym          - Is a matrix symmetric or a graph undirected?
%   isgraph        - Is an object a graph?
%   isbipartite    - Is a graph bipartite?
%   fiedler        - Fiedler vector of a graph.
%   laplacian      - Laplacian matrix of a graph.
%   intersection   - Intersection of two sets.
%   union          - Union of two sets.
%   undirect       - Undirected graph induced by directed multigraph.
%   blockdiags     - Create matrix with specified block diagonals.

help Contents
