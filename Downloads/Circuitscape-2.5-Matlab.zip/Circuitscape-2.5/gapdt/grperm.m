function F = grperm(G,pr,pc)
% GRPERM : Graph permutation:  Renumber the vertices of a graph.
%
% F = grperm(G,pr,pc) : G is a graph ("help formats" for details).
%     If pr is present, permute the 'from' vertices. (rows of matrix)
%     If pc is present, permute the 'to' vertices.   (cols of matrix)
%     If both are present, perform a symmetric permutation.
%
%     Labels are not handled for now.
%
% Prototype version of 17 Oct 2006.  VShah, JRG, SPR

if isempty(pc)
  F.g{1} = G.g{1}(pr,:);
elseif isempty(pr)
  F.g{1} = G.g{1}(:,pc);
else
  F.g{1} = G.g{1}(pr,pc);
end
