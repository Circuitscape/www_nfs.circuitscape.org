function partlabel = treepart(T, subgraphs)
% TREEPART
%
% label = treepart(T, subgraphs)
%
% T is the input tree which is to be partitioned.
% subgraphs is the number of subgraphs T is to be split into.
% label is a vector of subtree ids.  Every node with the same label
% belongs to the same subtree.
%
% Copyright (c) 2007, Vikram Aggarwal, Viral Shah.   All rights reserved.

% The diagonal is useless, so  drop it
% Also, the numbers themselves are useless, we need just connectivity
T = spones(zerodiag (grsparse (T)));
n = length(T);

nKids = ones(n, 1);

% When we see a number of children which is this, we should split
splitBound = ceil(n / subgraphs); 

if (splitBound == 1)
    % Each node is in its own subtree
    partlabel = 1:n;
    return
end

% Now we are certain that splitBound > 1, which means that every node to be
% split is there because some leaf updated its leafparent's nKids to be
% greater than splitBound

parent = getparent(T);
parent (parent == 0) = find (parent == 0);

outDegree = sum(T, 2);

notSplit = ones(n, 1);
count = 0;

while (true)
    leaves = find(outDegree == 1);
    leafparents = parent(leaves);

    if (isempty(leaves))
        break;
    end

    % Increase the parents number of kids based on the children
    toAdd = sparse(leafparents, 1, nKids(leaves), n, 1);
    nKids(leafparents) = nKids(leafparents) + toAdd(leafparents);

    % Find any node that can form a subtree
    splitRoot = find(nKids >= splitBound & notSplit);
    splitParent = parent(splitRoot);

    % Remove the edges from the subtree to the original tree
    s = spones(sparse([splitParent splitRoot], [splitRoot splitParent], 1, n, n));
    T = T - zerodiag(s);

    % Each of the leafparent and the splitRoot and the splitParent lose
    % one unit of outdegree each.
    toUpdate = [leafparents; splitRoot; splitParent];
    subtractDegree = sparse(toUpdate, 1, 1, double(n), 1);
    outDegree(toUpdate) = outDegree(toUpdate) - subtractDegree(toUpdate);
    outDegree(leaves) = 0;

    % All done with these nodes.  Remember not to split them again
    notSplit(splitRoot) = 0;

    % Detect a cycle in the tree.  And tell the user to bring it down from
    % the branches.
    count = count + 1;
    if (count > n)
        error ('Cycle detected.');
    elseif (any(nKids > n))
        error ('Loop invariant violated: nKids > n');
    end

end

partlabel = components(T);
