function Gu = unique_edges(G)
% UNIQUE_EDGES
%
% G = unique_edges (Gin);
%
% Assign unique weights to edges while respecting 
% edge weight order.
%
% Viral Shah (C) 2007. All rights reserved.

n = length(G);
G = triu(G, 1);

Z = nonzeros(G);
[ign Y] = sort(Z);
X(Y) = 1:length(Z);

[I J] = find(G);
G = sparse (I, J, X, n, n);
Gu = G + G';

