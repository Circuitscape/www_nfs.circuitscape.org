function lab = labels(G,varargin)
% LABELS : return the labels of specified vertices in a graph.
%
% lab = labels(G)   
% lab = labels(G,V) 
% lab = labels(G,[],DIM)
% lab = labels(G,V,DIM))
%	For all forms, G is a graph. If specified, V is a vertex 
%	(set of	vertices).  If specified, DIM is the dimension (1 or 2)
%	in which the vertices are relevant, for a bipartite graph.
%	If DIM is not specified, 1 is assumed.
%
% Prototype version of 17 Oct 2006.  VShah, JRG, SPR

dim = 1;
if nargin==3 && varargin{2}~=1 && varargin{2}~=2
  error('Unknown dimension specified');
end
if nargin>=2
  %FIX:  remove following IF when labels reside on server
  if isa(varargin{1},'ddense') || isa(varargin{1},'dsparse')
    varargin{1} = ppfront(varargin{1});
  end
  if dim==1
    lab = G.label{1}(varargin{1},:);
  else
    lab = G.label{2}(varargin{1},:);
  end
else
  if dim==1
    lab = G.label{1};
  else
    lab = G.label{2};
  end
end
