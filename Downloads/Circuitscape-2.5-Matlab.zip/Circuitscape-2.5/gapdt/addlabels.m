function H = addlabels(G,V,labels,varargin)
% ADDLABELS : add labels to a specified set of vertices in a graph
%
% H = addlabels(G,V,LABELS,DIM)  : input G is a graph, input V is a vector of
%	 vertex	numbers or a logical index of vertices, LABELS is a
%	 character array of label names, and DIM is a dimension along
%        which the labels will be added.  size(LABELS,1) must be equal to
%	 the length of V. 
%
% Prototype version of 17 Oct 2006.  VShah, JRG, SPR

dim = 1;
if nargin==4
  if varargin{1}~=1 && varargin{1}~=2
    error('Unsupported dimension');
  end
  dim = varargin{1};
end


H = G;
if dim==1
  H.label{1}(V,:) = ' ';
  if islogical(V)
    H.label{1}(V,1:size(labels,2)) = labels(V,1:size(labels,2));
  else
    H.label{1}(V,1:size(labels,2)) = labels(:,1:size(labels,2));
  end
elseif dim==2
  H.label{2}(V,:) = ' ';
  if islogical(V)
    H.label{2}(V,1:size(labels,2)) = labels(V,1:size(labels,2));
  else
    H.label{2}(V,1:size(labels,2)) = labels(:,1:size(labels,2));
  end
end
