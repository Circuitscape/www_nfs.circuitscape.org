function ne = nedges(G)
% NEDGES : Number of edges in a directed graph.
%
% ne = nedges(G)  : input G is a graph ("help formats" for details).
%
% Prototype version of 17 Oct 2006.  VShah, JRG, SPR

if isgraph(G)
  ne = nnz(G.g{1});
else
  ne = nnz(G);
end

