function [v1 varargout] = reach(G, V, varargin)
% REACH:  Returns vertices that are reachable in the graph from a set of
%       initial vertices
%
% outverts = reach(G, inverts): G is a graph ("help formats" for details).
%               outverts is the set of vertices that is reachable in G
%               from one of the vertices in inverts.
% outverts = reach(G, inverts, k): G is a graph ("help formats" for details).
%               outverts is the set of vertices in G that is reachable in
%               no more than k hops in the graph from one of the vertices in
%               inverts.
% outverts = reach(G, inverts, k, dim): 
% outverts = reach(G, inverts,[], dim): As above, with dim specifying,
%               for a bipartite graph, the dimension of inverts (1 or 2).
%
% Prototype version of 17 Oct 2006.  VShah, JRG, SPR


maxhop = 1e6;
if nargin>=3 & prod(size(varargin{1}))>0
  maxhop = varargin{1};
end
dim = 1;
if nargin>=4 & prod(size(varargin{2}))>0
  dim = varargin{2};
  if dim~=1 && dim~=2
    error('Unsupported dimension');
  end
end

delta = 0;

if nverts(G,1)==nverts(G,2)	%non-bipartite
  v1 = V;
  while maxhop>0 & prod(size(delta)) > 0
    delta = neighbors(G,v1);
    v1 = union(v1,delta);
    maxhop = maxhop - 1;
  end
else				%bipartite
  if nargout~=2
    error('Bipartite graphs must have two output arguments');
  end
  if dim==1
    v1 = V;
    v2 = zeros(1,nverts(G)*0);
  else
    v1 = zeros(1,nverts(G)*0);
    v2 = V;
  end
  
  while maxhop>0 & prod(size(delta)) > 0
    if dim==1
      delta = neighbors(G,v1,dim);
      v2 = union(v2,delta);
      dim = 2;
    else
      delta = neighbors(G,v2,dim);
      v1 = union(v1,delta);
      dim = 1;
    end
    maxhop = maxhop - 1;
  end
  varargout{1} = v2;
end
