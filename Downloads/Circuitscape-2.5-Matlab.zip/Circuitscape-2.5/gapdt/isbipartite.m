function tf = isbipartite(G)
% BIPARTITE: Returns logical value denoting whether the graph is bipartite.
%
% tf = isbipartite(G)	: G is a graph ("help formats" for details)
%
% Prototype version of 3 Nov 2006.  VShah, JRG, SPR

tf = nverts(G,1)~=nverts(G,2) || isfield(G,'label') && ...
	prod(size(G.label{2}))>0;
