function [C, colors] = vcolor (G)
% VCOLOR - Find a vertex coloring for a given graph
% 
% [C, colors] = VCOLOR (G)
%
% Input:    G       - Any graph
%
% Output:   C       - A vector with a color for each vertex
%           colors  - Number of colors used
%
% Viral Shah (C) 2005. All rights reserved.

if isbipartite(G)
  error('Not implemented for bipartite graphs');
end

G.g{1} = G.g{1} | G.g{1}';
n = length(G.g{1});
map = 1:n;

C = zeros (n, 1);
colors = 0;

while true
    n = length(G.g{1});
    Cremain = zeros (n, 1);
    
    M = mis (G);
    colors = colors + 1;
    Cremain(M) = colors;
    C(map(M)) = colors;
    
    remain = find (Cremain == 0);
    
    if isempty(remain)
        break;
    end
    
    G.g{1} = G.g{1}(remain, remain);
    map = map(remain);
end

    
    
