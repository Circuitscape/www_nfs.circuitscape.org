function Gn = grdiff(G1, G2)
% GRDIFF:  Returns edges that are in the first graph but not the second
%
% Gn = grdiff(G1, G2): G1 and G2 are graphs ("help formats" for details)
%               Gn is the graph consisting of edges that exist in 
%		G1 but not G2
%
% Prototype version of 17 Oct 2006.  VShah, JRG, SPR


diff = setdiff(find(G1.g{1}),find(G2.g{1}));
Gn.g{1} = G1.g{1}(diff);
Gn.label{1} = G1.label{1};
Gn.label{2} = G1.label{2};
