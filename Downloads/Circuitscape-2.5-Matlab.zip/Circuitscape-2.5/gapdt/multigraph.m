function G = multigraph(I, J, W)
% G = MULTIGRAPH (I, J)
% G = MULTIGRAPH (I, J, W)
%
% Modified from JRG kernel1.m in ssca2v1.1
% 16-Dec-06 Viral Shah

if nargin == 2
  [nrI ncI] = size(I);
  W = ones (nrI, ncI);
end

% Sort edge pairs into row major order
[col, perm] = sort(J);
row = I(perm);
weight = W(perm);
[row, perm] = sort(row);
col = col(perm);
weight = weight(perm);

% Parameters of the graph
nEdges = length(weight);
nVertices = max(max(row),max(col));

% Label each edge with which layer of the digraph it goes into
maxParallelEdges = 1;
layer = ones(nEdges,1);
dups = ([0 row(1:end-1)] == row) & ([0 col(1:end-1)] == col);
while any(dups)
    maxParallelEdges = maxParallelEdges+1;
    layer(find(dups)) = maxParallelEdges;
    pad = zeros(1, maxParallelEdges);
    dups = ([pad row(1:end-maxParallelEdges)] == row) & ...
           ([pad col(1:end-maxParallelEdges)] == col);
end;

% Create the digraph for each layer of duplicate edges
for k = 1:maxParallelEdges
    layerk = layer == k;
    G.g{k} = sparse(row(layerk), col(layerk), weight(layerk), nVertices, nVertices);
end;

