function nl = nlayers(G)
% NLAYERS : Number of layers in a graph.
%
% nl = nlayers(G)  : input G is a multigraph ("help formats" for details).
%        nl is the maximum number of duplicate layers in the graph.
%
% Prototype version of 17 Oct 2006.  VShah, JRG, SPR

%FIX Implement multi-graphs (multiple layers)

%SPR  if iscell(G)
%SPR      if nnz(G{1}) == 0
%SPR          nl = 0;
%SPR      else
%SPR          nl = length(G);
%SPR      end;
%SPR  else
%SPR      if nnz(G) == 0
%SPR          nl = 0;
%SPR      else
%SPR          nl = 1;
%SPR      end;
%SPR  end;

nl = 1;		%no multi-graphs for now
