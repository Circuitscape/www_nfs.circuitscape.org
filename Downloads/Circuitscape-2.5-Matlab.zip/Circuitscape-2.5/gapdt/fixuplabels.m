function newlabel = fixuplabels(oldlabel);
% FIXUPLABELS : Relabel a partition vector to make labels consecutive.
%
% newlabel = fixuplabels (oldlabel) 
%    oldlabel: vector of "labels" for the integers 1:n
%    newlabel: vector representing the same partition or
%              equivalence relation, but in which the labels
%              are consecutive integers starting with 1.
%                                 
% John R. Gilbert, UCSB
% Version of 25 August 2005
%
% $Id: fixuplabels.m 105 2007-03-19 21:15:53Z viral $

if size(oldlabel,2) == 1
    oldlabel = oldlabel.';
end

newlabel = zeros(size(oldlabel));
[s, perm] = sort(oldlabel);
f = find(diff([s(1)-1 s]));
newlabel(f) = 1;
newlabel = cumsum(newlabel);
newlabel(perm) = newlabel;
