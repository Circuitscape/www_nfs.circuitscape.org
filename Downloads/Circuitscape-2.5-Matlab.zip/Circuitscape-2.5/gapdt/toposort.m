function [perm, label] = toposort(G)
% TOPOSORT : Topological sort of a directed graph.
%
% [perm, label] = toposort(G)  : G is a directed graph 
%                               ("help formats" for details)
%   perm is a permutation that makes G(perm,perm) lower triangular,
%   or [] if no such permutation exists.
%   A topological sort can have many orderings. Nodes having the
%   same label can appear in any order.
%
% Prototype version of 17 Oct 2006.  VShah, JRG, SPR

%FIX:  2nd return value unimplemented.


[n,ignore] = size(G.g{1});
G.g{1} = G.g{1} | speye(n);

perm = zeros(1,n);
label = zeros(1,n);
x = ones(n,1);

lastp = 0;
nextp = 1;
path = 1;

while lastp < nextp
    c = G.g{1}*x;
    f = find(c==1);
    lastp = nextp;
    nextp = nextp + length(f);
    perm(lastp:nextp-1) = f;
    label(f) = path;
    x(f) = 0;
    path = path+1;
end;

if nextp < n+1
    perm = [];
    label = [];
end;
