function scc = scomponents (G)
% STRONGLY CONNECTED COMPONENTS
%
% label = scomponents (G)
% Input  :  G - Graph
% Output :  label - Every element in the same strongly connected
%                   component has the same label.
%
% The Fleischer, Hendrickson and Pinar algorithm is implemented.
%
% Viral Shah (C) 2007. All rights reserved.
%
% $Id: scomponents.m 105 2007-03-19 21:15:53Z viral $

global count;
global label;

G = grsparse(G);

n = length(G);
count = 0;
label = -1 * ones (1, n);
map = 1:n;

% Make graph of all ones with zero diagonal.
G = spones(G + speye(n)) - speye(n);

% Remove singletons from computation.
single = (sum(G, 1) == 0) & (sum(G, 2) == 0)';
n_single = nnz(single);
if n_single
  notsingle = find(not(single));
  single = find(single);

  label(single) = (count + 1):(count + n_single);
  count = count + n_single;

  map = map (notsingle); 
  G = G(notsingle, notsingle);
end

scomponents_recursive (G, map);
scc = label;

clear count;
clear label;

end


function scomponents_recursive (G, map);

global count;
global label;

% Remove singletons from computation.
single = (sum(G, 1) == 0) & (sum(G, 2) == 0)';
n_single = nnz(single);
if n_single
  notsingle = find(not(single));
  single = find(single);

  label(map(single)) = (count + 1):(count + n_single);
  count = count + n_single;

  map = map (notsingle); 
  G = G(notsingle, notsingle);
end

n = length(G);
if n == 0
    return;
end

Gt = G';
v = 1 + fix(rand * n);

% Compute predecessors and descendants. 
% Descendants are predecessors in G'.
pred = predecessor (G, v);
desc = predecessor (Gt, v);

% Intersection of predecessors and descendants is a SCC.
scc = pred & desc;
count = count + 1;
label(map(find(scc))) = count;

% Iterate over subgraph of predecessors
remain_p = find (xor (pred, scc));
scomponents_recursive (G(remain_p, remain_p), map(remain_p));

% Iterate over subgraph of descendants
remain_d = find (xor (desc, scc));
scomponents_recursive (G(remain_d, remain_d), map(remain_d));

% Iterate over remaining subgraph
remain = find (not (pred | desc));
scomponents_recursive (G(remain, remain), map(remain));

end


function x = predecessor (G, v);

x = zeros(length(G), 1);
x(v) = 1;

while true
    xold = x;
    x = x | G * x;
    if all(x == xold)
      return;
    end
end

end
