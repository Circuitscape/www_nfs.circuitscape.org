function Gmst = minspantree(G)
% MINIMUM WEIGHT SPANNING TREE
% Sollin's algorithm from Jaja, Page 224.
%
% Gmst = minspantree (G)
%
% (C) 2006 Viral Shah, Vikram Aggarwal. All rights reserved.

n = length(G.g{1});
[I J W] = find(G.g{1});
Gtmp.g{1} = sparse(I, J, 1./W, n, n);
Gtmp.labels = G.labels;
Gmst = maxspantree(Gtmp);

