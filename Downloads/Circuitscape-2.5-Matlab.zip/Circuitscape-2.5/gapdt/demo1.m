

echo on
%	create random graphs
Gflowers = powergraph(n^2*p);
Gchocs =   powergraph(n^2*p);

%	find all the people who sent flowers/chocs more than twice
flower_senders = find(outdegree(Gflowers)>2)';
choc_senders = find(outdegree(Gchocs)>2)';

%	find all the people who the thrice-senders recipients sent to (repeated)
flower_reach = reach(Gflowers,flower_senders);
choc_reach = reach(Gchocs,choc_senders);

%	find all the people who were reachable from both the thrice-flower-
%	senders	and thrice-chocolate-senders
flowerchoc = intersect(flower_reach,choc_reach);
