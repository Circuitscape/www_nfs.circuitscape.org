function G = zerodiag (Gin)
% ZERODIAG
%
% Zero out the diagonal of a sparse matrix.
% Alternatively, remove self loops in a graph.
%
% G = zerodiag (Gin)
%
% Viral Shah (C) 2007. All rights reserved.

G = grsparse (Gin);
G = G - diag (diag (G));

if isgraph (Gin)
  G = graph(G);
end
