echo on


if ~prod(size(strfind(pphostname,'americas.sgi.com')))
  sz = 1000*p;
  nftrain = powergraph(sz);	% non-bipartite
  nftest = subgraph(powergraph(sz),[],1:sz/20);  %choose a few as tests
else
  data = pph5read('/data/efs/a67/spr/starp/codes/gapdt/ratings_ts.h5','ratings');
  fid = fopen('movie_titles.txt','r'), 
  titles = textscan(fid,'%*d,%*4c,%s','delimiter','\n');
  nftrain = graph(data(1,:), data(2,:), data(3,:));
  nflix = nverts(FvP,1);
  nftest = subgraph(nftrain,[],1:25000);
end
  

foi = ppback((1:100).*2);

nmfxyz = grcoords(nftrain, nftest, 'nmf');

nonfoi = setdiff(1:nverts(nftrain,1),foi);
lnmfxyz = ppfront(nmfxyz);
lnonfoi = ppfront(nonfoi);
lfoi = ppfront(foi);
stem3(lnmfxyz(lnonfoi,1),lnmfxyz(lnonfoi,2),lnmfxyz(lnonfoi,3));
hold on
stem3(lnmfxyz(lfoi,1),lnmfxyz(lfoi,2),lnmfxyz(lfoi,3),'fill','m');

