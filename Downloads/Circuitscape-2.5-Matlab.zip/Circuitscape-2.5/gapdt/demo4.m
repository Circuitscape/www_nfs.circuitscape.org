
echo on
n, np
%	Successor to demo2.  Assumes that Gflowers, Gchocs, flower_senders,
%	choc_senders, flower_reach, and choc_reach have already been created.
%	
%Gflowers = powergraph(n*p);
%Gchocs =   powergraph(n*p);
%flower_senders = find(outdegree(Gflowers)>2)';
%choc_senders = find(outdegree(Gchocs)>2)';
%flower_reach = reach(Gflowers,flower_senders);
%choc_reach = reach(Gchocs,choc_senders);

%verts should be set to the 

Gcore = subgraph(grunion(Gflowers,Gchocs),union(flower_reach,choc_reach));

lasttime = floor(now)-1;	% yesterday
Gnew = dbfindconnections(verts(Gcore),'incremental',lasttime);

newverts = setdiff(verts(Gnew),verts(Gcore));
newedges = grdiff(Gnew,Gcore);
