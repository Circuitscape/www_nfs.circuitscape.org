function d = grdistance(G, v, w, varargin)
%FIX: bipartite-ize, and impl dim args for v and w
% GRDISTANCE : Graph distance between (sets of) vertices.
%
% d = grdistance(G, v, w): 
%        G is a directed or undirected graph ("help formats" for details)
%        v and w are vertex numbers
%        d is the shortest path length, in edges, from v to w (Inf if none)
% v and w may be sets of vertices, in which case d is the shortest
%        distance in edges from any vertex of v to any vertex of w.
%
% Prototype version of 17 Oct 2006.  VShah, JRG, SPR

%FIX  Doesn't work for vector inputs if G is distrib

if ~islogical(G.g{1})
    G.g{1} = G.g{1}~=0;
end;

x = zeros(nverts(G),1);
oldx = x;
x(w) = 1;
d = 0;
while ~any(x(v)) && nnz(x) > nnz(oldx)
    oldx = x;
    x = G.g{1}*x;
    d = d+1;
end;
if ~any(x(v))
    d = Inf;
end;
