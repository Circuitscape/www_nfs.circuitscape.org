function [coords] = grcoords(Gtrain, Gtest, method, varargin)
%
% COORDS = grcoords(Gtrain, Gtest, METHOD)
% COORDS = grcoords(Gtrain, Gtest, METHOD, TOL)
% COORDS = grcoords(Gtrain, Gtest, METHOD, TOL, ITERS)
% COORDS = grcoords(Gtrain, Gtest, METHOD, TOL, ITERS, DIM, OUTDIMS, METHOD_SPECIFIC_ARGS)
%	applies METHOD to the graph Gtrain to reduce its dimensionality
%	to a lower number. For each iteration of iterative METHODs, 
%	METHOD is applied to Gtrain first, with the
%	result then applied to Gtest.  When the change in the prediction
%	for Gtest from one iteration to the next is small enough, the
%	algorithm stops.  ITERS can be used to limit the number of iterations.
%	DIM specifies the dimension in which the reduction should be done;
%	DIM==1 characterizes an NxM matrix by an Nxk matrix, and DIM==2
%	characterizes an NxM matrix by a kxM matrix.  OUTDIMS specifies the
%	dimensionality k of the output (default 3).  METHOD_SPECIFIC_ARGS
%	are passed directly to the specified method.
%FIX:  if Gtest not specified, what happens?
%
%  Example:
%    [xyz] = grcoords(Gtrain,Gtest,'nmf');
%	uses non-negative matrix factorization with the divergence
%	objective to map Gtrain onto a 3D space.  See demo6 for a fuller
%	example.
%
%  Methods:
%    NMF:	Implemented with the Shahnaz and Berry algorithm, avoiding
%	the H*W (dense) product, which would be prohibitively large for
%	large graphs.  
%FIX:   Currently does not do a proper error test, so runs to the
%	maximum iterations.
%    SVDS:	Implemented with the SVDS operator.  Ignores Gtest, TOL,
%	and ITERS.
%	

%FIX:  transpose DIM==2 returns before returning?
%FIX:  some way to return both reductions in one call?

%NOTE:  nmfdiv/nmfmse both appear to do a full (dense) multiplication of
%	W*H, which in the general case will be huge.  nonnegfactor appears
%	to avoid this problem.

if nargin<3
  error('Too few input args');
end
if nargout>1
  error('Too many output args');
end
if prod(size(Gtest))==0
  isGtest = 0;
else
  isGtest = 1;
end
tol = 1e-9;	%FIX:  right?
if nargin>3
  if prod(size(varargin{1}))==0
    tol = 1e-9;
  else
    tol = varargin{1};
  end
end
iters = 40;
if nargin>4
  if prod(size(varargin{2}))==0
    iters = 40;
  else
    iters = varargin{2};
  end
end
dim = 1;
if nargin>5
  if prod(size(varargin{1}))==0
    dim = 1;
  elseif varargin{1}~=1 && varargin{1}~=2
    error('Unknown dimension');
  else
    dim = varargin{3};
  end
end
if nargin>6
  error('Unimplemented option specified');
end

switch method
case 'nmfdiv'
  [W H] = nmfdiv(Gtrain.g{1}, 3, 0, 0);
  if dim==1
    coords = H;
  else
    coords = W;
  end

case 'nmfmse'
  [W H] = nmfmse(Gtrain.g{1}, 3, 0, 0);
  if dim==1
    coords = W;
  else
    coords = H;
  end

case 'nmf'
  [W H] = nonnegfactor2(Gtrain.g{1}, Gtest.g{1}, 3, iters, tol, 'nonneg',0);
  if dim==1
    coords = W;
  else
    coords = H;
  end

case 'nmf-notest'
  [W H] = nonnegfactor(Gtrain.g{1}, dim, iters, tol, 'nonneg',0);
  if dim==1
    coords = W;
  else
    coords = H;
  end

case 'svds'
  [U S V] = svds(Gtrain.g{1}, 3);
  if dim==1
    coords = U;
  else
    coords = V;
  end

otherwise
  error('Unknown method');
end
