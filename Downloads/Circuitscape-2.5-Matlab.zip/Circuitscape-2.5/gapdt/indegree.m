function d = indegree(G, varargin)
% INDEGREE : Number of neighbors of a vertex in a directed graph.
%
% d = indegree(G, v)  : G is a graph ("help formats" for details)
%                       v is a vertex number
%                       d is the number of vertices w with (w,v) in G
%
% d = indegree(G)     : d is a vector of indegrees of all vertices of G
%
% d = indegree(G, v, dim)
% d = indegree(G,[], dim)  v is a vector of vertices in dimension dim
%
% With one input and no output, draw a histogram of the indegrees.
%
% Prototype version of 17 Oct 2006.  VShah, JRG, SPR

d = degree(G,varargin{:});
