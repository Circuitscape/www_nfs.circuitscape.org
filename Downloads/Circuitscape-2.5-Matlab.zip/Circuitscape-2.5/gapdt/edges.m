function [vert1 vert2] = edges(G,varargin)
% EDGES : return the edges incident to a set of specified vertices in a graph.
%
% lab = edges(G)    : input G is a graph ("help formats" for details).
% lab = edges(G,V)  : input G is a graph, input V is a vector of vertex
%		numbers or a logical index of vertices
% lab = edges(G,V1,V2)  : input G is a graph, input V1 is a vector of vertex
%		numbers or a logical index of vertices for vertices in the
%		first dimension (of a bipartite graph) and V2 similarly for
%		the second dimension
%
% Prototype version of 24 Oct 2006.  VShah, JRG, SPR

if nargin==3
  tmp = sparse(size(G.g{1},1),size(G.g{1},2),0);
  tmp(varargin{1},varargin{2}) = G.g{1}(varargin{1},varargin{2});
  [vert1 vert2] = find(tmp);
elseif nargin==2	% non-bipartite graph
  if size(G.g{1},1)~=size(G.g{1},2)
    error('Single input vector not accepted for bipartite graphs');
  end
  tmp = sparse(size(G.g{1},1),size(G.g{1},1),0);
  tmp(varargin{1},varargin{1}) = G.g{1}(varargin{1},varargin{1});
  [vert1 vert2] = find(tmp);
elseif nargin==1
  [vert1 vert2] = find(G.g{1});
else
  error('Unsupported number of input args');
end
