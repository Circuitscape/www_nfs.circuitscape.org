function tf = isgraph(G);
%
% TF = isgraph(G)	queries the passed-in var to see if it's a graph
%		as used elsewhere in the Graph Toolbox.  Intended as a 
%		helper routine for Graph Toolbox routines.

tf = false;
if isfield(G,'g') && isa(G.g,'cell')
  if isa(G.g{1},'dsparse') || isa(G.g{1},'sparse')
    tf = true;
  end
end
