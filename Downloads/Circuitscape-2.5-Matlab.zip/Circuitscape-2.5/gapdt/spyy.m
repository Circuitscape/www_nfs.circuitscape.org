function Bout = spyy(A, nrb, ncb, incmap);
%SPYY Spy plot for large graphs.
%
%   SPYY(A) plots the sparsity pattern of graph A as a colored image,
%           using 64 buckets (for A's long dimension) colored by density.
%   SPYY(A, nb) uses nb buckets instead of 64.
%   SPYY(A, nrb, ncb) uses nrb by ncb buckets.
%   SPPY(A, [], [], colormap) uses the supplied colormap.
%      Use 'print' for colormap to get a print version of the plot.          
%   B = SPYY(A,...)  returns the block densities instead of plotting them.
%
% Pre-prototype version of 15 Nov 2005.  JRG, SPR
% Updated 20 Jul 2006 to add scale info and separate plot routine.  JRG
% Updated 22 Sep 2006 to allow a grayscale colormap for printing. VBS
% Prototype version of 17 Oct 2006.  VShah, JRG, SPR

bucketsize = 64;
if isStarP
  bucketsize = bucketsize*p;
end

A = grsparse(A);
%[nra, nca] = size(A);
nra = nverts (A, 1);
nca = nverts (A, 2);
if nargin < 2
    nrb = bucketsize;
elseif isempty(nrb) || isempty(ncb)
    nrb = bucketsize;
    ncb = bucketsize;
end;
nb = nrb;
if nargin < 3
    if nra >= nca
        nrb = nb; ncb = round(nrb*nca/nra);
    else
        ncb = nb; nrb = round(ncb*nra/nca);
    end;
end;

if nargin < 4
    incmap = [];
end

% B is created by multiplying A by
% restriction and prolongation matrices.
Prows = zeros(1,nra);
Prows(round(1:(nra/nrb):end)) = 1;
Prows = cumsum(Prows);
P = sparse(Prows,1:nra,1,nrb,nra);
Qcols = zeros(1,nca);
Qcols(round(1:(nca/ncb):end)) = 1;
Qcols = cumsum(Qcols);
Q = sparse(1:nca,Qcols,1,nca,ncb);
B = P * (spones(A) * Q); 
if isStarP ()
    B = full(ppfront(B));   % for Star-P
else
    B = full(B);
end
    
if nargout > 0
    Bout = B;
else
    if nargin < 4
        cmap = mycmap;
    elseif strcmp(incmap, 'print')
        cmap = flipud(gray(80));
        cmap(2:16,:) = [];
    else
        cmap = incmap;
    end
    
    % plot an image
    str = sprintf('Matrix nr = %d, nc = %d, nnz = %d\nBucket nnz: ', ...
        nra, nca, nnz(A));
    
    plotyy(B, str, cmap);

    if strcmp (incmap, 'print')
        whitebg;
    end

end;

function plotyy(A,str,cmap)
% PLOTYY :  Plot for SPYY, 2D histogram, and related routines
%   
% plotyy(A) makes a 2D density picture of matrix A
% plotyy(A,str) includes string str in the caption (xlabel)
%
% Written 20 Jul 2006 : JRG

if nargin < 2
    str = [];
end;
[nra nca] = size(A);
colormap(cmap);
nh = size(cmap,1);
A = full(A);
Asum = sum(sum(A));
Amin = min(min(A));
Amax = max(max(A));
Aavg = Asum/(nra*nca);
image(A*nh/Amax);
whitebg('k');
axis equal
axis ij
axis([0 nca 0 nra]+.5);
str = sprintf('%smax = %d, min = %d, avg = %3g, total = %d, max/avg = %0.2g', ...
    str, Amax, Amin, Aavg, Asum, Amax/Aavg);
xlabel(str);
colorbar('ytick', [1:(nh-1)/4:nh], 'yticklabel', [0:Amax/4:Amax]);

function h = mycmap;
% Color map for spyy plots
h = [0.0417         0         0
    0.1615         0         0
    0.2813         0         0
    0.4010         0         0
    0.5208         0         0 
    0.6406         0         0
    0.7604         0         0
    0.8802         0         0
    1.0000         0         0
    1.0000    0.0556         0
    1.0000    0.1111         0
    1.0000    0.1667         0
    1.0000    0.2222         0
    1.0000    0.2778         0
    1.0000    0.3333         0
    1.0000    0.3889         0
    1.0000    0.4444         0
    1.0000    0.5000         0
    1.0000    0.5556         0
    1.0000    0.6111         0
    1.0000    0.6667         0
    1.0000    0.7222         0
    1.0000    0.7778         0
    1.0000    0.8333         0
    1.0000    0.8889         0
    1.0000    0.9444         0
    1.0000    1.0000         0
    1.0000    1.0000    0.0270
    1.0000    1.0000    0.0541
    1.0000    1.0000    0.0811
    1.0000    1.0000    0.1081
    1.0000    1.0000    0.1351
    1.0000    1.0000    0.1622
    1.0000    1.0000    0.1892
    1.0000    1.0000    0.2162
    1.0000    1.0000    0.2432
    1.0000    1.0000    0.2703
    1.0000    1.0000    0.2973
    1.0000    1.0000    0.3243
    1.0000    1.0000    0.3514
    1.0000    1.0000    0.3784
    1.0000    1.0000    0.4054
    1.0000    1.0000    0.4324
    1.0000    1.0000    0.4595
    1.0000    1.0000    0.4865
    1.0000    1.0000    0.5135
    1.0000    1.0000    0.5405
    1.0000    1.0000    0.5676
    1.0000    1.0000    0.5946
    1.0000    1.0000    0.6216
    1.0000    1.0000    0.6486
    1.0000    1.0000    0.6757
    1.0000    1.0000    0.7027
    1.0000    1.0000    0.7297
    1.0000    1.0000    0.7568
    1.0000    1.0000    0.7838
    1.0000    1.0000    0.8108
    1.0000    1.0000    0.8378
    1.0000    1.0000    0.8649
    1.0000    1.0000    0.8919
    1.0000    1.0000    0.9189
    1.0000    1.0000    0.9459
    1.0000    1.0000    0.9730
    1.0000    1.0000    1.0000];

