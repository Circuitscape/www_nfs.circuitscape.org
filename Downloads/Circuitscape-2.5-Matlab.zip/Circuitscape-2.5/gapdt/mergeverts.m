function H = mergeverts(G,dim,ndx)
% MERGEVERTS : Subgraph induced by merging set(s) of vertices.
%
% H = mergeverts(G,DIM,NDX):
%
% Input:   G is a graph (see "help formats").
%          DIM is the dimension in which to merge the vertices.
%          NDX is a vector, equal in length to the number of vertices in
%          G.  All vertices with an equal value in NDX will be merged into
%          a single vertex.  Zero values in NDX indicate "no change".
%
% Output:  R is the subgraph of G induced by the index set NDX,
%          that is, the graph obtained by collapsing all vertices with
%          the same value of NDX into a single vertex.
% 
% Prototype version of 18 Oct 2006.  VShah, JRG, SPR

%FIX  Need 3-return flavor of unique to work with ddense ndx

if dim~=1 && dim~=2
  error('Unknown dimension specified');
end

nochg = ndx==0;
newverts = nnz(unique(ndx(ndx~=0)));
newsz = nnz(nochg)+newverts;
H.g{1} = sparse(zeros(0*p,1),zeros(0*p,1),1,newsz,newsz);
if dim==1
  H.g{1}(1:nnz(nochg),:) = G.g{1}(nochg,:);
  for i=1:newverts
    H.g{1}(nnz(nochg)+i,:) = sum(G.g{1}(ndx==i, ndx==0),1);
    H.g{1}(1:nnz(ndx==0),:) = sum(G.g{1}(ndx==0, ndx==i),2);
  end
  
  [i j v] = find(ndx);
  [b m n] = unique(v);
  
  H.label{1}(1:nnz(nochg),:) = G.label{1}(nochg,:);
  H.label{1}(nnz(nochg)+1:newsz,:) = G.label{1}(j(m),:);
  H.label{2} = G.label{2};
else
  H.g{1}(:,1:nnz(nochg),:) = G.g{1}(:,nochg);
  for i=1:newverts
    H.g{1}(:,nnz(nochg)+i) = sum(G.g{1}(ndx==i, ndx==0),1);
    H.g{1}(:,1:nnz(ndx==0)) = sum(G.g{1}(ndx==0, ndx==i),2);
  end
  
  [i j v] = find(ndx);
  [b m n] = unique(v);
  
  H.label{1} = G.label{1};
  H.label{2}(1:nnz(nochg),:) = G.label{2}(nochg,:);
  H.label{2}(nnz(nochg)+1:newsz,:) = G.label{2}(j(m),:);
end
