
echo on
n, np
%	create random graphs
Gflowers = powergraph(n^2*p);
Gchocs =   powergraph(n^2*p);

%	find the people who sent flowers/chocs more than twice
flower_senders = find(outdegree(Gflowers)>2)';
choc_senders = find(outdegree(Gchocs)>2)';

%	find the people who the thrice-senders recipients sent to (repeated)
flower_reach = reach(Gflowers,flower_senders);
choc_reach = reach(Gchocs,choc_senders);

%	find the people who were reachable from both the thrice-flower-
%	senders	and thrice-chocolate-senders
flowerchoc = intersect(flower_reach,choc_reach);
%	find the people who sent flowers and received chocolates but did
%	not send chocolates
flowernochoc = setdiff(intersect(flower_senders,choc_reach),choc_senders);

%	find the people who sent/received flower/chocolates the most
degrees = degree(grintersect(Gflowers,Gchocs));
maxdeg = max(degrees);
highdegree = find(degrees>(maxdeg-3));

%	how much did those people send each other flowers/chocolates?
totdegs = nedges(subgraph(grunion(Gchocs,Gflowers),highdegree)); 
flowerdegs = nedges(subgraph(Gflowers,highdegree));
chocdegs = nedges(subgraph(Gchocs,highdegree));
