function ret = grsize(G)
% GRSIZE : Various size statistics about a graph.
%
% ret = grsize(G)  : input G is a graph ("help formats" for details).
%
% INTERFACE HACK:  To make it easy to see the contents interactively, 
%    it's best to do "grsize(G);" (with the trailing semicolon), which
%    GRSIZE will detect and print values of all the fields.  (Avoids
%    problem with dlayouts not being displayed like native data types.)
%
% Prototype version of 26 Nov 2006.  VShah, JRG, SPR


if ~isbipartite(G)
  ret.nverts(1) = double(nverts(G));
else
  ret.nverts(1) = nverts(G,1);
  ret.nverts(2) = nverts(G,2);
end
ret.nedges = nedges(G);
if issparse(G.g{1})
  if isa(G.g{1},'dsparse')
    ret.nbytes = ppbytesused(G.g{1});
  else
    tmp = G.g{1};		%FIX?  if this actually copies the graph
    tmp2 = whos('tmp');
    ret.nbytes = tmp2.bytes;
  end
else
  %FIX
end
if isfield(G,'label')
  ret.nbytes_labels(1) = 18;  	%FIX
  if prod(size(G.label{2}))>0
    ret.nbytes_labels(2) = 23;	%FIX
  end
end

%FIX:  short-term hack because disp(ret) only prints out "nverts: [1x1 dlayout]
%    instead of the value of nverts
bignum = 0;
if ret.nedges>1e9 
  bignum = 1;
else
  if ~isbipartite(G) 
    if ret.nverts>1e9
      bignum = 1;
    end
  else 
    if ret.nverts(1)>1e9 || ret.nverts(2)>1e9
      bignum = 1;
    end
  end
end
if nargout==0
  if ~isbipartite(G)
    if ~bignum
      fprintf('    nverts: %i\n    nedges: %i\n    nbytes: %i\n',ret.nverts,ret.nedges,ret.nbytes);
    else
      fprintf('    nverts: %i (%.3e)\n    nedges: %i (%.3e)\n    nbytes: %i (%.3e)\n',ret.nverts,ret.nverts,ret.nedges,ret.nedges,ret.nbytes,ret.nbytes);
    end
  else
    if ~bignum
      fprintf('    nverts: %i/%i\n    nedges: %i\n    nbytes: %i\n',ret.nverts(:),ret.nedges,ret.nbytes);
    else
      fprintf('    nverts: %i/%i (%.3e/%.3e)\n    nedges: %i (%.3e)\n    nbytes: %i (%.3e)\n',ret.nverts(:),ret.nverts(:),ret.nedges,ret.nedges,ret.nbytes,ret.nbytes);
    end
  end
end
