function [G] = grload_entfeat(fname);
%
% [ENTITY FEATURE] = GRLOAD_ENTFEAT(FNAME)
%   GRLOAD_ENTFEAT reads the contents of FNAME, assuming it has 2 elements 
%   per line, representing the ENTITY and the FEATURE, respectively, and
%   returns a graph representing the ENTITY-FEATURE edges in the file.


[len entity feature] = read_entfeat(fname);

uentity = unique(entity, 'rows');
ufeature = unique(feature, 'rows');


entndx = zeros(size(entity,1),1);
featndx = zeros(size(entity,1),1);
for i=1:size(entity,1)
    entndx(i) = strmatch(entity(i,:),uentity);
    featndx(i) = strmatch(feature(i,:),ufeature);
end
    
G = graph(entndx, featndx,1, length(entity), length(feature), entity, feature);
