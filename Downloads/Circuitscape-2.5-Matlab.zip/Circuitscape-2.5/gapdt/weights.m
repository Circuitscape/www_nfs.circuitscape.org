function w = weights(G,varargin)
% WEIGHTS : return the weights of edges incident to a set of specified
%	 vertices in a graph.
%
% w = weights(G)    : input G is a graph ("help formats" for details).
% w = weights(G,V)  : input G is a graph, input V is a vector of vertex
%		numbers or a logical index of vertices
%
% Prototype version of 24 Oct 2006.  VShah, JRG, SPR

if nargin==2
  if isbipartite(G)
    error('Bipartite graphs require two sets of input vertices');
  end
  tmp = sparse(size(G.g{1},1),size(G.g{1},2),0);
  tmp(varargin{1},varargin{1}) = G.g{1}(varargin{1},varargin{1});
  [ign1 ign2 w] = find(tmp);
elseif nargin==3
  tmp = sparse(size(G.g{1},1),size(G.g{1},2),0);
  tmp(varargin{1},varargin{1}) = G.g{1}(varargin{1},varargin{2});
  [ign1 ign2 w] = find(tmp);
else
  [ign1 ign2 w] = find(G.g{1});
end
