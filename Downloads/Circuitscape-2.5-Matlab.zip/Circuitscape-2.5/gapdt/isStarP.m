function X = isStarP ()
% isStarP - Check the presence of the StarP environment.
%
%  X = isStarP ()
%
% (C) 2006 Viral Shah. All rights reserved.

if exist ('np') & exist('ppping')
  X = true;
else
  X = false;
end
