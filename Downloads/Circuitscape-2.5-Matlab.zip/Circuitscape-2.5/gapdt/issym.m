function s = issym(G)
% ISSYM : Test for symmetry in graph/matrix.
%
% s = issym(G)  : input G is a graph ("help formats" for details).
%         s = 1 if the adjacency matrix of G is symmetric
%         s = 0 otherwise
%         
% Prototype version of 17 Oct 2006.  VShah, JRG, SPR

% Probabilistic test for symmetry
if nverts(G,1)~=nverts(G,2)	%if not square, not sym
  s = 0;
  return;
end
[n,ignore] = size(G.g{1});
x = randn(n,1);
y = randn(n,1);
normG = max(sum(abs(G.g{1}),2));
s = abs(y'*(G.g{1}*x)-x'*(G.g{1}*y)) / normG  <  10*sqrt(nnz(G.g{1}))*eps;
