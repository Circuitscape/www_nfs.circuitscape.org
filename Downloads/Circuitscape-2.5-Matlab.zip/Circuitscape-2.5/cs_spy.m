function cs_spy (G, color)
% CS_SPY - Plot landscape
%
% Brad McRae, Viral B. Shah (C) 2006-08. All rights reserved.
%
% $Id: cs_spy.m 21 2007-04-27 05:27:30Z viral $

global options;

if ~options.usingStarP
    hold on
    spy (G, color);
    drawnow;
    hold off 
end


