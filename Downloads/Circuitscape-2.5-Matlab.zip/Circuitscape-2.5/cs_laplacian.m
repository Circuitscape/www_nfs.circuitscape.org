function G = cs_laplacian (G)
% CS_LAPLACIAN - Make Laplacian for solving linear systems.
%
% Brad McRae, Viral B. Shah (C) 2006-08. All rights reserved.
%
% $Id: cs_laplacian.m 21 2007-04-27 05:27:30Z viral $

G = -G;                           % Make off-diagonals negative
G = G - diag(sparse(diag(G)));    % Make diagonal zero
G = G - diag(sparse(sum(G, 2)));  % Make row sums zero 
