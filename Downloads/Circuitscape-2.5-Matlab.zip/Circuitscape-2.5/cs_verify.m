function cs_verify ()
% CS_VERIFY - Verify if Circuitscape produces correct results.
%
% Brad McRae, Viral Shah (C) 2007. All rights reserved.
%
% $Id: cs_verify.m 23 2007-04-27 23:06:54Z viral $

clear all
global options

CORRECT_RESISTANCE = [
    0   0.003830141773298       0.006432673990234
    0.003830141773298                   0       0.005736874435859
    0.006432673990234   0.005736874435859    0
    ];

localdir='.';
os=computer;
if os(1,1)=='P';
    options.PC=1;
    slash='\';
else
    options.PC=0;
    slash='/';
end
options.inDir=strcat(localdir,slash,'testdata');
options.outDir=strcat(localdir,slash,'testdata',slash,'output');
options.cellFile=strcat(options.inDir,slash,'test_cellmap.asc');
options.pointFile=strcat(options.inDir,slash,'test_points_textlist.txt');
options.polygonFile=strcat(options.inDir,slash,'test_shorts.asc');
options.outFile=strcat(options.outDir,slash,'test.out');

options.polygonFlag=1;
options.resistanceFlag=0;
%options.gridFlag=0;
options.fourNeighborFlag=1;
options.curMapFlag=0;
options.voltMapFlag=0;
options.avgResistanceFlag=1;
options.useChol=true;

options.scenario='pairwise'

if exist ('Hypre_PCG_BAMG', 'file') ~= 2
    addpath gapdt
    addpath Hypre
end


if isStarP ()
    options.usingStarP = true;
else
    options.usingStarP = false;
end

% Load Hypre package if using StarP.
if options.usingStarP;
    Hypre_init;
end

R = cs_main


if norm (R-CORRECT_RESISTANCE, 'fro') > 1e-6
    disp(' ');
    error('*** Circuitscape produced incorrect results ***');
else
    disp(' ');
    disp('*** Circuitscape passed test with flying colors ***');
end
