function   cs_voltage_map(pt1,pt2,VOLTAGES,NODEMAP,numnodes)
%   Creates maps of current flow between source and ground points using
%   VOLTAGES calculated by solver modules
%
% Brad McRae, Viral B. Shah (C) 2006-08. All rights reserved.

global options
%fprintf('Generating voltage map\n')

VOLTMAP=zeros(options.nrow,options.ncol);

%Needs vectorizing 
for row=1:options.nrow
    for col=1:options.ncol
        node=NODEMAP(row,col);
        if node>0
         VOLTMAP(row,col)=VOLTAGES(node);
        end
    end
end

%Write voltage map to output file
output_filename=options.outFile;
SIZE=size(output_filename);
size_output_filename=SIZE(2);
outfile_root=output_filename(1:size_output_filename-4);
outfile=strcat(outfile_root,'_voltage_',pt1,'_',pt2,'.asc');
cs_mapwriter(VOLTMAP,outfile)

plot_flag=1;
    if plot_flag==1    
        X=zeros(options.nrow,options.ncol);
        Y=X;
        for r=1:options.nrow
            Y(r,:)=r;
        end
        for c=1:options.ncol
            X(:,c)=c;
        end
                    
        figure(2)
        surf(Y,X,VOLTMAP)
    end