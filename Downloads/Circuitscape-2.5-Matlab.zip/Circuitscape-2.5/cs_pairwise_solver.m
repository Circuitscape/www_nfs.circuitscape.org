function RESISTANCES = cs_pairwise_solver(G, NODEMAP, POINTS_RC)
% CS_PAIRWISE_SOLVER
%
% Compute resistance for all source/ground pairs.

% Brad McRae, Viral B. Shah (C) 2006-08. All rights reserved.

global options;

if options.curMapFlag
    CUMCURRMAP=zeros(options.nrow,options.ncol);
    writeCumFlag=0;
end

cs_time ('Calculating effective resistances');
fprintf('\n')
% Update the POINTS with the new node numbers
for point=1:size(POINTS_RC,1);
    row=POINTS_RC(point,2);
    col=POINTS_RC(point,3);
    POINTS_RC(point,4)=NODEMAP(row,col); %ID row col nodenumber
end

% Make G Laplacian for solving linear systems.
G = cs_laplacian(G);

% Need pointers because dropped nodes don't get reported,
% and create spaces in RESISTANCES matrix.
pointer1=1;
numpoints = size (POINTS_RC, 1);
numnodes = length (G);

count=0;
pctDone=0;
pctDoneStr=strcat(num2str(pctDone),'% done');
%fprintf('%s\n', pctDoneStr)

for point_1=1:numpoints-1
    if POINTS_RC(point_1,4) <= 0;        % If point has been dropped
        pointer1=pointer1+1;
        pointlabel_1=POINTS_RC(point_1,1);
        RESISTANCES(1,pointer1)=pointlabel_1;
        RESISTANCES(pointer1,1)=pointlabel_1;
        RESISTANCES(pointer1,2:numpoints+1)=-999;
        RESISTANCES(2:numpoints+1,pointer1)=-999;
        continue;
    end

    pointer1=pointer1+1;
    node1=POINTS_RC(point_1,4);
    GTEMP=G(:,:);       % Force Star-P to make a copy.
    GTEMP(node1,:)=[];
    GTEMP(:,node1)=[];

    % Cholesky factors of GTEMP. GTEMP = Rt * R.
    % Save factorization for multiple solves.
    if ~options.usingStarP
        if options.useChol
            try
                [R, p, perm] = chol (GTEMP, 'vector');
            catch
                fprintf('\nNote: Reverting to Matlab mldivide routine to solve grids. \n')
                options.useChol=false;
                p=0;
            end
            if p ~= 0
                error ('The function chol() produced an unexpected result.');
            end
        end
    end
    if pctDone==0
        fprintf('%s\n', pctDoneStr)
    end
    pointer2=pointer1;
    for point_2 = point_1+1:numpoints
        if POINTS_RC(point_2,4) <= 0;         % If point has been dropped
            pointer2=pointer2+1;
            pointlabel_2=POINTS_RC(point_2,1);
            RESISTANCES(1,pointer2)=pointlabel_2;
            RESISTANCES(pointer2,1)=pointlabel_2;
            RESISTANCES(pointer2,pointer1)=-999;
            RESISTANCES(pointer1,pointer2)=-999;
            continue;
        end

        pointer2=pointer2+1;
        node2=POINTS_RC(point_2,4);

        %  Calculate effective resistance, etc
        CURR=zeros(numnodes,1);
        % Add source and sink.
        CURR(node2)=1;
        CURR(node1)=[];

        if options.usingStarP
            [P iter relres] = Hypre_PCG_BAMG (GTEMP, CURR);
            if abs(relres) > 1e-3; error('Bad linear solve'); end
        else

            % THE MEMORY INTENSIVE STEP
            if options.useChol
                CURR_perm = CURR(perm);           % Fill-reducing permutation
                P_perm = R \ (CURR_perm' / R)';   %
                P = zeros(size(P_perm));          % Result storage.
                P(perm) = P_perm;                 % Inverse permutation
            else
                P=GTEMP\CURR;
            end
        end

        if node1 == node2
            resistance = 0;
        elseif node2 > node1
            resistance=P(node2-1);
        else
            resistance=P(node2);
        end


        VOLTAGES=P(:);
        VOLTAGES(node1)=0;%This step and the VOLTAGES vector are different from older versions because current is injected into node2
        VOLTAGES(node1+1:numnodes)=P(node1:numnodes-1);

        pt1=POINTS_RC(point_1,1);
        pt1=num2str(pt1);
        pt2=POINTS_RC(point_2,1);
        pt2=num2str(pt2);

        if options.curMapFlag
            SOURCESTEMP=zeros(numnodes,1);%BHM040408
            SOURCESTEMP(node2)=1;%BHM040408

            G_GRAPH = (G - diag(sparse(diag(G))));

            if point_1==numpoints-1
                if point_2==numpoints
                    writeCumFlag=1;
                end
            end
            FINITEGROUNDS=zeros(size(VOLTAGES));%No finite grounds in pairwise case.
            CUMCURRMAP=cs_current_map(pt1,pt2,VOLTAGES,FINITEGROUNDS,G_GRAPH,NODEMAP,CUMCURRMAP,writeCumFlag);
        end
        if options.voltMapFlag
            cs_voltage_map(pt1,pt2,VOLTAGES,NODEMAP,numnodes)
        end

        %Store resistances and voltages
        RESISTANCES(pointer1,pointer2)=resistance;
        RESISTANCES(pointer2,pointer1)=resistance;
        %Label header row and columns
        pointlabel_1=POINTS_RC(point_1,1);
        pointlabel_2=POINTS_RC(point_2,1);
        RESISTANCES(1,pointer1)=pointlabel_1;
        RESISTANCES(pointer1,1)=pointlabel_1;
        RESISTANCES(1,pointer2)=pointlabel_2;
        RESISTANCES(pointer2,1)=pointlabel_2;
        count=count+1;

        for n=1:(length(pctDoneStr)+1)
            fprintf('\b')
        end
        pctDone=round(100*count/(numpoints*0.5*(numpoints-1)));
        pctDoneStr=strcat(num2str(pctDone),'% done');
        fprintf('%s\n', pctDoneStr)
    end % for node2

    cs_write_resistances(0, RESISTANCES) %Write partially completed results
end % for node1

numDropPoints=size(POINTS_RC, 1)-nnz(POINTS_RC(:,4));
fprintf('\n%d source/ground points were dropped. \n', numDropPoints)

cs_write_resistances(G, RESISTANCES)
% cs_write_resistances(G, RESISTANCES) %Write output file

RESISTANCES(1,:)=[];
RESISTANCES(:,1)=[];

return;

