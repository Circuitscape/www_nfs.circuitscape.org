function cs_options (handles)
% CS_OPTIONS - Default options.
%
% Brad McRae, Viral B. Shah (C) 2006-08. All rights reserved.
%
% $Id: cs_options.m 30 2007-04-30 02:04:55Z viral $

global options

if(nargin) %Called to update options structure based on GUI input and add extra options fields
    options.scenario=handles.scenario;
    options.inDir=handles.inDir;
    options.cellFile=handles.cellFile;
    options.resistanceFlag=handles.resistanceFlag;
    options.pointFile=handles.pointFile;
    
    options.fourNeighborFlag=handles.fourNeighborFlag;
    options.avgResistanceFlag=handles.avgResistanceFlag;

    options.polygonFlag=handles.polygonFlag;
    options.polygonFile=handles.polygonFile;
    

    options.groundFile=handles.groundFile;
    options.groundRorC=handles.groundRorC;
    options.unitCurrents=handles.unitCurrents;
    options.directGrounds=handles.directGrounds;
    options.rmvSrcGnd=handles.rmvSrcGnd;

    options.outDir=handles.outDir;
    options.outFile=handles.outFile;
    options.curMapFlag=handles.curMapFlag;
    options.voltMapFlag=handles.voltMapFlag;

else
    if exist('cs_options.mat')
        load cs_options.mat
    else
        fprintf('Options.mat is missing. Reverting to default options. \n')
        localdir='.';
        os=computer;
        if os(1,1)=='P';
            options.PC=1;
            slash='\';
        else
            options.PC=0;
            slash='/';
        end
        options.scenario='pairwise';
        options.inDir=strcat(localdir,slash,'testdata');
        options.cellFile=strcat(options.inDir,slash,'test_cellmap.asc');
        options.resistanceFlag=0;
        options.pointFile=strcat(options.inDir,slash,'test_points_textlist.txt');



        options.fourNeighborFlag=1;        
        options.avgResistanceFlag=1;
        
        options.polygonFlag=1;
        options.polygonFile=strcat(options.inDir,slash,'test_polygons.asc');

        options.groundFile=strcat(options.inDir,slash,'groundfile.asc');
        options.groundRorC=1;
        options.unitCurrents=0;
        options.directGrounds=0;
        options.rmvSrcGnd='keepAll';

        options.outDir=strcat(localdir,slash,'testdata',slash,'output');
        options.outFile=strcat(options.outDir,slash,'test.out');
        options.curMapFlag=0;
        options.voltMapFlag=0;


        if exist ('Hypre_PCG_BAMG', 'file') ~= 2
            addpath gapdt
            addpath Hypre
        end

        if isStarP ()
            options.usingStarP = true;
        else
            options.usingStarP = false;
        end

        % Load Hypre package if using StarP.
        if options.usingStarP;
            Hypre_init;
        end
    end
end

if exist ('Hypre_PCG_BAMG', 'file') ~= 2
    addpath gapdt
    addpath Hypre
end


if isStarP ()
    options.usingStarP = true;
else
    options.usingStarP = false;
end

% Disable StarP even if it is detected.
%options.usingStarP = false;

% Load Hypre package if using StarP.
if options.usingStarP;
    Hypre_init;
end

os=computer;
if os(1,1)=='P'
    options.PC=1;
else
    options.PC=0;
end

%options.avgResistanceFlag=1; %Average resistances between cells in graph construction for now.


%Setting statement below to true will maximize speed for solving many source/ground point pairs.
%Setting to false will maximize grid size that the program can solve.
options.useChol = true; % Use cholesky factors if true. Otherwise
% use \ for all solves.
