function NODEMAP = cs_relabel (NODEMAP);
% CS_RELABEL - Relabel nodes in a contiguous range.
%
% Brad McRae, Viral B. Shah (C) 2006-08. All rights reserved.
%
% $Id: cs_relabel.m 21 2007-04-27 05:27:30Z viral $

% Use fixuplabels to relabel nodes in a contiguous range.
NODEMAP_1d = full(reshape (NODEMAP, 1, prod(size(NODEMAP))));
NODEMAP_1d = fixuplabels (NODEMAP_1d);

% Set empty cells back to zero. fixuplabels assigns node lables
% starting at 1. Subracting 1 makes the empty cells back to 0. 
if nnz(not(NODEMAP))>0
  NODEMAP_1d = NODEMAP_1d - 1;
end

NODEMAP = reshape (NODEMAP_1d, size(NODEMAP));
