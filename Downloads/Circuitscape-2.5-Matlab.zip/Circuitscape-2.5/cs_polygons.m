function [G, NODEMAP2] = cs_polygons (G, NODEMAP1, POLYGONMAP)
% CS_POLYGONS - Consolidate polygons into a single node.
%
% Brad McRae, Viral B. Shah (C) 2006-08. All rights reserved.
%
% $Id: cs_polygons.m 21 2007-04-27 05:27:30Z viral $

cs_time ('Consolidating short-circuit regions');

oldnumnodes = length(G);

% Which nodes are in node map?
NODEMAPPOS=NODEMAP1 > 0;
% Which nodes are positive in polygon map?
POLYGONPOS=POLYGONMAP > 0;  
POLYGONPOS=POLYGONPOS.*NODEMAPPOS;
% Change negative entries in polygon map to zero.
POLYGONMAP=POLYGONMAP .* POLYGONPOS; 

% Assign high node numbers to polygon nodes. All nodes in a polygon
% have the same number.
NODEMAP2 = (not(POLYGONPOS) .* NODEMAP1) + ...
    (POLYGONMAP + POLYGONPOS .* max(max(NODEMAP1)));

% Relabel nodes in a contiguous range.
NODEMAP2 = cs_relabel (NODEMAP2);

% VS 031707 - Simplify code by using contract from gapdt.
% Contract polygons in the graph.
NODEMAP2_TRANS = NODEMAP2';
LABELS = nonzeros (NODEMAP2_TRANS(:));
G = contract (G, LABELS);

fprintf ('              : %d node(s) consolidated. Graph now has %d nodes.\n', ...
         oldnumnodes-length(G), length(G));
