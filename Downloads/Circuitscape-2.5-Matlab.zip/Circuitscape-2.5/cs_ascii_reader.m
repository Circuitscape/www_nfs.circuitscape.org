function [GISMAP ncol nrow xllcorner yllcorner cellsize NODATA_value] = cs_ascii_reader(filename)

        GISMAP = textread(filename,'','headerlines',6);
        [text,header] = textread(filename,'%s %f',6);
        ncol = header(1);
        nrow = header(2);
        xllcorner = header(3);
        yllcorner = header(4);
        cellsize = header(5);
        NODATA_value = header(6);

        SIZE_GISMAP=size(GISMAP) ;%Sometimes get extra column
        gis_ncols=SIZE_GISMAP(2);
      
        if ncol < gis_ncols;
            GISMAP(:,gis_ncols)=[];
        end
