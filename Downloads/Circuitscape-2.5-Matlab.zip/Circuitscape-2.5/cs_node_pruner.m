function [G, NODEMAP] = cs_node_pruner(G, NODEMAP, POINTS_RC)
% CS_NODE_PRUNER - Prune disconnected parts of the graph.
%
% Brad McRae, Viral B. Shah (C) 2006-08. All rights reserved.
%
% $Id: cs_node_pruner.m 31 2007-05-01 19:36:23Z viral $

global options;

cs_time ('Evaluating node connectedness');

oldnumnodes = length(G);

%First source point defines what is and is not connected
target_row=POINTS_RC(1,2);
target_col=POINTS_RC(1,3);
target_node=NODEMAP(target_row,target_col);
if target_node==0
  error('Error: first current source point is not in habitat.')
end

c = components(G); 
if max(c) > 1
    target_component=c(target_node);
    keep = find (c == target_component);
    remove = find (c ~= target_component);

    % New graph does not have disconnected components
    G = G(keep, keep);

    % Drop removed nodes from NODEMAP.
    [I, J, V] = find (NODEMAP);
    delete = cs_intersect (V, remove);
    V(delete) = 0;
    NODEMAP = sparse (I, J, V, size(NODEMAP,1), size(NODEMAP,2));

    % Relabel nodes in a contiguous range.
    NODEMAP = cs_relabel (NODEMAP);

    fprintf ('              : %d nodes pruned. Graph has %d nodes.\n', ...
             oldnumnodes-length(G), length(G));
else
    fprintf('               : No node pruning was needed.\n')
end

end % cs_node_pruner

function delete = cs_intersect (V, remove) 
% This is a Star-P replacement for intersect 
% Perhaps more efficient than the MATLAB equivalent: 
%        [ign, delete] = intersect (V, remove);

V_ind(V) = 1:length(V);
H1 = sparse (V,1,1,max(V),1);
H2 = sparse (remove,1,1,max(V),1);
delete = V_ind(H1 & H2);

end % cs_intersect
