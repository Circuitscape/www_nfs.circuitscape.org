% Brad McRae, Viral B. Shah (C) 2006-08. All rights reserved.
clear all;
global options

cs_gui

%Need to do:
%error handling with dropped or absent sources and grounds
%drop sources and grounds that fall outside of connected component
%tooltip
%testing
%duplicate riverside?
%source and ground identifiers?
%fix and standardize points_rc and grounds_rc
%error check- points, grounds from text list in range
%zero sources?
