function cs_write_resistances(G, RESISTANCES)

% CS - WRITE_RESISTANCES
%
% Write pairwise resistances to output file

% Brad McRae, Viral B. Shah (C) 2006-08. All rights reserved.

global options

output_filename=options.outFile;
SIZE=size(output_filename);
size_output_filename=SIZE(2);
outfile_root=output_filename(1:size_output_filename-4);
outfile_extension=output_filename(size_output_filename-3:size_output_filename);
outfile=strcat(outfile_root,'_resistances',outfile_extension);

NODE_NUMBERS=RESISTANCES(1,:);
NODE_NUMBERS(1)=[];
RESISTANCES(1,:)=[];
RESISTANCES(:,1)=[];

fid = fopen(outfile,'w');

if length(G)>1
    numnodes=size(G,1);
    if(options.resistanceFlag)
        fprintf(fid,'Cell values specify RESISTANCES \n')  ;
    else
        fprintf(fid,'Cell values specify CONDUCTANCES \n')  ;
    end
    if(options.fourNeighborFlag)
        fprintf(fid,'Connections made using using FOUR neighbors \n')  ;
    else
        fprintf(fid,'Connections made using using EIGHT neighbors \n')  ;
    end
    if(options.avgResistanceFlag)
        fprintf(fid,'Connections made using using average RESISTANCES \n')  ;
    else
        fprintf(fid,'Connections made using using average CONDUCTANCES \n')  ;
    end

    fprintf(fid,'Number of nodes: %d\n',numnodes);
    sumG=full(sum(diag(G)));
    fprintf(fid,'Sum of conductances: %d\n',sumG);
    fprintf(fid,'Cell map filename: %s \n', options.cellFile);
    fprintf(fid,'Source/ground point filename: %s \n', options.pointFile);
    if(options.polygonFlag)
        fprintf(fid,'Short-circuit region filename: %s \n', options.polygonFile);
    end
    fprintf(fid,'Output filename: %s \n\n\n', outfile);
else
    fprintf(fid,'Partially completed results\n\n\n');
end

SIZE_R=size(RESISTANCES);
numrows_r=SIZE_R(1,1);

fprintf(fid,'\t') ; %Hold that first space in upper left hand of output matrix
fprintf(fid,'%i\t',NODE_NUMBERS) ; %Top row of node numbers
fprintf(fid,'\n');

for row=1:numrows_r
    fprintf(fid,'%i\t',NODE_NUMBERS(row)) ;
    fprintf(fid,'%e\t',RESISTANCES(row,:)) ;
    fprintf(fid,'\n');
end

st=fclose(fid);
