function cs_logwriter(G)

% Brad McRae, Viral B. Shah (C) 2006-08. All rights reserved.

global options

%write log file
output_filename=options.outFile;
SIZE=size(output_filename);
size_output_filename=SIZE(2);
outfile_root=output_filename(1:size_output_filename-4);
outfile=strcat(outfile_root,'.log');

numnodes = length (G);

fid = fopen(outfile,'w');

if strcmp(options.scenario,'pairwise')
    fprintf(fid,'Scenario is PAIRWISE \n\n')  ;
elseif strcmp(options.scenario,'oneSrcAllGnd')
    fprintf(fid,'Scenario: activate one source and all grounds at a time\n\n')  ;
elseif strcmp(options.scenario,'allSrcOneGnd')
    fprintf(fid,'Scenario: activate one ground and all sources at a time\n\n')  ;
else
    fprintf(fid,'Scenario: activate all sources and all grounds at once\n\n')  ;
end

fprintf(fid,'Cell map filename: %s \n', options.cellFile);

if(options.resistanceFlag)
    fprintf(fid,'Cell values specify RESISTANCES \n\n')  ;
else
    fprintf(fid,'Cell values specify CONDUCTANCES \n\n')  ;
end
if strcmp(options.scenario,'pairwise')
fprintf(fid,'Source/ground filename: %s \n\n', options.pointFile);
else
    fprintf(fid,'Current source filename: %s \n\n', options.pointFile);
end
if(options.polygonFlag)
    fprintf(fid,'Short-circuit raster filename: %s \n\n', options.polygonFile);
end

if ~strcmp(options.scenario,'pairwise')
    fprintf(fid,'Ground point filename: %s \n', options.groundFile);
    if(options.groundRorC)
        fprintf(fid,'Ground point values specify RESISTANCES \n\n')  ;
    else
        fprintf(fid,'Ground point values specify CONDUCTANCES \n\n')  ;
    end
    if(options.unitCurrents)
        fprintf(fid,'Unit currents used\n')  ;
    end
    if(options.directGrounds)
        fprintf(fid,'Direct grounds used\n')  ;
    end
    fprintf(fid,'When a node is both a source and a ground:\n');
    if strcmp(options.rmvSrcGnd,'keepAll')
        fprintf(fid,'Sources and ground connections not removed unless ground connection is direct\n\n')  ;
    elseif strcmp(options.rmvSrcGnd,'rmvGnd')
        fprintf(fid,'Ground connection is removed\n\n')  ;
    else
        fprintf(fid,'Current source is removed\n\n')  ;
    end
end

    if(options.fourNeighborFlag)
        fprintf(fid,'Connections made using using FOUR neighbors \n')  ;
    else
        fprintf(fid,'Connections made using using EIGHT neighbors \n')  ;
    end
    
    if(options.avgResistanceFlag) 
        fprintf(fid,'Connections made using using average RESISTANCES \n\n')  ;
    else
        fprintf(fid,'Connections made using using average CONDUCTANCES \n\n')  ;
    end
        fprintf(fid,'Number of nodes: %d\n\n',numnodes);

    
    fprintf(fid,'Output filename: %s \n\n', options.outFile);
    if options.curMapFlag
        fprintf(fid,'Current maps created. \n');
    end
    if options.voltMapFlag
        fprintf(fid,'Voltage maps created. \n');
    end
    st=fclose(fid);
